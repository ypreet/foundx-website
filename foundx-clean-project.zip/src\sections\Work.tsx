import { useState } from 'react';
import { motion } from 'framer-motion';
import { FadeUp } from '../components/ui/FadeUp';
import { Code2, Smartphone, Globe, ArrowUpRight, Cpu } from 'lucide-react';

const categories = ['All Projects', 'Web & SaaS', 'AI & Automation', 'Mobile Apps'];

const caseStudies = [
  {
    id: 'found-x',
    title: 'Found X Studio Platform',
    category: 'Web & SaaS',
    year: '2026',
    client: 'FOUND X Ecosystem',
    img: '/images/work/foundx-platform.png',
    metrics: '12.4ms Latency • 100% Precision',
    tech: ['React 19', 'Next.js 15', 'Tailwind v3', 'Framer Motion', 'Node.js'],
    overview: 'A high-performance digital ecosystem providing technical founders with spatial insights, real-time node telemetry, and automated studio workflows.',
    problem: 'Traditional founder tools are linear and clunky, failing to provide the deep focus and raw execution speed required by high-scale technical directors.',
    approach: 'Engineered a Spatial OS aesthetic combining Imperial Warm Cream, Antique Gold, and 3D glassmorphic telemetry cards designed for sub-frame execution.',
    learning: 'High-contrast design coupled with obsessive 1px metallic borders creates instant technical credibility and domain authority.',
  },
  {
    id: 'moyo-ai',
    title: 'Moyo AI — Predictive Engine',
    category: 'AI & Automation',
    year: '2026',
    client: 'Moyo Intelligence',
    img: '/images/work/moyo-ai.png',
    metrics: '410ms Task Speed • 4 Autonomous Nodes',
    tech: ['Python', 'FastAPI', 'RAG Vector Search', 'LLM Agents', 'Tailwind'],
    overview: 'A predictive intelligence tool designed to surface actionable insights from unstructured enterprise data streams, operating silently in the background.',
    problem: 'Executive teams waste hours parsing disconnected telemetry streams without semantic context or automated prioritization.',
    approach: 'Architected a multi-modal AI agent network that ingests 100,000 events/sec and surfaces real-time vector memory insights.',
    learning: 'User trust in AI systems is established through complete execution transparency and clean log outputs.',
  },
  {
    id: 'web-app-projects',
    title: 'Sub-Frame Web & App Suite',
    category: 'Web & SaaS',
    year: '2026',
    client: 'High-Growth Tech Clients',
    img: '/images/work/web-app-suite.png',
    metrics: '99.98% Uptime • 50+ Products Shipped',
    tech: ['React 19', 'TypeScript', 'Serverless Edge', 'GraphQL', 'Tailwind'],
    overview: 'A suite of high-conversion marketing surfaces, SaaS web apps, and cross-platform clients built for speed and technical authority.',
    problem: 'Heavy legacy codebases cause slow page loads and high drop-off rates for enterprise software products.',
    approach: 'Strict adherence to edge rendering patterns, modular component architectures, and sub-15ms edge caching.',
    learning: 'Speed is the ultimate product feature. Reducing latency directly scales conversion rates by 4.8x.',
  },
  {
    id: 'ai-tools-agents',
    title: 'Autonomous AI Agent Network',
    category: 'AI & Automation',
    year: '2026',
    client: 'FOUND X AI Lab',
    img: '/images/work/ai-agent-suite.png',
    metrics: '100k Events/Sec • Zero Human Bottleneck',
    tech: ['Python', 'LangChain', 'Pinecone Vector DB', 'Node.js', 'Docker'],
    overview: 'Autonomous agent network integrated into CLI and IDE environments to automate code refactoring, deployment telemetry, and bug patching.',
    problem: 'Repetitive maintenance tasks and manual deployment checks slow down engineering iteration velocity.',
    approach: 'Deployed self-contained localized agents that execute background verification and automatically issue refactor pull requests.',
    learning: 'Autonomous workflows succeed when agents operate within strict guardrails with transparent logging.',
  },
];

const capabilities = [
  {
    icon: Code2,
    title: 'Custom Web & SaaS Platforms',
    desc: 'Scalable web applications built with React 19, Next.js, and TypeScript engineered for sub-frame edge rendering.',
    stack: ['React 19', 'Next.js 15', 'TypeScript', 'Node.js'],
  },
  {
    icon: Smartphone,
    title: 'Cross-Platform Mobile Apps',
    desc: 'Fluid iOS & Android native-feel applications built for offline sync and smooth gesture interactions.',
    stack: ['React Native', 'Flutter', 'iOS / Android'],
  },
  {
    icon: Cpu,
    title: 'AI Agents & Automation',
    desc: 'Autonomous multi-node LLM agent pipelines, RAG vector search, and enterprise workflow telemetry.',
    stack: ['RAG Vector DB', 'LLM Agents', 'Python', 'FastAPI'],
  },
  {
    icon: Globe,
    title: 'High-Conversion Marketing Surfaces',
    desc: 'High-authority landing pages and digital brand surfaces optimized for SEO, speed, and founder positioning.',
    stack: ['Tailwind v3', 'Framer Motion', 'Edge Caching'],
  },
];

export function Work() {
  const [selectedCategory, setSelectedCategory] = useState('All Projects');

  const filteredProjects = selectedCategory === 'All Projects'
    ? caseStudies
    : caseStudies.filter(p => p.category === selectedCategory);

  return (
    <section id="work" className="w-full bg-[#F6F3EC] text-[#181716] py-16 md:py-24">
      {/* Header Section */}
      <header className="px-margin-mobile md:px-margin-desktop max-w-container-max mx-auto text-center mb-16">
        <FadeUp>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#EFECE4] border border-[#9E7B4F]/40 text-[#9E7B4F] font-mono text-xs font-bold uppercase tracking-widest mb-4 shadow-sm">
            WORK & CASE STUDIES PORTFOLIO
          </div>
        </FadeUp>
        <FadeUp delay={0.1}>
          <h2 className="font-display font-bold text-4xl sm:text-6xl md:text-7xl text-[#181716] tracking-tight leading-tight mb-6">
            Things I've built, <span className="text-[#9E7B4F]">explored & shipped.</span>
          </h2>
        </FadeUp>
        <FadeUp delay={0.15}>
          <p className="font-sans text-base sm:text-lg text-[#54504A] max-w-2xl mx-auto leading-relaxed">
            A curated portfolio of high-performance web platforms, autonomous AI agent systems, and spatial interfaces engineered with sub-frame speed.
          </p>
        </FadeUp>

        {/* Filter Categories */}
        <FadeUp delay={0.2}>
          <div className="flex flex-wrap justify-center gap-3 mt-10">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-5 py-2 rounded-full text-xs font-mono font-bold tracking-wider transition-all cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-[#9E7B4F] text-white shadow-md'
                    : 'bg-[#EFECE4] text-[#54504A] hover:bg-[#E2DED4] hover:text-[#181716] border border-[#9E7B4F]/20'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </FadeUp>
      </header>

      {/* Main Case Studies Grid */}
      <div className="px-margin-mobile md:px-margin-desktop max-w-container-max mx-auto space-y-16 mb-24">
        {filteredProjects.map((cs, index) => (
          <FadeUp key={cs.id} delay={index * 0.1}>
            <motion.article
              whileHover={{ y: -4 }}
              transition={{ duration: 0.35 }}
              className="bg-[#EFECE4] rounded-2xl border border-[#9E7B4F]/30 overflow-hidden metallic-edge shadow-lg hover:border-[#9E7B4F] hover:shadow-2xl transition-all grid grid-cols-1 lg:grid-cols-12 gap-0"
            >
              {/* Ultra-HD Image Container */}
              <div className="lg:col-span-6 relative overflow-hidden group min-h-[320px] lg:min-h-[460px] bg-[#121215]">
                <img
                  src={cs.img}
                  alt={cs.title}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 brightness-95 group-hover:brightness-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#181716]/80 via-transparent to-transparent opacity-60 pointer-events-none" />
                <div className="absolute top-4 left-4 bg-[#181716]/90 backdrop-blur-md text-[#9E7B4F] px-3.5 py-1.5 rounded-full font-mono text-xs font-bold border border-[#9E7B4F]/40 shadow-md">
                  {cs.metrics}
                </div>
              </div>

              {/* Case Study Details Column */}
              <div className="lg:col-span-6 p-8 md:p-12 flex flex-col justify-between bg-[#EFECE4]">
                <div>
                  {/* Category & Client Header — Unified Cluster */}
                  <div className="flex flex-wrap items-center gap-3 mb-4">
                    <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1 rounded-md border border-[#9E7B4F]/25 font-bold uppercase tracking-wider">
                      {cs.category} • {cs.year}
                    </span>
                    <span className="text-[#9E7B4F]/40 font-bold">•</span>
                    <span className="font-mono text-xs text-[#54504A] font-semibold">{cs.client}</span>
                  </div>

                  <h3 className="font-display font-bold text-2xl md:text-4xl text-[#181716] mb-4">
                    {cs.title}
                  </h3>

                  <p className="font-sans text-sm md:text-base text-[#54504A] leading-relaxed mb-6">
                    {cs.overview}
                  </p>

                  {/* Problem & Approach Breakdown with Clear Gutter & Scannability */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6 pt-4 border-t border-[#9E7B4F]/20">
                    <div>
                      <h4 className="font-mono text-xs text-[#9E7B4F] font-bold uppercase tracking-wider mb-1.5">The Challenge</h4>
                      <p className="font-sans text-xs text-[#54504A] leading-relaxed">{cs.problem}</p>
                    </div>
                    <div className="sm:border-l sm:border-[#9E7B4F]/20 sm:pl-5">
                      <h4 className="font-mono text-xs text-[#9E7B4F] font-bold uppercase tracking-wider mb-1.5">Our Approach</h4>
                      <p className="font-sans text-xs text-[#54504A] leading-relaxed">{cs.approach}</p>
                    </div>
                  </div>

                  {/* Tech Stack Pills */}
                  <div className="flex flex-wrap gap-2 mb-6">
                    {cs.tech.map(t => (
                      <span key={t} className="font-mono text-xs text-[#181716] bg-[#FAF8F5] px-2.5 py-1 rounded-md border border-[#9E7B4F]/25 font-semibold">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Bottom Action Link with Prominent Single-Line CTA */}
                <div className="pt-4 border-t border-[#9E7B4F]/20 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <span className="font-mono text-xs text-[#54504A] italic">{cs.learning}</span>
                  <a
                    href="#contact"
                    className="btn-secondary text-xs px-4 py-2 shrink-0 whitespace-nowrap inline-flex items-center gap-2 self-start sm:self-auto"
                  >
                    <span>Build Similar Product</span>
                    <ArrowUpRight size={15} />
                  </a>
                </div>
              </div>
            </motion.article>
          </FadeUp>
        ))}
      </div>

      {/* Capabilities Section — Bento Cards */}
      <div className="px-margin-mobile md:px-margin-desktop max-w-container-max mx-auto">
        <FadeUp>
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="font-display font-bold text-3xl md:text-5xl text-[#181716]">Studio Capabilities</h2>
            <p className="font-sans text-sm md:text-base text-[#54504A] mt-3">What we bring to every engineering engagement.</p>
          </div>
        </FadeUp>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {capabilities.map((cap, i) => {
            const Icon = cap.icon;
            return (
              <FadeUp key={cap.title} delay={i * 0.1}>
                <div className="bg-[#EFECE4] p-8 rounded-2xl border border-[#9E7B4F]/30 metallic-edge shadow-md">
                  <div className="w-12 h-12 rounded-full bg-[#FAF8F5] border border-[#9E7B4F]/30 flex items-center justify-center text-[#9E7B4F] mb-6 shadow-sm">
                    <Icon size={24} />
                  </div>
                  <h3 className="font-display font-bold text-2xl text-[#181716] mb-3">{cap.title}</h3>
                  <p className="font-sans text-sm text-[#54504A] leading-relaxed mb-6">{cap.desc}</p>
                  <div className="flex flex-wrap gap-2">
                    {cap.stack.map(s => (
                      <span key={s} className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-2.5 py-1 rounded border border-[#9E7B4F]/25 font-bold">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              </FadeUp>
            );
          })}
        </div>
      </div>
    </section>
  );
}
