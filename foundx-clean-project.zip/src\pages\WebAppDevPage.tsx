import { Link } from 'react-router-dom';
import { FadeUp } from '../components/ui/FadeUp';
import { Zap, ArrowLeft, Server, Globe, Smartphone } from 'lucide-react';
import { Technology } from '../sections/Technology';

export function WebAppDevPage() {
  const capabilities = [
    {
      title: 'Custom Web & SaaS Platforms',
      description: 'React 19, Next.js 15, TypeScript, and serverless edge rendering built for zero latency.',
      icon: Globe,
    },
    {
      title: 'Cross-Platform Mobile Apps',
      description: 'Native-feel iOS & Android applications built with React Native / Flutter and offline sync.',
      icon: Smartphone,
    },
    {
      title: 'API & Microservices Engineering',
      description: 'High-throughput Node.js, REST, GraphQL, and serverless architectures engineered for scale.',
      icon: Server,
    },
    {
      title: 'Sub-Frame Performance Optimization',
      description: 'Core Web Vitals tuning, bundle reduction, and edge caching for sub-15ms response times.',
      icon: Zap,
    },
  ];

  return (
    <div className="py-20 md:py-28 px-margin-mobile md:px-margin-desktop max-w-container-max mx-auto bg-[#F6F3EC] text-[#181716]">
      {/* Back Link */}
      <div className="mb-8">
        <Link to="/services" className="inline-flex items-center gap-2 font-mono text-xs text-[#9E7B4F] font-bold uppercase tracking-wider hover:underline">
          <ArrowLeft size={16} /> BACK TO ALL SERVICES
        </Link>
      </div>

      {/* Hero Header */}
      <div className="text-center max-w-4xl mx-auto mb-16">
        <FadeUp>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#EFECE4] border border-[#9E7B4F]/40 text-[#9E7B4F] font-mono text-xs font-bold uppercase tracking-widest mb-4 shadow-sm">
            01 // ENGINEERING PILLAR
          </div>
        </FadeUp>
        <FadeUp delay={0.1}>
          <h1 className="font-display font-bold text-4xl sm:text-6xl md:text-7xl text-[#181716] tracking-tight leading-tight mb-6">
            Web & Mobile App <span className="text-[#9E7B4F]">Development Studio.</span>
          </h1>
        </FadeUp>
        <FadeUp delay={0.15}>
          <p className="font-sans text-lg text-[#54504A] leading-relaxed max-w-2xl mx-auto mb-8">
            High-performance React 19, Next.js 15, Node.js, and mobile applications built for technical visionaries with sub-frame speed and architectural precision.
          </p>
        </FadeUp>

        <FadeUp delay={0.2}>
          <div className="flex justify-center gap-4">
            <Link to="/contact" className="btn-primary">
              START DEVELOPMENT
            </Link>
            <Link to="/work" className="btn-secondary">
              VIEW CASE STUDIES
            </Link>
          </div>
        </FadeUp>
      </div>

      {/* Engineering Capabilities Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        {capabilities.map((cap, i) => {
          const Icon = cap.icon;
          return (
            <FadeUp key={cap.title} delay={i * 0.1}>
              <div className="bg-[#EFECE4] p-8 rounded-xl border border-[#9E7B4F]/30 metallic-edge shadow-md">
                <div className="w-12 h-12 rounded-full bg-[#FAF8F5] border border-[#9E7B4F]/30 flex items-center justify-center text-[#9E7B4F] mb-6 shadow-sm">
                  <Icon size={24} />
                </div>
                <h3 className="font-display font-bold text-2xl text-[#181716] mb-3">{cap.title}</h3>
                <p className="font-sans text-sm text-[#54504A] leading-relaxed">{cap.description}</p>
              </div>
            </FadeUp>
          );
        })}
      </div>

      {/* Full Stack Technology Matrix */}
      <Technology />

      {/* CTA Footer */}
      <div className="mt-16 text-center pt-12 border-t border-[#9E7B4F]/25">
        <h3 className="font-display font-bold text-3xl text-[#181716] mb-4">Ready to build your web or mobile product?</h3>
        <p className="font-sans text-base text-[#54504A] mb-8">Sub-frame edge speed, clean code, and zero compromises.</p>
        <Link to="/contact" className="btn-primary">INQUIRE FOR DEVELOPMENT</Link>
      </div>
    </div>
  );
}
