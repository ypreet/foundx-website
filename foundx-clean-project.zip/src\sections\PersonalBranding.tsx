import { FadeUp } from '../components/ui/FadeUp';

const before = [
  'Generic profile',
  'No clear positioning',
  'Random content',
  'Low visibility',
  'No inbound leads',
];

const after = [
  'Clear, strong positioning',
  'Expert authority',
  'Consistent value content',
  'High search visibility',
  'Inbound opportunities',
];

export function PersonalBranding() {
  return (
    <section className="section-y bg-brand-white">
      <div className="section-padding max-w-screen-xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Left */}
          <div className="flex flex-col gap-8">
            <FadeUp>
              <p className="label">Personal Branding</p>
            </FadeUp>
            <FadeUp delay={0.1}>
              <h2 className="heading-md text-brand-black">
                People Buy From People They Remember.
              </h2>
            </FadeUp>
            <FadeUp delay={0.15}>
              <p className="body-lg">
                A strong personal brand is not about ego. It is about clarity — making it obvious who you are, what you do, and why someone should work with you.
              </p>
            </FadeUp>
            <FadeUp delay={0.2}>
              <div className="grid grid-cols-2 gap-3 mt-2">
                {['Clear Positioning', 'Consistent Content', 'Thought Leadership', 'Social Proof', 'Network Building', 'Lead Generation'].map(item => (
                  <div
                    key={item}
                    className="flex items-center gap-2 text-sm text-brand-black/65 border border-brand-border rounded-lg px-4 py-3"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-brand-brown flex-shrink-0" />
                    {item}
                  </div>
                ))}
              </div>
            </FadeUp>
          </div>

          {/* Right — before/after */}
          <FadeUp delay={0.2}>
            <div className="grid grid-cols-2 gap-4">
              {/* Before */}
              <div className="flex flex-col gap-4 p-6 rounded-2xl bg-brand-gray border border-brand-border">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-red-300" />
                  <p className="text-xs font-bold tracking-widest uppercase text-brand-black/40">Before</p>
                </div>
                {before.map(item => (
                  <div key={item} className="flex items-start gap-2">
                    <span className="text-red-300 text-xs mt-0.5">✗</span>
                    <span className="text-sm text-brand-black/50">{item}</span>
                  </div>
                ))}
              </div>

              {/* After */}
              <div className="flex flex-col gap-4 p-6 rounded-2xl bg-brand-brown text-white">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-brand-brown-warm" />
                  <p className="text-xs font-bold tracking-widest uppercase text-white/50">After</p>
                </div>
                {after.map(item => (
                  <div key={item} className="flex items-start gap-2">
                    <span className="text-brand-brown-warm text-xs mt-0.5">✓</span>
                    <span className="text-sm text-white/80">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </FadeUp>
        </div>
      </div>
    </section>
  );
}
