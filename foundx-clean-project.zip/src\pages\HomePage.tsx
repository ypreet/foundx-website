import { Hero } from '../sections/Hero';
import { DeviceShowcase } from '../sections/DeviceShowcase';
import { Services } from '../sections/Services';
import { Technology } from '../sections/Technology';
import { Work } from '../sections/Work';
import { GrowpidoProofFAQ } from '../components/GrowpidoProofFAQ';
import { About } from '../sections/About';
import { Contact } from '../sections/Contact';

export function HomePage() {
  return (
    <>
      <Hero />
      <DeviceShowcase />
      <Services />
      <Technology />
      <Work />
      <GrowpidoProofFAQ />
      <About />
      <Contact />
    </>
  );
}
