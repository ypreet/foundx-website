import { motion } from 'framer-motion';
import { FadeUp } from '../components/ui/FadeUp';
import { Search, Zap, Compass, TestTube, RefreshCw, Fingerprint, Terminal, ArrowRight } from 'lucide-react';

const trajectory = [
  {
    year: '2024',
    title: 'LinkedIn & Executive Narrative Engineering',
    desc: 'Mastering the digital handshake. Building algorithmic leverage and cultivating high-signal networks for founders and executives in the tech ecosystem.',
    active: false,
  },
  {
    year: '2025',
    title: 'AI, Web & Edge Backend Development',
    desc: 'Transitioning from narrative to infrastructure. Deep-diving into LLM integration, robust serverless architectures, and creating seamless spatial web experiences.',
    active: false,
  },
  {
    year: '2026',
    title: 'Found X + Autonomous AI Agents + Digital Products',
    desc: 'The convergence. Launching Found X to synthesize experimental AI agent workflows into scalable, premium digital products for technical directors.',
    active: true,
  },
];

const principles = [
  {
    num: '01',
    title: 'Obsessive Curiosity',
    rule: 'Rule: Deep-Dive First Principles',
    desc: 'Dissecting complex systems down to fundamental truths before writing a single line of code or design.',
    icon: Search,
    span: 'col-span-1 md:col-span-2 lg:col-span-2',
  },
  {
    num: '02',
    title: 'Relentless Execution',
    rule: 'Rule: Sub-Frame 16ms Speed',
    desc: 'Ideas are cheap; sub-frame execution is rare. Shipping production code with absolute speed and zero friction.',
    icon: Zap,
    span: 'col-span-1 md:col-span-2 lg:col-span-3',
  },
  {
    num: '03',
    title: 'Architectural Clarity',
    rule: 'Rule: 100% Signal-to-Noise',
    desc: 'Eliminating bloated abstractions and clutter. Creating transparent, high-signal interfaces that command authority.',
    icon: Compass,
    span: 'col-span-1 md:col-span-2 lg:col-span-3',
  },
  {
    num: '04',
    title: 'Empirical Experimentation',
    rule: 'Rule: Rapid AI Prototyping',
    desc: 'Testing hypotheses against live production data rather than relying on guesswork or conventional templates.',
    icon: TestTube,
    span: 'col-span-1 md:col-span-2 lg:col-span-2',
  },
];

export function About() {
  return (
    <section id="about" className="py-16 md:py-24 px-margin-mobile md:px-margin-desktop w-full max-w-container-max mx-auto relative bg-[#F6F3EC] text-[#181716]">
      {/* Hero Header */}
      <div className="mb-16 text-center max-w-4xl mx-auto">
        <FadeUp>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#EFECE4] border border-[#9E7B4F]/40 text-[#9E7B4F] font-mono text-xs font-bold uppercase tracking-widest mb-4 shadow-sm">
            THE PERSON BEHIND FOUND X
          </div>
        </FadeUp>
        <FadeUp delay={0.1}>
          <h2 className="font-display text-4xl sm:text-6xl md:text-7xl font-bold tracking-tight text-[#181716] leading-tight mb-4">
            Still early. <span className="text-[#9E7B4F]">Still building.</span>
          </h2>
        </FadeUp>
        <FadeUp delay={0.15}>
          <p className="font-sans text-base sm:text-lg text-[#54504A] max-w-2xl mx-auto leading-relaxed">
            Founded by Preet Yadav, FOUND X is an architectural studio designed for technical founders who demand performance, speed, and domain authority.
          </p>
        </FadeUp>
      </div>

      {/* Split Cards: BRAND vs BUILD */}
      <div className="mb-20 grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* BRAND Side */}
        <FadeUp>
          <motion.div
            whileHover={{ y: -4 }}
            transition={{ duration: 0.35 }}
            className="bg-[#EFECE4] rounded-2xl p-8 md:p-10 border border-[#9E7B4F]/30 metallic-edge relative overflow-hidden flex flex-col justify-between min-h-[340px] shadow-lg group hover:border-[#9E7B4F] transition-all"
          >
            <div>
              <div className="flex justify-between items-center mb-6">
                <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1 rounded border border-[#9E7B4F]/25 font-bold uppercase tracking-wider">
                  PILLAR 01 // BRAND NARRATIVE
                </span>
                <Fingerprint size={28} className="text-[#9E7B4F] group-hover:scale-110 transition-transform" />
              </div>
              <h3 className="font-display font-bold text-3xl md:text-4xl text-[#181716] mb-3">
                Brand Authority
              </h3>
              <p className="font-sans text-sm md:text-base text-[#54504A] leading-relaxed">
                Crafting identity in the digital ether. Establishing presence through precision, technical narrative, and uncompromising aesthetic standards.
              </p>
            </div>

            <div className="pt-6 border-t border-[#9E7B4F]/20 flex items-center justify-between font-mono text-xs font-bold text-[#9E7B4F]">
              <span>POSITIONING & REPUTATION</span>
              <ArrowRight size={16} />
            </div>
          </motion.div>
        </FadeUp>

        {/* BUILD Side */}
        <FadeUp delay={0.15}>
          <motion.div
            whileHover={{ y: -4 }}
            transition={{ duration: 0.35 }}
            className="bg-[#EFECE4] rounded-2xl p-8 md:p-10 border border-[#9E7B4F]/30 metallic-edge relative overflow-hidden flex flex-col justify-between min-h-[340px] shadow-lg group hover:border-[#9E7B4F] transition-all"
          >
            <div>
              <div className="flex justify-between items-center mb-6">
                <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1 rounded-md border border-[#9E7B4F]/25 font-bold uppercase tracking-wider">
                  PILLAR 02 // CODE ENGINEERING
                </span>
                <Terminal size={28} className="text-[#9E7B4F] group-hover:scale-110 transition-transform" />
              </div>
              <h3 className="font-display font-bold text-3xl md:text-4xl text-[#181716] mb-3">
                Build & Infrastructure
              </h3>
              <p className="font-sans text-sm md:text-base text-[#54504A] leading-relaxed">
                Engineering complex web applications, mobile clients, and autonomous AI agents designed to handle growth effortlessly with zero latency.
              </p>
            </div>

            <div className="pt-6 border-t border-[#9E7B4F]/20 flex items-center justify-between font-mono text-xs font-bold text-[#9E7B4F]">
              <span>REACT 19 • AI AGENTS • EDGE</span>
              <ArrowRight size={16} />
            </div>
          </motion.div>
        </FadeUp>
      </div>

      {/* Trajectory Timeline */}
      <div className="mb-24 bg-[#EFECE4] rounded-2xl p-8 md:p-12 border border-[#9E7B4F]/30 metallic-edge shadow-xl">
        <FadeUp>
          <div className="flex justify-between items-center mb-10 pb-4 border-b border-[#9E7B4F]/20">
            <span className="font-mono text-xs text-[#9E7B4F] font-bold uppercase tracking-widest">
              THE STUDIO TRAJECTORY
            </span>
            <span className="font-mono text-xs text-[#54504A]">2024 — PRESENT</span>
          </div>
        </FadeUp>

        <div className="relative pl-6 md:pl-10 border-l-2 border-[#9E7B4F]/30 space-y-10">
          {trajectory.map((item, i) => (
            <FadeUp key={item.year} delay={i * 0.15}>
              <div className="relative">
                {/* Node Bullet */}
                <div className={`absolute -left-[31px] md:-left-[47px] top-1 w-4 h-4 rounded-full border-2 ${item.active ? 'bg-[#9E7B4F] border-white shadow-md' : 'bg-[#EFECE4] border-[#9E7B4F]/50'}`} />
                
                <span className={`font-mono text-xs font-bold mb-1.5 block tracking-wider ${item.active ? 'text-[#9E7B4F]' : 'text-[#54504A]'}`}>
                  {item.year} {item.active && '• CURRENT MANDATE'}
                </span>
                
                <h4 className="font-display text-xl md:text-2xl font-bold text-[#181716] mb-2">
                  {item.title}
                </h4>
                
                <p className="font-sans text-sm md:text-base text-[#54504A] max-w-2xl leading-relaxed">
                  {item.desc}
                </p>
              </div>
            </FadeUp>
          ))}
        </div>
      </div>

      {/* CORE PRINCIPLES BENTO GRID */}
      <div>
        <FadeUp>
          <div className="text-center max-w-3xl mx-auto mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#EFECE4] border border-[#9E7B4F]/40 text-[#9E7B4F] font-mono text-xs font-bold uppercase tracking-widest mb-3 shadow-sm">
              FOUNDER METHODOLOGY
            </div>
            <h3 className="font-display font-bold text-3xl md:text-5xl text-[#181716] tracking-tight">
              Core Architectural Principles
            </h3>
            <p className="font-sans text-sm text-[#54504A] mt-2">
              The unyielding standards governing every product, code commit, and brand strategy shipped by FOUND X.
            </p>
          </div>
        </FadeUp>

        {/* Bento Principles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-6">
          {principles.map((p, i) => {
            const Icon = p.icon;
            return (
              <FadeUp key={p.title} delay={i * 0.1} className={p.span}>
                <motion.div
                  whileHover={{ y: -4 }}
                  transition={{ duration: 0.35 }}
                  className="bg-[#EFECE4] p-8 rounded-2xl border border-[#9E7B4F]/30 metallic-edge flex flex-col justify-between h-full shadow-md hover:border-[#9E7B4F] hover:shadow-xl transition-all group"
                >
                  <div>
                    <div className="flex justify-between items-center mb-6">
                      <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1 rounded border border-[#9E7B4F]/25 font-bold">
                        PRINCIPLE {p.num}
                      </span>
                      <div className="w-10 h-10 rounded-full bg-[#FAF8F5] border border-[#9E7B4F]/30 flex items-center justify-center text-[#9E7B4F] group-hover:bg-[#9E7B4F] group-hover:text-white transition-all shadow-sm">
                        <Icon size={20} />
                      </div>
                    </div>

                    <h4 className="font-display font-bold text-2xl text-[#181716] mb-2 group-hover:text-[#9E7B4F] transition-colors">
                      {p.title}
                    </h4>
                    <p className="font-mono text-xs text-[#8B693C] font-semibold mb-4">
                      {p.rule}
                    </p>
                    <p className="font-sans text-sm text-[#54504A] leading-relaxed">
                      {p.desc}
                    </p>
                  </div>
                </motion.div>
              </FadeUp>
            );
          })}
        </div>

        {/* Full-Width Principle Card: Continuous Compounding */}
        <FadeUp delay={0.4}>
          <motion.div
            whileHover={{ y: -4 }}
            transition={{ duration: 0.35 }}
            className="bg-[#EFECE4] p-8 md:p-10 rounded-2xl border border-[#9E7B4F]/40 metallic-edge shadow-lg hover:border-[#9E7B4F] transition-all flex flex-col md:flex-row justify-between items-start md:items-center gap-6"
          >
            <div className="flex items-start gap-5">
              <div className="w-12 h-12 rounded-full bg-[#9E7B4F]/15 border border-[#9E7B4F]/40 flex items-center justify-center text-[#9E7B4F] shrink-0 shadow-sm">
                <RefreshCw size={24} />
              </div>
              <div>
                <span className="font-mono text-xs text-[#9E7B4F] font-bold uppercase tracking-widest block mb-1">
                  PRINCIPLE 05 // COMPOUNDING MASTERY
                </span>
                <h4 className="font-display font-bold text-2xl md:text-3xl text-[#181716] mb-2">
                  Continuous Learning & Iteration
                </h4>
                <p className="font-sans text-sm text-[#54504A] max-w-2xl leading-relaxed">
                  Technology moves fast. We relentlessly refactor codebases, upgrade AI models, and optimize funnels so our clients remain ahead of the curve.
                </p>
              </div>
            </div>

            <a href="#contact" className="btn-primary shrink-0">
              BUILD WITH US
            </a>
          </motion.div>
        </FadeUp>
      </div>
    </section>
  );
}
