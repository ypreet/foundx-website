import { useState, useEffect } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';

const navLinks = [
  { path: '/', label: 'Home' },
  { path: '/services', label: 'Services' },
  { path: '/3d-showcase', label: '3D Showcase' },
  { path: '/ai-lab', label: 'AI Lab' },
  { path: '/work', label: 'Work' },
  { path: '/about', label: 'About' },
  { path: '/insights', label: 'Insights' },
  { path: '/contact', label: 'Contact' },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <>
      <nav
        className={`fixed top-0 w-full z-50 transition-all duration-500 ease-out ${
          scrolled
            ? 'bg-[#F6F3EC]/90 backdrop-blur-xl border-b border-[#9E7B4F]/25 py-3 shadow-[0_4px_25px_rgba(158,123,79,0.08)]'
            : 'bg-[#F6F3EC]/70 backdrop-blur-xl border-b border-[#9E7B4F]/15 py-3.5'
        }`}
      >
        <div className="flex justify-between items-center px-margin-desktop max-w-container-max mx-auto md:px-margin-desktop px-margin-mobile">
          {/* Logo with Seal Emblem */}
          <Link to="/" className="flex items-center gap-3 group">
            <img
              src="/images/foundx-logo.png"
              alt="FOUND X Seal Logo"
              className="w-10 h-10 object-contain rounded-full mix-blend-multiply group-hover:scale-105 transition-transform"
            />
            <span className="font-display text-xl md:text-2xl font-bold tracking-tighter text-[#181716] group-hover:text-[#9E7B4F] transition-colors">
              FOUND X
            </span>
          </Link>

          {/* Desktop Nav Links */}
          <ul className="hidden md:flex gap-4 lg:gap-6 font-mono text-xs items-center uppercase tracking-wider">
            {navLinks.map((link) => (
              <li key={link.label}>
                <NavLink
                  to={link.path}
                  end={link.path === '/'}
                  className={({ isActive }) =>
                    `relative py-1.5 px-3 rounded-lg transition-all duration-300 font-semibold ${
                      isActive
                        ? 'text-[#9E7B4F] bg-[#9E7B4F]/10 border border-[#9E7B4F]/30 shadow-xs'
                        : 'text-[#54504A] hover:text-[#181716] hover:bg-[#9E7B4F]/5'
                    }`
                  }
                >
                  {({ isActive }) => (
                    <>
                      <span>{link.label}</span>
                      {isActive && (
                        <span className="absolute bottom-0 left-2 right-2 h-0.5 bg-[#9E7B4F] rounded-full" />
                      )}
                    </>
                  )}
                </NavLink>
              </li>
            ))}
          </ul>

          {/* CTA */}
          <div className="hidden md:block">
            <Link
              to="/contact"
              className="bg-[#9E7B4F] text-[#FAF8F5] font-mono text-xs font-bold uppercase tracking-wider px-6 py-3 rounded shadow-[0_4px_15px_rgba(158,123,79,0.25)] hover:bg-[#8B693C] transition-all inline-block"
            >
              Let's Build
            </Link>
          </div>

          {/* Mobile Menu Hamburger */}
          <button
            className="md:hidden text-[#181716] p-1"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Toggle menu"
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className="fixed inset-0 z-40 bg-[#F6F3EC] flex flex-col pt-24 px-8 pb-12"
          >
            <nav className="flex flex-col gap-6 flex-1">
              {navLinks.map((link, i) => (
                <motion.div
                  key={link.label}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                >
                  <NavLink
                    to={link.path}
                    end={link.path === '/'}
                    className={({ isActive }) =>
                      `font-display text-2xl font-bold transition-colors block py-1 ${
                        isActive
                          ? 'text-[#9E7B4F] pl-3 border-l-4 border-[#9E7B4F]'
                          : 'text-[#181716] hover:text-[#9E7B4F]'
                      }`
                    }
                    onClick={() => setMenuOpen(false)}
                  >
                    {link.label}
                  </NavLink>
                </motion.div>
              ))}
            </nav>
            <Link
              to="/contact"
              className="bg-[#9E7B4F] text-white font-mono text-xs font-bold uppercase tracking-wider text-center py-4 rounded shadow-lg"
              onClick={() => setMenuOpen(false)}
            >
              Let's Build
            </Link>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
