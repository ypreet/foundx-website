import { useState } from 'react';
import { FadeUp } from '../components/ui/FadeUp';
import { Mail, Phone, ExternalLink, MessageCircle, Check, Copy, Send } from 'lucide-react';

export function Contact() {
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', projectType: 'Build Web App', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText('info@foundx.co.in');
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;
    
    // Construct WhatsApp message URL for direct high-intent conversion
    const text = `Hi Preet! My name is ${formData.name} (${formData.email}). Interest: ${formData.projectType}. Message: ${formData.message}`;
    const waUrl = `https://wa.me/919990044861?text=${encodeURIComponent(text)}`;
    
    setSubmitted(true);
    setTimeout(() => {
      window.open(waUrl, '_blank');
    }, 600);
  };

  return (
    <section id="contact" className="py-16 md:py-24 px-margin-mobile md:px-margin-desktop w-full max-w-container-max mx-auto relative z-10 bg-[#F6F3EC] text-[#181716]">
      {/* Centered Section Header for Perfect Visual Balance */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <FadeUp>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#EFECE4] border border-[#9E7B4F]/40 text-[#9E7B4F] font-mono text-xs font-bold uppercase tracking-widest mb-4 shadow-sm">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            DIRECT STUDIO INQUIRY
          </div>
        </FadeUp>
        <FadeUp delay={0.1}>
          <h2 className="font-display text-4xl sm:text-6xl md:text-7xl font-bold text-[#181716] leading-tight mb-4 tracking-tight">
            Let’s build <span className="text-[#9E7B4F] italic">something useful.</span>
          </h2>
        </FadeUp>
        <FadeUp delay={0.15}>
          <p className="font-sans text-base md:text-lg text-[#54504A] leading-relaxed max-w-2xl mx-auto">
            We partner with founders and technical directors who value precision, deep engineering, and high-performance tooling.
          </p>
        </FadeUp>
      </div>

      {/* Balanced 2-Column Grid with Equal Top Alignment */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch w-full">
        {/* Left Column: Interactive Inquiry Form (7 cols) */}
        <div className="lg:col-span-7 flex flex-col">
          <FadeUp delay={0.2} className="h-full flex flex-col">
            <form onSubmit={handleSubmit} className="bg-[#EFECE4] backdrop-blur-2xl rounded-2xl p-6 sm:p-8 md:p-10 metallic-edge border border-[#9E7B4F]/30 flex flex-col justify-between h-full shadow-[0_10px_35px_rgba(158,123,79,0.08)]">
              <div>
                <div className="flex items-center justify-between pb-6 mb-6 border-b border-[#9E7B4F]/20">
                  <div>
                    <span className="font-mono text-xs text-[#9E7B4F] uppercase tracking-wider font-bold block mb-1">
                      ONLINE INQUIRY FORM
                    </span>
                    <h3 className="font-display text-2xl md:text-3xl font-bold text-[#181716]">
                      Start a Conversation
                    </h3>
                  </div>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#9E7B4F]/10 border border-[#9E7B4F]/30 text-[#9E7B4F] font-mono text-xs font-bold tracking-wider">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#9E7B4F] animate-pulse" />
                    <span>Response &lt; 4 Hrs</span>
                  </div>
                </div>

                <div className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block font-mono text-xs text-[#54504A] uppercase tracking-wider mb-2 font-semibold">Your Name</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Alex Morgan"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full bg-[#FAF8F5] border border-[#9E7B4F]/30 rounded-lg px-4 py-3.5 text-sm text-[#181716] placeholder:text-[#54504A]/50 focus:border-[#9E7B4F] focus:outline-none transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block font-mono text-xs text-[#54504A] uppercase tracking-wider mb-2 font-semibold">Your Email</label>
                      <input
                        type="email"
                        required
                        placeholder="alex@company.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full bg-[#FAF8F5] border border-[#9E7B4F]/30 rounded-lg px-4 py-3.5 text-sm text-[#181716] placeholder:text-[#54504A]/50 focus:border-[#9E7B4F] focus:outline-none transition-colors"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-mono text-xs text-[#54504A] uppercase tracking-wider mb-2 font-semibold">Primary Goal</label>
                    <select
                      value={formData.projectType}
                      onChange={(e) => setFormData({ ...formData, projectType: e.target.value })}
                      className="w-full bg-[#FAF8F5] border border-[#9E7B4F]/30 rounded-lg px-4 py-3.5 text-sm text-[#181716] focus:border-[#9E7B4F] focus:outline-none transition-colors cursor-pointer"
                    >
                      <option value="Build Web App">Build Web & App Product (Next.js / React / Node)</option>
                      <option value="LinkedIn Growth">LinkedIn Personal Brand & Lead Gen</option>
                      <option value="AI Tools & Agents">Autonomous AI Agents & RAG Systems</option>
                      <option value="Full Studio Retainer">Full Studio Retainer / Advisory</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-mono text-xs text-[#54504A] uppercase tracking-wider mb-2 font-semibold">Project Details</label>
                    <textarea
                      required
                      rows={4}
                      placeholder="Tell us briefly about your project scope, timelines, or goal..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full bg-[#FAF8F5] border border-[#9E7B4F]/30 rounded-lg px-4 py-3.5 text-sm text-[#181716] placeholder:text-[#54504A]/50 focus:border-[#9E7B4F] focus:outline-none transition-colors resize-none"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-6 mt-6 border-t border-[#9E7B4F]/20">
                <button
                  type="submit"
                  disabled={submitted}
                  className="btn-primary w-full py-4 text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-[0_4px_20px_rgba(158,123,79,0.3)]"
                >
                  {submitted ? (
                    <>
                      <Check size={16} className="text-emerald-300" /> CONNECTING DIRECTLY ON WHATSAPP...
                    </>
                  ) : (
                    <>
                      <Send size={15} /> SEND INQUIRY TO PREET
                    </>
                  )}
                </button>
              </div>
            </form>
          </FadeUp>
        </div>

        {/* Right Column: Founder Direct Contact Card (5 cols) */}
        <div className="lg:col-span-5 flex flex-col">
          <FadeUp delay={0.25} className="h-full flex flex-col">
            <div className="bg-[#EFECE4] backdrop-blur-2xl rounded-2xl p-6 sm:p-8 md:p-10 metallic-edge relative overflow-hidden group transition-all duration-500 border border-[#9E7B4F]/30 shadow-[0_10px_35px_rgba(158,123,79,0.1)] flex flex-col justify-between h-full">
              {/* Inner gold ambient glow */}
              <div className="absolute inset-0 bg-[#9E7B4F]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

              <div className="relative z-10 flex flex-col justify-between h-full">
                <div>
                  <div className="mb-8 pb-6 border-b border-[#9E7B4F]/20 flex justify-between items-center">
                    <div className="flex items-center gap-4">
                      <img
                        src="/images/foundx-logo.png"
                        alt="FOUND X Seal Emblem"
                        className="w-12 h-12 object-contain rounded-full mix-blend-multiply"
                      />
                      <div>
                        <h3 className="font-display text-2xl md:text-3xl font-bold text-[#181716] mb-0.5">
                          Preet Yadav
                        </h3>
                        <p className="font-mono text-xs text-[#9E7B4F] tracking-wider font-semibold">
                          Founder — Found X
                        </p>
                      </div>
                    </div>
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 font-mono text-xs font-bold tracking-wider shrink-0">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      <span>Online</span>
                    </div>
                  </div>

                  <div className="space-y-5">
                    {/* Email with 1-Click Copy right next to the text */}
                    <div className="flex items-center gap-3.5 group/item">
                      <div className="w-10 h-10 rounded-full bg-[#FAF8F5] flex items-center justify-center metallic-edge border border-[#9E7B4F]/30 group-hover/item:border-[#9E7B4F] transition-all text-[#54504A] group-hover/item:text-[#9E7B4F] shadow-sm shrink-0">
                        <Mail size={18} />
                      </div>
                      <div>
                        <p className="font-mono text-xs text-[#54504A] mb-0.5 tracking-wider uppercase font-semibold">
                          EMAIL
                        </p>
                        <div className="flex items-center gap-2">
                          <a
                            href="mailto:info@foundx.co.in"
                            className="font-sans text-sm text-[#181716] group-hover/item:text-[#9E7B4F] transition-colors font-semibold"
                          >
                            info@foundx.co.in
                          </a>
                          <button
                            onClick={handleCopyEmail}
                            title="Copy Email"
                            className="p-1.5 rounded-md bg-[#FAF8F5] text-[#54504A] hover:text-[#9E7B4F] hover:bg-[#9E7B4F]/10 transition-all border border-[#9E7B4F]/25 cursor-pointer inline-flex items-center justify-center"
                          >
                            {copiedEmail ? <Check size={14} className="text-emerald-600" /> : <Copy size={14} />}
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Phone */}
                    <a
                      href="tel:+919990044861"
                      className="flex items-center gap-3.5 group/item"
                    >
                      <div className="w-10 h-10 rounded-full bg-[#FAF8F5] flex items-center justify-center metallic-edge border border-[#9E7B4F]/30 group-hover/item:border-[#9E7B4F] transition-all text-[#54504A] group-hover/item:text-[#9E7B4F] shadow-sm shrink-0">
                        <Phone size={18} />
                      </div>
                      <div>
                        <p className="font-mono text-xs text-[#54504A] mb-0.5 tracking-wider uppercase font-semibold">
                          PHONE
                        </p>
                        <p className="font-sans text-sm text-[#181716] group-hover/item:text-[#9E7B4F] transition-colors font-semibold">
                          +91 9990044861
                        </p>
                      </div>
                    </a>

                    {/* LinkedIn */}
                    <a
                      href="https://www.linkedin.com/in/preet-yadav-found-x/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3.5 group/item"
                    >
                      <div className="w-10 h-10 rounded-full bg-[#FAF8F5] flex items-center justify-center metallic-edge border border-[#9E7B4F]/30 group-hover/item:border-[#9E7B4F] transition-all text-[#54504A] group-hover/item:text-[#9E7B4F] shadow-sm shrink-0">
                        <ExternalLink size={18} />
                      </div>
                      <div>
                        <p className="font-mono text-xs text-[#54504A] mb-0.5 tracking-wider uppercase font-semibold">
                          LINKEDIN
                        </p>
                        <p className="font-sans text-sm text-[#181716] group-hover/item:text-[#9E7B4F] transition-colors font-semibold">
                          Preet Yadav
                        </p>
                      </div>
                    </a>
                  </div>
                </div>

                {/* Subordinate Secondary WhatsApp Button */}
                <div className="pt-6 mt-6 border-t border-[#9E7B4F]/20 flex flex-col gap-3">
                  <a
                    href="https://wa.me/919990044861?text=Hi%20Preet,%20I%20saw%20your%20website%20and%20would%20love%20to%20discuss%20a%20project!"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-secondary w-full py-3.5 border border-[#9E7B4F]/40 hover:bg-[#9E7B4F]/10 text-[#181716] font-mono text-xs font-bold rounded-xl flex items-center justify-center gap-2"
                  >
                    <MessageCircle size={16} className="text-[#9E7B4F]" />
                    <span>Quick Message on WhatsApp</span>
                  </a>
                  <p className="font-mono text-xs text-center text-[#54504A] tracking-wider font-semibold">
                    Location: Gurugram / NCR, India — Global Remote
                  </p>
                </div>
              </div>
            </div>
          </FadeUp>
        </div>
      </div>
    </section>
  );
}
