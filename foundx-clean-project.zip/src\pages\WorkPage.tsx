import { Work } from '../sections/Work';

export function WorkPage() {
  return (
    <div className="pt-12">
      <Work />
    </div>
  );
}
