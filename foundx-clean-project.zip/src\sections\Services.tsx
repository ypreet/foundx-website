import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { FadeUp } from '../components/ui/FadeUp';
import { ArrowRight, Code2, Sparkles, Cpu, TrendingUp } from 'lucide-react';

export function Services() {
  return (
    <section id="services" className="py-16 md:py-24 px-margin-mobile md:px-margin-desktop w-full max-w-container-max mx-auto relative bg-[#F6F3EC] text-[#181716]">
      {/* Header Section */}
      <header className="flex flex-col gap-4 md:w-3/4 mb-12">
        <FadeUp>
          <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1.5 rounded border border-[#9E7B4F]/25 uppercase tracking-widest font-bold w-fit inline-block">
            STUDIO CAPABILITIES // 4 CORE PILLARS
          </span>
        </FadeUp>
        <FadeUp delay={0.1}>
          <h2 className="font-display font-bold text-4xl sm:text-6xl md:text-7xl text-[#181716] leading-tight tracking-tight">
            Everything founders need to <span className="text-[#9E7B4F]">build, scale & command authority.</span>
          </h2>
        </FadeUp>
        <FadeUp delay={0.15}>
          <p className="font-sans text-base sm:text-lg text-[#54504A] max-w-2xl leading-relaxed">
            A boutique builder's studio engineered for technical directors, CTOs, and visionaries who demand architectural precision and zero friction.
          </p>
        </FadeUp>
      </header>

      {/* Services Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* BUILD Category (col-span-8) */}
        <FadeUp className="md:col-span-8">
          <motion.div
            whileHover={{ y: -4 }}
            transition={{ duration: 0.35 }}
            className="bg-[#EFECE4] rounded-2xl p-8 border border-[#9E7B4F]/30 metallic-edge flex flex-col gap-6 shadow-sm hover:border-[#9E7B4F] hover:shadow-md transition-all h-full justify-between group"
          >
            <div>
              <div className="flex justify-between items-start mb-4">
                <div className="flex flex-col gap-1">
                  <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1 rounded border border-[#9E7B4F]/25 w-fit font-bold tracking-wider uppercase">
                    PILLAR 01 // ENGINEERING
                  </span>
                  <h3 className="font-display font-bold text-3xl md:text-4xl text-[#181716] mt-2">
                    BUILD
                  </h3>
                </div>
                <div className="p-3 rounded-xl bg-[#FAF8F5] border border-[#9E7B4F]/20 text-[#9E7B4F] group-hover:scale-110 transition-transform">
                  <Code2 size={26} />
                </div>
              </div>

              <div
                className="w-full h-60 rounded-xl metallic-edge overflow-hidden relative bg-cover bg-center border border-[#9E7B4F]/20 mb-6 shadow-inner"
                style={{
                  backgroundImage:
                    "url('https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1200&q=80')",
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-t from-[#181716]/80 via-[#181716]/30 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center text-xs font-mono text-white">
                  <span>REACT 19 • NEXT.JS 15 • EDGE CLOUD</span>
                  <span className="text-[#C5A059] font-bold">12.4MS LATENCY</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-display font-bold text-xl text-[#181716] mb-1.5">
                    Web & SaaS Applications
                  </h4>
                  <p className="font-sans text-sm text-[#54504A] leading-relaxed">
                    Scalable, zero-compromise web applications built with TypeScript, Node.js, and serverless edge rendering.
                  </p>
                </div>
                <div>
                  <h4 className="font-display font-bold text-xl text-[#181716] mb-1.5">
                    Mobile & Native Clients
                  </h4>
                  <p className="font-sans text-sm text-[#54504A] leading-relaxed">
                    Cross-platform iOS and Android applications with offline-first synchronization and sub-16ms touch responses.
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-[#9E7B4F]/20 flex justify-between items-center">
              <span className="font-mono text-xs text-[#54504A]">50+ Products Shipped</span>
              <Link
                to="/services/web-app-development"
                className="btn-link group-hover:gap-3"
              >
                <span>Explore Build Services</span>
                <ArrowRight size={14} />
              </Link>
            </div>
          </motion.div>
        </FadeUp>

        {/* BRAND Category (col-span-4) */}
        <FadeUp delay={0.15} className="md:col-span-4">
          <motion.div
            whileHover={{ y: -4 }}
            transition={{ duration: 0.35 }}
            className="bg-[#EFECE4] rounded-2xl p-8 border border-[#9E7B4F]/30 metallic-edge flex flex-col gap-6 shadow-sm hover:border-[#9E7B4F] hover:shadow-md transition-all h-full justify-between group"
          >
            <div>
              <div className="flex justify-between items-start mb-4">
                <div className="flex flex-col gap-1">
                  <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1 rounded border border-[#9E7B4F]/25 w-fit font-bold tracking-wider uppercase">
                    PILLAR 02 // IDENTITY
                  </span>
                  <h3 className="font-display font-bold text-3xl md:text-4xl text-[#181716] mt-2">
                    BRAND
                  </h3>
                </div>
                <div className="p-3 rounded-xl bg-[#FAF8F5] border border-[#9E7B4F]/20 text-[#9E7B4F] group-hover:scale-110 transition-transform">
                  <Sparkles size={26} />
                </div>
              </div>

              <div
                className="w-full h-48 rounded-xl metallic-edge overflow-hidden relative bg-cover bg-center border border-[#9E7B4F]/20 mb-6 shadow-inner"
                style={{
                  backgroundImage:
                    "url('https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80')",
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-t from-[#181716]/80 via-[#181716]/30 to-transparent" />
                <div className="absolute bottom-4 left-4 text-xs font-mono text-[#C5A059] font-bold">
                  FOUNDER NARRATIVE ARCHITECTURE
                </div>
              </div>

              <div>
                <h4 className="font-display font-bold text-xl text-[#181716] mb-1.5">
                  Personal Brand Advisory
                </h4>
                <p className="font-sans text-sm text-[#54504A] leading-relaxed">
                  Strategic narrative positioning for CTOs and technical founders that commands respect and unlocks high-ticket inbounds.
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-[#9E7B4F]/20 flex justify-between items-center">
              <span className="font-mono text-xs text-[#54504A]">50+ Leaders Guided</span>
              <Link
                to="/services/personal-branding"
                className="btn-link group-hover:gap-3"
              >
                <span>Explore Brand Advisory</span>
                <ArrowRight size={14} />
              </Link>
            </div>
          </motion.div>
        </FadeUp>

        {/* AUTOMATE Category (col-span-6) */}
        <FadeUp delay={0.2} className="md:col-span-6">
          <motion.div
            whileHover={{ y: -4 }}
            transition={{ duration: 0.35 }}
            className="bg-[#EFECE4] rounded-2xl p-8 border border-[#9E7B4F]/30 metallic-edge flex flex-col gap-6 shadow-sm hover:border-[#9E7B4F] hover:shadow-md transition-all h-full justify-between group"
          >
            <div>
              <div className="flex justify-between items-start mb-4">
                <div className="flex flex-col gap-1">
                  <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1 rounded border border-[#9E7B4F]/25 w-fit font-bold tracking-wider uppercase">
                    PILLAR 03 // INTELLIGENCE
                  </span>
                  <h3 className="font-display font-bold text-3xl md:text-4xl text-[#181716] mt-2">
                    AUTOMATE
                  </h3>
                </div>
                <div className="p-3 rounded-xl bg-[#FAF8F5] border border-[#9E7B4F]/20 text-[#9E7B4F] group-hover:scale-110 transition-transform">
                  <Cpu size={26} />
                </div>
              </div>

              <div
                className="w-full h-44 rounded-xl metallic-edge overflow-hidden relative bg-cover bg-center border border-[#9E7B4F]/20 mb-6 shadow-inner"
                style={{
                  backgroundImage:
                    "url('https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&w=800&q=80')",
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-t from-[#181716]/80 via-[#181716]/30 to-transparent" />
                <div className="absolute bottom-4 left-4 text-xs font-mono text-[#C5A059] font-bold">
                  AUTONOMOUS RAG VECTOR PIPELINES
                </div>
              </div>

              <h4 className="font-display font-bold text-xl text-[#181716] mb-1.5">
                Autonomous AI Agent Networks
              </h4>
              <p className="font-sans text-sm text-[#54504A] leading-relaxed">
                Deploy multi-modal AI agents, vector retrieval databases, and self-executing business workflows that eliminate operational bottlenecks.
              </p>
            </div>

            <div className="pt-4 border-t border-[#9E7B4F]/20 flex justify-between items-center">
              <span className="font-mono text-xs text-[#54504A]">410ms Task Speed</span>
              <Link
                to="/services/ai-automation"
                className="btn-link group-hover:gap-3"
              >
                <span>Explore AI Agents</span>
                <ArrowRight size={14} />
              </Link>
            </div>
          </motion.div>
        </FadeUp>

        {/* GROW Category (col-span-6) */}
        <FadeUp delay={0.25} className="md:col-span-6">
          <motion.div
            whileHover={{ y: -4 }}
            transition={{ duration: 0.35 }}
            className="bg-[#EFECE4] rounded-2xl p-8 border border-[#9E7B4F]/30 metallic-edge flex flex-col gap-6 shadow-sm hover:border-[#9E7B4F] hover:shadow-md transition-all h-full justify-between group"
          >
            <div>
              <div className="flex justify-between items-start mb-4">
                <div className="flex flex-col gap-1">
                  <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1 rounded border border-[#9E7B4F]/25 w-fit font-bold tracking-wider uppercase">
                    PILLAR 04 // SCALE
                  </span>
                  <h3 className="font-display font-bold text-3xl md:text-4xl text-[#181716] mt-2">
                    GROW
                  </h3>
                </div>
                <div className="p-3 rounded-xl bg-[#FAF8F5] border border-[#9E7B4F]/20 text-[#9E7B4F] group-hover:scale-110 transition-transform">
                  <TrendingUp size={26} />
                </div>
              </div>

              <div
                className="w-full h-44 rounded-xl metallic-edge overflow-hidden relative bg-cover bg-center border border-[#9E7B4F]/20 mb-6 shadow-inner"
                style={{
                  backgroundImage:
                    "url('https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80')",
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-t from-[#181716]/80 via-[#181716]/30 to-transparent" />
                <div className="absolute bottom-4 left-4 text-xs font-mono text-[#C5A059] font-bold">
                  2.4M+ ORGANIC LINKEDIN REACH
                </div>
              </div>

              <h4 className="font-display font-bold text-xl text-[#181716] mb-1.5">
                LinkedIn Growth & Pipeline Engine
              </h4>
              <p className="font-sans text-sm text-[#54504A] leading-relaxed">
                Transform passive profiles into active commercial engines. High-intent inbound lead acquisition and algorithmic distribution.
              </p>
            </div>

            <div className="pt-4 border-t border-[#9E7B4F]/20 flex justify-between items-center">
              <span className="font-mono text-xs text-[#54504A]">₹22 Crore in Client POs</span>
              <Link
                to="/services/linkedin-growth"
                className="btn-link group-hover:gap-3"
              >
                <span>Explore Growth Engine</span>
                <ArrowRight size={14} />
              </Link>
            </div>
          </motion.div>
        </FadeUp>
      </div>
    </section>
  );
}
