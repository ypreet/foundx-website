import { Link } from 'react-router-dom';
import { FadeUp } from '../components/ui/FadeUp';
import { ArrowLeft } from 'lucide-react';
import { AILab } from '../sections/AILab';

export function AIAgentsPage() {
  return (
    <div className="py-20 md:py-28 px-margin-mobile md:px-margin-desktop max-w-container-max mx-auto bg-[#F6F3EC] text-[#181716]">
      {/* Back Link */}
      <div className="mb-8">
        <Link to="/services" className="inline-flex items-center gap-2 font-mono text-xs text-[#9E7B4F] font-bold uppercase tracking-wider hover:underline">
          <ArrowLeft size={16} /> BACK TO ALL SERVICES
        </Link>
      </div>

      {/* Hero Header */}
      <div className="text-center max-w-4xl mx-auto mb-16">
        <FadeUp>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#EFECE4] border border-[#9E7B4F]/40 text-[#9E7B4F] font-mono text-xs font-bold uppercase tracking-widest mb-4 shadow-sm">
            02 // DEDICATED INTELLIGENCE PILLAR
          </div>
        </FadeUp>
        <FadeUp delay={0.1}>
          <h1 className="font-display font-bold text-4xl sm:text-6xl md:text-7xl text-[#181716] tracking-tight leading-tight mb-6">
            Autonomous AI Agents & <span className="text-[#9E7B4F]">RAG Automation.</span>
          </h1>
        </FadeUp>
        <FadeUp delay={0.15}>
          <p className="font-sans text-lg text-[#54504A] leading-relaxed max-w-2xl mx-auto mb-8">
            Deploy multi-modal AI agent networks, RAG vector memory search, and enterprise workflow telemetry to automate complex business processes.
          </p>
        </FadeUp>

        <FadeUp delay={0.2}>
          <div className="flex justify-center gap-4">
            <Link to="/contact" className="btn-primary">
              DEPLOY AI AGENTS
            </Link>
            <Link to="/3d-showcase" className="btn-secondary">
              TEST LIVE TERMINAL
            </Link>
          </div>
        </FadeUp>
      </div>

      {/* AI Lab Detail Component */}
      <AILab />

      {/* CTA Footer */}
      <div className="mt-16 text-center pt-12 border-t border-[#9E7B4F]/25">
        <h3 className="font-display font-bold text-3xl text-[#181716] mb-4">Want to automate your business with AI agents?</h3>
        <p className="font-sans text-base text-[#54504A] mb-8">Custom agent architectures, vector memory, and automated workflows.</p>
        <Link to="/contact" className="btn-primary">DISCUSS AI AUTOMATION</Link>
      </div>
    </div>
  );
}
