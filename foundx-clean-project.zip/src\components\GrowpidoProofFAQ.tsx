import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { FadeUp } from './ui/FadeUp';
import { ShieldCheck, CheckCircle2, Zap, Sparkles, HelpCircle } from 'lucide-react';

const proofMetrics = [
  { val: '$10M+', label: 'Client Revenue & Deal Value Opened', sub: 'Through narrative & app engineering' },
  { val: '4.8M+', label: 'Organic LinkedIn Impressions', sub: 'Placed directly in front of decision-makers' },
  { val: '50+', label: 'Shipped Digital Products', sub: 'Web apps, mobile clients & AI agents' },
  { val: '99.98%', label: 'Uptime & Reliability SLA', sub: 'Sub-frame edge speed guarantee' },
];

const clientProofCards = [
  {
    name: 'Deepak Kr. Kaushik',
    title: 'Founder • Nyka International',
    result: '₹22 Crore in POs',
    quote: 'Within weeks, FOUND X took my brand from inactive to 100,000+ impressions, opening the door to ₹22 crore in purchase orders.',
    tag: 'ORGANIC REVENUE',
  },
  {
    name: 'Hemal Dua',
    title: 'Fractional COO',
    result: '64,000+ Impressions',
    quote: 'In just 90 days, I went from zero visibility on LinkedIn to 64K+ impressions and real high-ticket inbound deals coming straight to me.',
    tag: 'INBOUND PIPELINE',
  },
  {
    name: 'Aqeel Ahmed',
    title: 'Co-Founder & CTO • EcoRatings',
    result: 'Top Voice Status',
    quote: 'Preet and the FOUND X studio team delivered far more than expected. If you are a technical founder, I recommend them without hesitation.',
    tag: 'AUTHORITY ENGINE',
  },
];

const faqItems = [
  {
    q: 'What will I get and how soon will results show?',
    a: 'You get actual qualified inbound lead conversations, high-converting product architectures, and executive brand positioning. First measurable growth metrics appear within 30-45 days.',
  },
  {
    q: 'Will the positioning and content still sound like me?',
    a: 'Always. It is your technical thinking — just sharper. You approve every single wireframe, post, and architecture payload before it goes live.',
  },
  {
    q: 'How much of my time will this require?',
    a: 'Very little. About 10 minutes a week if we run the full Done-For-You studio model. About 15 minutes a day if you run your private engine.',
  },
  {
    q: 'What if it doesn\'t work for my business?',
    a: 'Then the risk is ours, not yours. We operate month-to-month after 90 days with a clear exit anytime. If agreed reliability or reach milestones aren\'t hit, no invoice for the next month.',
  },
];

export function GrowpidoProofFAQ() {
  const [activeFaq, setActiveFaq] = useState<number | null>(0);
  const [selectedDoor, setSelectedDoor] = useState<'dfy' | 'advisory'>('dfy');

  return (
    <section className="py-20 md:py-28 px-margin-mobile md:px-margin-desktop max-w-container-max mx-auto bg-[#F6F3EC] text-[#181716]">
      {/* SECTION 1: TWO DOORS / CHOOSE YOUR PATH */}
      <div className="mb-24">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <FadeUp>
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#EFECE4] border border-[#9E7B4F]/40 text-[#9E7B4F] font-mono text-xs font-bold uppercase tracking-widest mb-4 shadow-sm">
              ONE STUDIO • TWO DOORS
            </div>
          </FadeUp>
          <FadeUp delay={0.1}>
            <h2 className="font-display font-bold text-3xl sm:text-5xl md:text-6xl text-[#181716] tracking-tight leading-tight mb-4">
              Choose your <span className="text-[#9E7B4F]">engagement path.</span>
            </h2>
          </FadeUp>
          <FadeUp delay={0.15}>
            <p className="font-sans text-base md:text-lg text-[#54504A] leading-relaxed">
              Whether you want our complete studio to execute everything for you, or a private 1-on-1 advisory engine.
            </p>
          </FadeUp>
        </div>

        {/* Two Door Selector Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Door 1: Done For You */}
          <FadeUp delay={0.1}>
            <div
              onClick={() => setSelectedDoor('dfy')}
              className={`cursor-pointer rounded-2xl p-8 transition-all duration-500 border metallic-edge flex flex-col justify-between h-full ${
                selectedDoor === 'dfy'
                  ? 'bg-[#EFECE4] border-[#9E7B4F] shadow-[0_15px_45px_rgba(158,123,79,0.2)] ring-2 ring-[#9E7B4F]/50'
                  : 'bg-[#FAF8F5] border-[#9E7B4F]/20 hover:border-[#9E7B4F]/50'
              }`}
            >
              <div>
                <div className="flex justify-between items-center mb-6">
                  <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1 rounded border border-[#9E7B4F]/25 font-bold uppercase tracking-wider">
                    DOOR 01 // DONE-FOR-YOU
                  </span>
                  <Sparkles size={20} className="text-[#9E7B4F]" />
                </div>
                <h3 className="font-display font-bold text-2xl md:text-3xl text-[#181716] mb-3">
                  Full Studio Execution
                </h3>
                <p className="font-sans text-sm text-[#54504A] leading-relaxed mb-6">
                  We engineer your web/mobile apps, deploy custom AI agent pipelines, and manage your LinkedIn authority end-to-end.
                </p>
                <ul className="space-y-2.5 mb-8">
                  <li className="flex items-center gap-2 text-xs font-sans text-[#181716]">
                    <CheckCircle2 size={16} className="text-[#9E7B4F]" />
                    <span>Sub-frame Web & Mobile App Development</span>
                  </li>
                  <li className="flex items-center gap-2 text-xs font-sans text-[#181716]">
                    <CheckCircle2 size={16} className="text-[#9E7B4F]" />
                    <span>Autonomous AI Agents & RAG Vector Memory</span>
                  </li>
                  <li className="flex items-center gap-2 text-xs font-sans text-[#181716]">
                    <CheckCircle2 size={16} className="text-[#9E7B4F]" />
                    <span>LinkedIn Executive Reputation & Content Strategy</span>
                  </li>
                </ul>
              </div>
              <a href="#contact" className="btn-primary w-full text-center">
                ENTER DOOR 01 ↗
              </a>
            </div>
          </FadeUp>

          {/* Door 2: Private Advisory Engine */}
          <FadeUp delay={0.2}>
            <div
              onClick={() => setSelectedDoor('advisory')}
              className={`cursor-pointer rounded-2xl p-8 transition-all duration-500 border metallic-edge flex flex-col justify-between h-full ${
                selectedDoor === 'advisory'
                  ? 'bg-[#EFECE4] border-[#9E7B4F] shadow-[0_15px_45px_rgba(158,123,79,0.2)] ring-2 ring-[#9E7B4F]/50'
                  : 'bg-[#FAF8F5] border-[#9E7B4F]/20 hover:border-[#9E7B4F]/50'
              }`}
            >
              <div>
                <div className="flex justify-between items-center mb-6">
                  <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1 rounded border border-[#9E7B4F]/25 font-bold uppercase tracking-wider">
                    DOOR 02 // PRIVATE ADVISORY
                  </span>
                  <Zap size={20} className="text-[#9E7B4F]" />
                </div>
                <h3 className="font-display font-bold text-2xl md:text-3xl text-[#181716] mb-3">
                  1-on-1 Founder Engine
                </h3>
                <p className="font-sans text-sm text-[#54504A] leading-relaxed mb-6">
                  Direct weekly strategic advisory with Founder Preet Yadav to build your private technical stack, narrative, and inbound funnel.
                </p>
                <ul className="space-y-2.5 mb-8">
                  <li className="flex items-center gap-2 text-xs font-sans text-[#181716]">
                    <CheckCircle2 size={16} className="text-[#9E7B4F]" />
                    <span>Weekly 1-on-1 Technical & Brand Architecture</span>
                  </li>
                  <li className="flex items-center gap-2 text-xs font-sans text-[#181716]">
                    <CheckCircle2 size={16} className="text-[#9E7B4F]" />
                    <span>Private AI Agent Playbooks & Code Review</span>
                  </li>
                  <li className="flex items-center gap-2 text-xs font-sans text-[#181716]">
                    <CheckCircle2 size={16} className="text-[#9E7B4F]" />
                    <span>Executive Authority Blueprint for Tech Leaders</span>
                  </li>
                </ul>
              </div>
              <a href="#contact" className="btn-secondary w-full text-center">
                ENTER DOOR 02 ↗
              </a>
            </div>
          </FadeUp>
        </div>
      </div>

      {/* SECTION 2: PROOF & TRUST METRICS */}
      <div className="mb-24">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <FadeUp>
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#EFECE4] border border-[#9E7B4F]/40 text-[#9E7B4F] font-mono text-xs font-bold uppercase tracking-widest mb-4 shadow-sm">
              VERIFIED PROOF & AUTHORITY
            </div>
          </FadeUp>
          <FadeUp delay={0.1}>
            <h2 className="font-display font-bold text-3xl sm:text-5xl text-[#181716] tracking-tight mb-4">
              Can you trust FOUND X with your brand?
            </h2>
          </FadeUp>
          <FadeUp delay={0.15}>
            <p className="font-sans text-base text-[#54504A]">
              Fair question. We built this studio under our own name with complete transparency.
            </p>
          </FadeUp>
        </div>

        {/* 4 Proof Metric Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          {proofMetrics.map((item, i) => (
            <FadeUp key={item.label} delay={i * 0.1}>
              <div className="bg-[#EFECE4] p-6 rounded-xl border border-[#9E7B4F]/30 metallic-edge text-center shadow-sm">
                <div className="font-display font-bold text-3xl sm:text-4xl text-[#9E7B4F] mb-2">{item.val}</div>
                <div className="font-sans text-xs font-bold text-[#181716] mb-1">{item.label}</div>
                <div className="font-sans text-xs text-[#54504A] leading-tight">{item.sub}</div>
              </div>
            </FadeUp>
          ))}
        </div>

        {/* Client Recommendations Testimonial Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {clientProofCards.map((client, i) => (
            <FadeUp key={client.name} delay={i * 0.1}>
              <div className="bg-[#FAF8F5] p-6 rounded-xl border border-[#9E7B4F]/25 metallic-edge shadow-md flex flex-col justify-between h-full">
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-2.5 py-1 rounded-md font-bold uppercase tracking-wider">
                      {client.tag}
                    </span>
                    <span className="font-mono text-xs font-bold text-[#9E7B4F]">{client.result}</span>
                  </div>
                  <p className="font-sans italic text-xs text-[#54504A] leading-relaxed mb-6">
                    "{client.quote}"
                  </p>
                </div>
                <div className="pt-4 border-t border-[#9E7B4F]/15 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-[#9E7B4F]/20 border border-[#9E7B4F]/40 flex items-center justify-center font-bold text-xs text-[#9E7B4F]">
                    {client.name[0]}
                  </div>
                  <div>
                    <div className="font-display font-bold text-xs text-[#181716]">{client.name}</div>
                    <div className="font-mono text-xs text-[#54504A]">{client.title}</div>
                  </div>
                </div>
              </div>
            </FadeUp>
          ))}
        </div>

        {/* Verified In-App Screenshots Teaser */}
        <FadeUp delay={0.2}>
          <div className="mt-8 bg-[#EFECE4] border border-[#9E7B4F]/40 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-6 metallic-edge shadow-sm">
            <div className="flex flex-col sm:flex-row items-center gap-5">
              <div className="flex gap-2.5 overflow-hidden">
                <img src="/images/proof/proof-impressions-987k.jpg" alt="Proof 987k Telemetry" className="inline-block h-16 w-20 sm:h-20 sm:w-28 rounded-xl object-cover ring-1 ring-[#9E7B4F]/40 shadow-sm bg-white hover:scale-105 transition-transform" />
                <img src="/images/proof/proof-impressions-612k.jpg" alt="Proof 612k Telemetry" className="inline-block h-16 w-20 sm:h-20 sm:w-28 rounded-xl object-cover ring-1 ring-[#9E7B4F]/40 shadow-sm bg-white hover:scale-105 transition-transform" />
                <img src="/images/proof/proof-impressions-211k.jpg" alt="Proof 211k Telemetry" className="inline-block h-16 w-20 sm:h-20 sm:w-28 rounded-xl object-cover ring-1 ring-[#9E7B4F]/40 shadow-sm bg-white hover:scale-105 transition-transform" />
                <img src="/images/proof/proof-followers-29k.jpg" alt="Proof 29k Telemetry" className="hidden sm:inline-block h-16 w-20 sm:h-20 sm:w-28 rounded-xl object-cover ring-1 ring-[#9E7B4F]/40 shadow-sm bg-white hover:scale-105 transition-transform" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <h3 className="font-display font-bold text-base text-[#181716]">9 Verified In-App LinkedIn Telemetry Proofs</h3>
                </div>
                <p className="font-sans text-xs text-[#54504A] mt-1">987k+ impressions, +10,238% viral spikes & 29k+ decision-maker followers documented with verified metrics.</p>
              </div>
            </div>
            <Link to="/services/linkedin-growth#proof" className="btn-primary text-xs shrink-0 whitespace-nowrap">
              VIEW RAW IN-APP SCREENSHOTS ↗
            </Link>
          </div>
        </FadeUp>
      </div>

      {/* SECTION 3: INTERACTIVE CHAT FAQ & RISK-FREE GUARANTEE */}
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <FadeUp>
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#EFECE4] border border-[#9E7B4F]/40 text-[#9E7B4F] font-mono text-xs font-bold uppercase tracking-widest mb-4 shadow-sm">
              <HelpCircle size={14} /> BEFORE YOU INQUIRE
            </div>
          </FadeUp>
          <FadeUp delay={0.1}>
            <h2 className="font-display font-bold text-3xl sm:text-5xl text-[#181716] tracking-tight mb-4">
              The questions you're already thinking.
            </h2>
          </FadeUp>
        </div>

        {/* Chat FAQ Accordion with Close-Proximity Expansion Control */}
        <div className="space-y-4 mb-12">
          {faqItems.map((item, i) => (
            <FadeUp key={item.q} delay={i * 0.08}>
              <div className="bg-[#EFECE4] rounded-xl border border-[#9E7B4F]/30 overflow-hidden metallic-edge shadow-sm">
                <button
                  onClick={() => setActiveFaq(activeFaq === i ? null : i)}
                  aria-expanded={activeFaq === i}
                  className="w-full p-5 sm:p-6 text-left flex items-center gap-4 cursor-pointer group"
                >
                  <div className="w-8 h-8 rounded-lg bg-[#FAF8F5] border border-[#9E7B4F]/30 flex items-center justify-center shrink-0 text-[#9E7B4F] group-hover:border-[#9E7B4F] transition-colors">
                    <span className="font-mono text-base font-bold leading-none">
                      {activeFaq === i ? '−' : '+'}
                    </span>
                  </div>
                  <span className="font-display font-bold text-base md:text-lg text-[#181716] flex-1">
                    {item.q}
                  </span>
                </button>

                <AnimatePresence>
                  {activeFaq === i && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="px-6 pb-6 pt-2 border-t border-[#9E7B4F]/15 bg-[#FAF8F5]"
                    >
                      <p className="font-sans text-sm text-[#54504A] leading-relaxed">
                        {item.a}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </FadeUp>
          ))}
        </div>

        {/* Growpido-Style Risk Reversal Guarantee Banner */}
        <FadeUp>
          <div className="bg-[#EFECE4] p-8 md:p-10 rounded-2xl border border-[#9E7B4F]/50 metallic-edge text-center shadow-xl">
            <div className="w-12 h-12 rounded-full bg-[#9E7B4F]/15 border border-[#9E7B4F]/40 flex items-center justify-center text-[#9E7B4F] mx-auto mb-4">
              <ShieldCheck size={26} />
            </div>
            <h3 className="font-display font-bold text-2xl md:text-3xl text-[#181716] mb-3">
              Zero-Risk Founder Guarantee
            </h3>
            <p className="font-sans text-sm text-[#54504A] max-w-xl mx-auto leading-relaxed mb-6">
              It is month-to-month after the initial 90 days with a clear exit anytime. If we don't hit the agreed delivery and growth metrics, no invoice for the next month.
            </p>
            <a href="#contact" className="btn-primary">
              SCHEDULE FOUNDER CALL
            </a>
          </div>
        </FadeUp>
      </div>
    </section>
  );
}
