import { useRef, useState, useEffect } from 'react';
import { motion, useMotionValue, useSpring, useTransform, useMotionTemplate } from 'framer-motion';
import { FadeUp } from '../components/ui/FadeUp';
import {
  Cpu,
  TrendingUp,
  Activity,
  Layers,
  Play,
  CheckCircle2,
  Sparkles,
  RefreshCw,
  Globe2,
  Sliders,
  Maximize2,
  Minimize2,
  RotateCcw,
  ArrowUpRight,
  UserCheck,
  Award,
  Move3d,
  PlayCircle,
  PauseCircle,
  Eye,
  Compass,
} from 'lucide-react';

interface SimulationPrompt {
  id: string;
  label: string;
  description: string;
  latency: string;
  steps: {
    node: string;
    text: string;
    status: 'done' | 'active' | 'pending';
    color: string;
  }[];
  resultMetric: string;
}

const simulationPrompts: SimulationPrompt[] = [
  {
    id: 'refactor',
    label: 'Edge Code Refactor',
    description: 'Autonomous patch generation for sub-15ms edge middleware',
    latency: '340ms',
    steps: [
      { node: 'NODE_01', text: 'Telemetry ingestion: Scanning 48 edge microservices across Cloudflare & Vercel', status: 'done', color: 'emerald' },
      { node: 'NODE_02', text: 'Semantic AST parsing: Identified 3 unmemoized render cascades & blocking DB call', status: 'done', color: 'amber' },
      { node: 'NODE_03', text: 'Code generation: Synthesizing zero-allocation Rust WASM edge function', status: 'done', color: 'gold' },
      { node: 'NODE_04', text: 'Test automation: 142/142 unit tests passed in sandbox environment', status: 'done', color: 'emerald' },
    ],
    resultMetric: 'Latency reduced by 64% (38ms → 12.4ms)',
  },
  {
    id: 'rag',
    label: 'RAG Vector Memory',
    description: 'Cross-document semantic intent matching with cosine similarity >0.98',
    latency: '210ms',
    steps: [
      { node: 'VECTOR_01', text: 'Ingesting 10,000 unstructured customer support transcripts & product specs', status: 'done', color: 'emerald' },
      { node: 'VECTOR_02', text: 'Embedding generation: 1,536-dim vectors indexed via HNSW graph algorithm', status: 'done', color: 'amber' },
      { node: 'VECTOR_03', text: 'Multi-query expansion: Semantic distance scored at 0.988 relevance', status: 'done', color: 'gold' },
      { node: 'VECTOR_04', text: 'Context synthesis: Verified grounded output with zero hallucinations', status: 'done', color: 'emerald' },
    ],
    resultMetric: 'Context grounded with 99.8% precision score',
  },
  {
    id: 'lead',
    label: 'Founder Lead Scoring',
    description: 'Autonomous profile enrichment and high-intent inbound routing',
    latency: '185ms',
    steps: [
      { node: 'GROWTH_01', text: 'Webhook triggered: Executive visitor detected from Fortune 500 SaaS group', status: 'done', color: 'emerald' },
      { node: 'GROWTH_02', text: 'Public profile enrichment: Tech stack, headcount growth & funding rounds synced', status: 'done', color: 'amber' },
      { node: 'GROWTH_03', text: 'Intent calculation: High-intent ICP score 96/100 (Budget >$50k)', status: 'done', color: 'gold' },
      { node: 'GROWTH_04', text: 'Automated notification: High-priority brief delivered to Preet Yadav direct line', status: 'done', color: 'emerald' },
    ],
    resultMetric: 'Lead scored and routed in 185ms with VIP calendar link',
  },
];

export function DeviceShowcase() {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Tabs: dashboard, agents, growth
  const [activeTab, setActiveTab] = useState<'dashboard' | 'agents' | 'growth'>('dashboard');

  // Angle presets: '3d' | 'iso' | 'flat' | 'orbit'
  const [anglePreset, setAnglePreset] = useState<'3d' | 'iso' | 'flat' | 'orbit'>('3d');
  const [isExpanded, setIsExpanded] = useState(false);
  const [isAutoOrbit, setIsAutoOrbit] = useState(false);

  // Drag interaction state
  const isDraggingRef = useRef(false);
  const dragStartRef = useRef({ x: 0, y: 0, rotX: 0, rotY: 0 });

  // Simulation state for AI Agents Tab
  const [selectedPromptId, setSelectedPromptId] = useState('refactor');
  const [isSimulating, setIsSimulating] = useState(false);
  const [simulationProgress, setSimulationProgress] = useState(100);

  // Interactive Growth Calculator state
  const [monthlyImpressions, setMonthlyImpressions] = useState(85000);

  // Motion Values for Hardware Physics
  const rotX = useMotionValue(8);
  const rotY = useMotionValue(-6);
  const scale = useMotionValue(1);

  // Fluid Spring Physics
  const springConfig = { damping: 26, stiffness: 200, mass: 0.7 };
  const smoothRotX = useSpring(rotX, springConfig);
  const smoothRotY = useSpring(rotY, springConfig);
  const smoothScale = useSpring(scale, springConfig);

  // Specular Dynamic Glare Sheen calculation
  const glareX = useTransform(smoothRotY, [-30, 30], ['15%', '85%']);
  const glareY = useTransform(smoothRotX, [30, -30], ['15%', '85%']);
  const glareOpacity = useTransform(smoothRotX, (val) => Math.min(0.45, Math.abs(val) / 35 + 0.12));

  // Dynamic Shadow based on tilt
  const shadowX = useTransform(smoothRotY, [-30, 30], [25, -25]);
  const shadowY = useTransform(smoothRotX, [-30, 30], [-25, 45]);
  const dynamicShadow = useMotionTemplate`${shadowX}px ${shadowY}px 90px rgba(0,0,0,0.6), 0 0 50px rgba(158,123,79,0.2)`;

  // Handle Preset Changes
  const applyPreset = (preset: '3d' | 'iso' | 'flat' | 'orbit') => {
    setAnglePreset(preset);
    setIsAutoOrbit(false);

    if (preset === 'flat') {
      rotX.set(0);
      rotY.set(0);
      scale.set(1);
    } else if (preset === 'iso') {
      rotX.set(16);
      rotY.set(-20);
      scale.set(0.98);
    } else if (preset === '3d') {
      rotX.set(7);
      rotY.set(-5);
      scale.set(1);
    } else if (preset === 'orbit') {
      scale.set(1);
    }
  };

  // Auto Orbit Loop
  useEffect(() => {
    if (!isAutoOrbit) return;

    let animId: number;
    let startTime: number | null = null;

    const loop = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const elapsed = timestamp - startTime;
      const t = elapsed * 0.0012;

      // Elegant Lissajous 3D Orbit
      const targetY = Math.sin(t) * 18;
      const targetX = Math.cos(t * 0.7) * 10 + 4;

      rotY.set(targetY);
      rotX.set(targetX);

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [isAutoOrbit, rotX, rotY]);

  // Background 3D Spatial Canvas (Particle Constellation & Depth Grid)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.offsetWidth || 1200);
    let height = (canvas.height = canvas.parentElement?.offsetHeight || 800);

    const handleResize = () => {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.offsetWidth;
      height = canvas.height = canvas.parentElement.offsetHeight;
    };

    window.addEventListener('resize', handleResize);

    // Particle nodes
    interface SpatialNode {
      x: number;
      y: number;
      z: number;
      vx: number;
      vy: number;
    }

    const nodes: SpatialNode[] = [];
    for (let i = 0; i < 35; i++) {
      nodes.push({
        x: (Math.random() - 0.5) * width,
        y: (Math.random() - 0.5) * height,
        z: Math.random() * 600 + 100,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
      });
    }

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      const cx = width / 2;
      const cy = height / 2;
      const currentRotX = (smoothRotX.get() * Math.PI) / 180;
      const currentRotY = (smoothRotY.get() * Math.PI) / 180;

      // Draw subtle connecting 3D spatial web
      ctx.lineWidth = 0.5;

      for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i];
        node.x += node.vx;
        node.y += node.vy;

        // Wrap around bounds
        if (node.x > width / 2) node.x = -width / 2;
        if (node.x < -width / 2) node.x = width / 2;
        if (node.y > height / 2) node.y = -height / 2;
        if (node.y < -height / 2) node.y = height / 2;

        // Apply 3D rotation projection
        const cosY = Math.cos(currentRotY * 0.5);
        const sinY = Math.sin(currentRotY * 0.5);
        const cosX = Math.cos(currentRotX * 0.5);
        const sinX = Math.sin(currentRotX * 0.5);

        const x1 = node.x * cosY + node.z * sinY;
        const z1 = -node.x * sinY + node.z * cosY;
        const y1 = node.y * cosX - z1 * sinX;
        const z2 = node.y * sinX + z1 * cosX + 800;

        const fov = 700;
        const scale2d = fov / (fov + z2);
        const screenX = cx + x1 * scale2d;
        const screenY = cy + y1 * scale2d;

        // Draw node
        ctx.beginPath();
        ctx.arc(screenX, screenY, Math.max(1, 2 * scale2d), 0, Math.PI * 2);
        ctx.fillStyle = `rgba(158, 123, 79, ${0.35 * scale2d})`;
        ctx.fill();

        // Connect with nearby nodes
        for (let j = i + 1; j < nodes.length; j++) {
          const n2 = nodes[j];
          const dx = node.x - n2.x;
          const dy = node.y - n2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 140) {
            const x2_1 = n2.x * cosY + n2.z * sinY;
            const z2_1 = -n2.x * sinY + n2.z * cosY;
            const y2_1 = n2.y * cosX - z2_1 * sinX;
            const z2_2 = n2.y * sinX + z2_1 * cosX + 800;

            const scale2d_2 = fov / (fov + z2_2);
            const sX2 = cx + x2_1 * scale2d_2;
            const sY2 = cy + y2_1 * scale2d_2;

            ctx.beginPath();
            ctx.moveTo(screenX, screenY);
            ctx.lineTo(sX2, sY2);
            ctx.strokeStyle = `rgba(197, 160, 89, ${0.12 * (1 - dist / 140)})`;
            ctx.stroke();
          }
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [smoothRotX, smoothRotY]);

  // Cursor Hover Parallax (active when in '3d' mode and not dragging)
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (isDraggingRef.current) {
      const dx = e.clientX - dragStartRef.current.x;
      const dy = e.clientY - dragStartRef.current.y;
      rotY.set(dragStartRef.current.rotY + dx * 0.35);
      rotX.set(Math.max(-30, Math.min(30, dragStartRef.current.rotX - dy * 0.35)));
      return;
    }

    if (anglePreset !== '3d' || isAutoOrbit) return;
    if (!containerRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;

    // Responsive 3D dynamic tilt range
    rotY.set(x * 20);
    rotX.set(-y * 18);
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    // Only initiate drag if clicking on bezel or background or in orbit mode
    const target = e.target as HTMLElement;
    const isInteractive = target.closest('button, input, a, select, textarea, [role="slider"]');
    if (isInteractive && anglePreset !== 'orbit') return;

    isDraggingRef.current = true;
    setIsAutoOrbit(false);
    dragStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      rotX: rotX.get(),
      rotY: rotY.get(),
    };
  };

  const handleMouseUp = () => {
    if (isDraggingRef.current) {
      isDraggingRef.current = false;
      if (anglePreset === '3d') {
        rotX.set(7);
        rotY.set(-5);
      }
    }
  };

  const handleMouseLeave = () => {
    if (isDraggingRef.current) {
      isDraggingRef.current = false;
    }
    if (anglePreset === '3d' && !isAutoOrbit) {
      rotX.set(7);
      rotY.set(-5);
    }
  };

  // Touch Support for mobile / tablet drag
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    const target = e.target as HTMLElement;
    const isInteractive = target.closest('button, input, a, select, textarea, [role="slider"]');
    if (isInteractive && anglePreset !== 'orbit') return;

    if (e.touches.length === 1) {
      isDraggingRef.current = true;
      setIsAutoOrbit(false);
      dragStartRef.current = {
        x: e.touches[0].clientX,
        y: e.touches[0].clientY,
        rotX: rotX.get(),
        rotY: rotY.get(),
      };
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!isDraggingRef.current || e.touches.length !== 1) return;
    const dx = e.touches[0].clientX - dragStartRef.current.x;
    const dy = e.touches[0].clientY - dragStartRef.current.y;
    rotY.set(dragStartRef.current.rotY + dx * 0.35);
    rotX.set(Math.max(-30, Math.min(30, dragStartRef.current.rotX - dy * 0.35)));
  };

  const handleTouchEnd = () => {
    isDraggingRef.current = false;
  };

  // Run AI Simulation
  const runSimulation = () => {
    if (isSimulating) return;
    setIsSimulating(true);
    setSimulationProgress(15);
    const t1 = setTimeout(() => setSimulationProgress(45), 300);
    const t2 = setTimeout(() => setSimulationProgress(75), 650);
    const t3 = setTimeout(() => {
      setSimulationProgress(100);
      setIsSimulating(false);
    }, 1000);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  };

  const handleSelectPrompt = (id: string) => {
    setSelectedPromptId(id);
    runSimulation();
  };

  const activePrompt = simulationPrompts.find((p) => p.id === selectedPromptId) || simulationPrompts[0];

  // Dynamic Growth Calculations
  const estQualifiedLeads = Math.max(2, Math.round((monthlyImpressions / 10000) * 3.8));
  const estPipelineValue = estQualifiedLeads * 14500;
  const sliderPercentage = Math.round(((monthlyImpressions - 10000) / (350000 - 10000)) * 100);

  return (
    <section
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseDown={handleMouseDown}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseLeave}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      id="3d-showcase"
      className="py-16 md:py-24 px-margin-mobile md:px-margin-desktop w-full max-w-container-max mx-auto relative overflow-hidden bg-[#F6F3EC] select-none"
    >
      {/* Background 3D Spatial Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none opacity-60 z-0"
      />

      {/* Section Header */}
      <div className="text-center max-w-3xl mx-auto mb-8 relative z-10">
        <FadeUp>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#EFECE4] border border-[#9E7B4F]/40 text-[#9E7B4F] font-mono text-xs font-bold uppercase tracking-widest mb-4 shadow-sm">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            FOUND X SPATIAL HARDWARE OS v4.2
          </div>
        </FadeUp>
        <FadeUp delay={0.1}>
          <h2 className="font-display font-bold text-3xl sm:text-5xl md:text-6xl text-[#181716] tracking-tight leading-tight mb-4">
            Engineered for <span className="text-[#9E7B4F] drop-shadow-[0_4px_25px_rgba(158,123,79,0.25)]">absolute precision.</span>
          </h2>
        </FadeUp>
        <FadeUp delay={0.15}>
          <p className="font-sans text-base md:text-lg text-[#54504A] leading-relaxed">
            Interact with our ultra-crisp studio spatial tablet in real-time 3D. Drag to orbit, hover to tilt, and toggle between real-time engineering velocity, autonomous AI agent simulations, and dynamic founder growth economics.
          </p>
        </FadeUp>
      </div>

      {/* 3D Control Center Bar with Unified Heights and Logical Grouping */}
      <div className="flex flex-wrap justify-center items-center gap-3 mb-5 relative z-20">
        {/* Camera Angle Segmented Group */}
        <div className="bg-[#EFECE4] border border-[#9E7B4F]/30 p-1 rounded-xl flex items-center gap-1 shadow-sm font-mono text-xs">
          <button
            onClick={() => applyPreset('3d')}
            className={`h-10 px-3.5 rounded-lg font-bold transition-all cursor-pointer inline-flex items-center gap-2 ${
              anglePreset === '3d' && !isAutoOrbit
                ? 'bg-[#9E7B4F] text-white shadow-sm'
                : 'text-[#54504A] hover:text-[#181716]'
            }`}
          >
            <Move3d size={14} />
            <span>3D DYNAMIC</span>
          </button>
          <button
            onClick={() => applyPreset('iso')}
            className={`h-10 px-3.5 rounded-lg font-bold transition-all cursor-pointer inline-flex items-center gap-2 ${
              anglePreset === 'iso' && !isAutoOrbit
                ? 'bg-[#9E7B4F] text-white shadow-sm'
                : 'text-[#54504A] hover:text-[#181716]'
            }`}
          >
            <Layers size={14} />
            <span>ISOMETRIC</span>
          </button>
          <button
            onClick={() => applyPreset('orbit')}
            className={`h-10 px-3.5 rounded-lg font-bold transition-all cursor-pointer inline-flex items-center gap-2 ${
              anglePreset === 'orbit' && !isAutoOrbit
                ? 'bg-[#9E7B4F] text-white shadow-sm'
                : 'text-[#54504A] hover:text-[#181716]'
            }`}
          >
            <Compass size={14} />
            <span>FREE ORBIT</span>
          </button>
          <button
            onClick={() => applyPreset('flat')}
            className={`h-10 px-3.5 rounded-lg font-bold transition-all cursor-pointer inline-flex items-center gap-2 ${
              anglePreset === 'flat' && !isAutoOrbit
                ? 'bg-[#9E7B4F] text-white shadow-sm'
                : 'text-[#54504A] hover:text-[#181716]'
            }`}
          >
            <Eye size={14} />
            <span>RETINA 2D</span>
          </button>
        </div>

        {/* Action Controls Group */}
        <div className="flex items-center gap-2">
          {/* Auto Orbit Tour Button */}
          <button
            onClick={() => {
              setIsAutoOrbit(!isAutoOrbit);
              if (!isAutoOrbit) setAnglePreset('3d');
            }}
            className={`h-10 inline-flex items-center gap-2 px-3.5 rounded-xl border text-xs font-mono font-bold transition-colors shadow-sm cursor-pointer ${
              isAutoOrbit
                ? 'bg-[#9E7B4F] text-white border-[#9E7B4F]'
                : 'bg-[#EFECE4] border-[#9E7B4F]/30 text-[#181716] hover:border-[#9E7B4F]'
            }`}
          >
            {isAutoOrbit ? <PauseCircle size={14} /> : <PlayCircle size={14} />}
            <span>{isAutoOrbit ? 'ORBITING...' : 'AUTO TOUR'}</span>
          </button>

          {/* Reset Button */}
          <button
            onClick={() => applyPreset('3d')}
            className="h-10 inline-flex items-center gap-2 px-3.5 rounded-xl bg-[#EFECE4] border border-[#9E7B4F]/30 text-xs font-mono font-bold text-[#181716] hover:border-[#9E7B4F] transition-colors shadow-sm cursor-pointer"
          >
            <RotateCcw size={14} />
            <span>RESET</span>
          </button>

          {/* Expand / Compact Toggle */}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="h-10 inline-flex items-center gap-2 px-3.5 rounded-xl bg-[#EFECE4] border border-[#9E7B4F]/30 text-xs font-mono font-bold text-[#181716] hover:border-[#9E7B4F] transition-colors shadow-sm cursor-pointer"
          >
            {isExpanded ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
            <span>{isExpanded ? 'COMPACT' : 'EXPAND VIEW'}</span>
          </button>
        </div>
      </div>

      {/* Telemetry Status & Interaction Guidance Bar (Separated & Non-Overlapping) */}
      <div className={`flex flex-col sm:flex-row justify-between items-center gap-3 mb-6 relative z-20 mx-auto px-2 transition-all duration-500 ${
        isExpanded ? 'max-w-7xl' : 'max-w-5xl'
      }`}>
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#EFECE4] border border-[#9E7B4F]/30 text-xs font-mono text-[#54504A] font-semibold uppercase tracking-wider shadow-sm">
          <span className="w-2 h-2 rounded-full bg-[#9E7B4F] animate-ping" />
          <span>Click & drag to orbit • Click screen tabs to test</span>
        </div>

        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#16151c] border border-[#C5A059]/60 shadow-[0_4px_15px_rgba(0,0,0,0.25)]">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs font-mono font-bold text-[#C5A059] tracking-wider uppercase">
            60 FPS HARDWARE ACCELERATED
          </span>
        </div>
      </div>

      {/* 3D Perspective Viewport */}
      <div
        className={`relative w-full flex justify-center [perspective:1400px] py-4 transition-all duration-500 ${
          isExpanded ? 'max-w-7xl' : 'max-w-5xl'
        } mx-auto z-10 cursor-grab active:cursor-grabbing`}
        style={{ transformStyle: 'preserve-3d' }}
      >
        {/* Ambient Warm Gold Glow Backdrop */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4/5 h-4/5 bg-[#9E7B4F]/25 blur-[140px] rounded-full pointer-events-none" />

        {/* Photorealistic Titanium Hardware Chassis */}
        <motion.div
          style={{
            rotateX: smoothRotX,
            rotateY: smoothRotY,
            scale: smoothScale,
            boxShadow: dynamicShadow,
            transformStyle: 'preserve-3d',
          }}
          className="w-full bg-gradient-to-b from-[#24222c] via-[#141319] to-[#0c0b10] border-2 border-[#9E7B4F]/60 rounded-[36px] md:rounded-[48px] p-3 md:p-5 relative z-10 transition-shadow duration-300"
        >
          {/* Subtle Chamfered Metallic Edge Reflection */}
          <div className="absolute inset-0 rounded-[36px] md:rounded-[48px] border border-white/20 pointer-events-none z-20" />
          <div className="absolute inset-1 rounded-[34px] md:rounded-[46px] border border-black/80 pointer-events-none z-20" />

          {/* Screen Display Housing */}
          <div
            className="w-full bg-[#0d0d12] rounded-[26px] md:rounded-[38px] overflow-hidden border border-white/15 relative flex flex-col min-h-[580px] md:min-h-[660px] shadow-2xl z-10"
            style={{ transformStyle: 'preserve-3d' }}
          >
            {/* Dynamic Specular Glass Glare Sheen */}
            <motion.div
              style={{
                background: useMotionTemplate`radial-gradient(circle at ${glareX} ${glareY}, rgba(255,255,255,0.18) 0%, rgba(197,160,89,0.06) 40%, transparent 65%)`,
                opacity: glareOpacity,
              }}
              className="absolute inset-0 pointer-events-none z-30 rounded-[26px] md:rounded-[38px] transition-opacity"
            />

            {/* Tablet Hardware Top Status Bar */}
            <div className="w-full bg-[#16151c]/95 backdrop-blur-xl border-b border-white/10 px-5 md:px-8 py-3.5 flex items-center justify-between z-20 relative">
              {/* Left: Camera Sensor Notch & Studio OS Badge */}
              <div className="flex items-center gap-3">
                <div className="w-4 h-4 rounded-full bg-[#050508] border border-white/25 flex items-center justify-center shadow-inner">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#C5A059] animate-pulse" />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-display font-bold text-white tracking-wider">
                    FOUND X
                  </span>
                  <span className="text-xs font-mono text-[#C5A059] bg-[#C5A059]/15 px-2 py-0.5 rounded border border-[#C5A059]/30 font-semibold hidden sm:inline">
                    SPATIAL OS 4.2
                  </span>
                </div>
              </div>

              {/* Center: Segmented App Switcher Tabs */}
              <div className="flex items-center gap-1.5 bg-[#0a090e] p-1 rounded-xl border border-white/15 shadow-inner">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveTab('dashboard');
                  }}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-sans font-bold transition-all flex items-center gap-2 cursor-pointer ${
                    activeTab === 'dashboard'
                      ? 'bg-gradient-to-r from-[#9E7B4F] to-[#C5A059] text-white shadow-[0_0_15px_rgba(197,160,89,0.5)]'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  <Activity size={14} /> <span>DASHBOARD</span>
                </button>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveTab('agents');
                  }}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-sans font-bold transition-all flex items-center gap-2 cursor-pointer ${
                    activeTab === 'agents'
                      ? 'bg-gradient-to-r from-[#9E7B4F] to-[#C5A059] text-white shadow-[0_0_15px_rgba(197,160,89,0.5)]'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  <Cpu size={14} /> <span>AI AGENTS</span>
                </button>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveTab('growth');
                  }}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-sans font-bold transition-all flex items-center gap-2 cursor-pointer ${
                    activeTab === 'growth'
                      ? 'bg-gradient-to-r from-[#9E7B4F] to-[#C5A059] text-white shadow-[0_0_15px_rgba(197,160,89,0.5)]'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  <TrendingUp size={14} /> <span>GROWTH</span>
                </button>
              </div>

              {/* Right: Live Telemetry Indicator */}
              <div className="flex items-center gap-2 bg-emerald-950/60 border border-emerald-500/40 px-3 py-1 rounded-full shadow-sm">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs text-emerald-300 font-mono font-bold tracking-wider hidden md:inline">
                  99.98% SLA
                </span>
              </div>
            </div>

            {/* Tablet Screen Display Content */}
            <div className="flex-1 p-6 md:p-8 flex flex-col justify-between relative bg-gradient-to-b from-[#111017] via-[#0d0c12] to-[#070609]">
              {/* TAB 1: PRODUCT DASHBOARD */}
              {activeTab === 'dashboard' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  {/* Top Stats Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {[
                      { label: 'Edge RPS', val: '42,910', delta: '+18.4%', good: true },
                      { label: 'Avg Latency', val: '12.4ms', delta: '-4.2ms', good: true },
                      { label: 'Error Budget', val: '99.99%', delta: '0.00%', good: true },
                      { label: 'Active Sessions', val: '8,421', delta: '+340', good: true },
                    ].map((stat) => (
                      <div
                        key={stat.label}
                        className="bg-[#181721] p-4 rounded-xl border border-white/10 space-y-1 shadow-md hover:border-[#9E7B4F]/40 transition-colors"
                      >
                        <span className="text-zinc-400 text-xs font-mono uppercase">{stat.label}</span>
                        <div className="font-display font-bold text-xl md:text-2xl text-white">{stat.val}</div>
                        <span className="text-xs font-mono text-emerald-400 font-bold block">{stat.delta}</span>
                      </div>
                    ))}
                  </div>

                  {/* System Performance Velocity Chart */}
                  <div className="bg-[#181721] p-6 rounded-2xl border border-white/10 space-y-4 shadow-lg">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <Activity size={18} className="text-[#C5A059]" />
                        <h3 className="font-display font-bold text-base md:text-lg text-white">
                          Edge Latency Velocity (ms)
                        </h3>
                      </div>
                      <span className="font-mono text-xs text-[#C5A059] bg-[#9E7B4F]/20 px-3 py-1 rounded-full border border-[#9E7B4F]/40 font-bold uppercase tracking-wider w-fit">
                        SUB-FRAME TELEMETRY
                      </span>
                    </div>

                    {/* Interactive Chart Bars */}
                    <div className="h-36 flex items-end justify-between gap-2.5 pt-6 border-b border-white/10 pb-3">
                      {[18.2, 16.4, 15.1, 14.2, 13.8, 12.9, 12.4, 12.1, 11.9, 12.4, 11.8, 11.2].map((ms, i) => (
                        <div key={i} className="flex-1 flex flex-col items-center gap-1.5 group relative cursor-pointer">
                          <div className="absolute -top-7 opacity-0 group-hover:opacity-100 transition-opacity bg-black border border-[#9E7B4F] px-2 py-0.5 rounded text-xs font-mono text-[#C5A059] pointer-events-none whitespace-nowrap z-30">
                            {ms} ms
                          </div>
                          <div
                            className="w-full bg-gradient-to-t from-[#9E7B4F]/30 via-[#9E7B4F] to-[#C5A059] rounded-t-md transition-all duration-300 group-hover:brightness-125 shadow-[0_0_12px_rgba(197,160,89,0.3)]"
                            style={{ height: `${(25 - ms) * 6 + 15}%` }}
                          />
                          <span className="text-xs font-mono text-zinc-400 group-hover:text-white hidden sm:inline">
                            T{i + 1}
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* Edge Nodes Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
                      {[
                        { region: 'US-East (Virginia)', ping: '9ms', status: 'Optimal' },
                        { region: 'EU-Central (Frankfurt)', ping: '14ms', status: 'Optimal' },
                        { region: 'AP-South (Mumbai)', ping: '11ms', status: 'Optimal' },
                        { region: 'AP-East (Tokyo)', ping: '16ms', status: 'Optimal' },
                      ].map((node) => (
                        <div key={node.region} className="bg-[#121118] p-2.5 rounded-xl border border-white/5 text-xs font-sans">
                          <div className="text-zinc-400 truncate text-xs">{node.region}</div>
                          <div className="flex justify-between items-center mt-1">
                            <span className="text-[#C5A059] font-mono font-bold">{node.ping}</span>
                            <span className="text-emerald-400 text-xs font-semibold">{node.status}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {/* TAB 2: AI AGENTS TERMINAL & SIMULATOR */}
              {activeTab === 'agents' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-5"
                >
                  {/* Scenario Selectors */}
                  <div className="bg-[#181721] p-4 rounded-2xl border border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg">
                    <div>
                      <h4 className="font-display font-bold text-base md:text-lg text-white flex items-center gap-2">
                        <Cpu size={18} className="text-[#C5A059]" /> AUTONOMOUS AGENT REASONING ENGINE
                      </h4>
                      <p className="font-sans text-xs text-zinc-400 mt-0.5">Select scenario to simulate real-time multi-agent execution</p>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        runSimulation();
                      }}
                      disabled={isSimulating}
                      className="bg-gradient-to-r from-[#9E7B4F] to-[#C5A059] hover:brightness-110 text-white px-4 py-2 rounded-xl text-xs font-sans font-bold flex items-center gap-2 transition-all cursor-pointer shadow-md disabled:opacity-50"
                    >
                      {isSimulating ? <RefreshCw size={14} className="animate-spin" /> : <Play size={14} />}
                      <span>{isSimulating ? 'EXECUTING...' : 'RUN SIMULATION'}</span>
                    </button>
                  </div>

                  {/* Prompt Preset Tabs */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    {simulationPrompts.map((prompt) => (
                      <button
                        key={prompt.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSelectPrompt(prompt.id);
                        }}
                        className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer font-sans ${
                          selectedPromptId === prompt.id
                            ? 'bg-[#22212e] border-[#C5A059] shadow-md ring-1 ring-[#C5A059]/40'
                            : 'bg-[#14131b] border-white/5 text-zinc-400 hover:text-zinc-200 hover:border-white/15'
                        }`}
                      >
                        <div className="font-bold text-[#C5A059] text-xs mb-1">{prompt.label}</div>
                        <div className="text-xs text-zinc-400 line-clamp-1 leading-relaxed">{prompt.description}</div>
                      </button>
                    ))}
                  </div>

                  {/* Terminal Log Output */}
                  <div className="bg-[#09080d] rounded-2xl p-5 border border-white/15 font-mono text-xs text-zinc-200 space-y-3 shadow-2xl relative overflow-hidden">
                    {/* Execution Progress Bar */}
                    <div className="w-full bg-zinc-800/80 h-1.5 rounded-full overflow-hidden mb-3">
                      <motion.div
                        className="h-full bg-gradient-to-r from-[#9E7B4F] via-[#C5A059] to-emerald-400"
                        style={{ width: `${simulationProgress}%` }}
                        transition={{ duration: 0.2 }}
                      />
                    </div>

                    <div className="flex justify-between items-center text-[#C5A059] font-bold text-xs pb-2 border-b border-white/10">
                      <div className="flex items-center gap-2">
                        <div className="flex gap-1.5">
                          <div className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                          <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
                          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                        </div>
                        <span className="font-mono text-zinc-300 ml-2">session_trc_{activePrompt.id}.log</span>
                      </div>
                      <span className="text-zinc-400 text-xs font-mono">P99: {activePrompt.latency}</span>
                    </div>

                    {/* Step Logs */}
                    <div className="space-y-2 pt-1">
                      {activePrompt.steps.map((step, idx) => (
                        <motion.div
                          key={idx}
                          initial={{ opacity: 0, x: -6 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: idx * 0.08 }}
                          className={`pl-3 border-l-2 text-xs leading-relaxed ${
                            step.color === 'emerald'
                              ? 'border-emerald-400 text-emerald-300'
                              : step.color === 'amber'
                              ? 'border-amber-400 text-amber-200'
                              : 'border-[#C5A059] text-[#C5A059]'
                          }`}
                        >
                          <span className="font-bold mr-1.5">[{step.node}]</span>
                          <span>{step.text}</span>
                        </motion.div>
                      ))}
                    </div>

                    {/* Result Output Card */}
                    <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs bg-emerald-950/40 p-3 rounded-xl border border-emerald-500/30">
                      <div className="flex items-center gap-2 text-emerald-300 font-bold font-sans">
                        <Sparkles size={16} className="text-emerald-400" />
                        <span>{activePrompt.resultMetric}</span>
                      </div>
                      <span className="text-emerald-400 font-mono text-xs font-bold">100% PRECISION</span>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* TAB 3: GROWTH CALCULATOR & AUTHORITY ENGINE */}
              {activeTab === 'growth' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-5"
                >
                  {/* Luxury Slider Box */}
                  <div className="bg-[#181721] p-6 rounded-2xl border border-white/10 space-y-4 shadow-xl">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 rounded-lg bg-[#9E7B4F]/20 text-[#C5A059]">
                          <Sliders size={18} />
                        </div>
                        <div>
                          <h3 className="font-display font-bold text-base md:text-lg text-white">
                            Founder Reach & Pipeline Modeler
                          </h3>
                          <p className="font-sans text-xs text-zinc-400">
                            Slide to calculate your monthly inbound deals and commercial pipeline value
                          </p>
                        </div>
                      </div>

                      {/* Glowing Metric Badge */}
                      <div className="bg-gradient-to-r from-[#9E7B4F]/25 to-[#C5A059]/25 border border-[#C5A059]/50 px-4 py-1.5 rounded-full shadow-[0_0_15px_rgba(197,160,89,0.2)] flex items-center gap-2 self-start sm:self-auto">
                        <span className="w-2 h-2 rounded-full bg-[#C5A059] animate-pulse" />
                        <span className="font-display font-bold text-sm text-[#FAF8F5] tracking-wide">
                          {monthlyImpressions.toLocaleString()}
                        </span>
                        <span className="font-mono text-xs text-zinc-400 uppercase">IMPRESSIONS / MO</span>
                      </div>
                    </div>

                    {/* Custom Styled Gold Range Slider */}
                    <div className="pt-2 pb-1">
                      <input
                        type="range"
                        min={10000}
                        max={350000}
                        step={5000}
                        value={monthlyImpressions}
                        onChange={(e) => setMonthlyImpressions(Number(e.target.value))}
                        onClick={(e) => e.stopPropagation()}
                        onMouseDown={(e) => e.stopPropagation()}
                        onTouchStart={(e) => e.stopPropagation()}
                        className="gold-slider cursor-grab active:cursor-grabbing"
                        style={{
                          background: `linear-gradient(90deg, #9E7B4F 0%, #C5A059 ${sliderPercentage}%, #22212c ${sliderPercentage}%)`,
                        }}
                      />
                    </div>

                    {/* Quick Preset Buttons */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                      {[
                        { label: '25k (Seed Stage)', val: 25000 },
                        { label: '85k (Authority Tier)', val: 85000 },
                        { label: '180k (Scale Engine)', val: 180000 },
                        { label: '350k+ (Category Leader)', val: 350000 },
                      ].map((preset) => (
                        <button
                          key={preset.val}
                          onClick={(e) => {
                            e.stopPropagation();
                            setMonthlyImpressions(preset.val);
                          }}
                          className={`text-xs px-3 py-1 rounded-lg font-sans font-medium transition-all cursor-pointer border ${
                            monthlyImpressions === preset.val
                              ? 'bg-[#C5A059]/20 border-[#C5A059] text-white shadow-sm font-semibold'
                              : 'bg-[#121118] border-white/5 text-zinc-400 hover:text-white hover:border-white/20'
                          }`}
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Calculated Metric Output Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Metric Card 1: Qualified Inbound Deals */}
                    <div className="bg-[#181721] p-5 rounded-2xl border border-white/10 space-y-3 shadow-lg relative overflow-hidden group hover:border-[#9E7B4F]/50 transition-all">
                      <div className="flex justify-between items-start">
                        <span className="font-mono text-xs text-zinc-400 uppercase tracking-wider font-semibold">
                          EST. QUALIFIED INBOUND DEALS / MO
                        </span>
                        <div className="p-1.5 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          <UserCheck size={14} />
                        </div>
                      </div>

                      <div className="flex items-baseline gap-3">
                        <span className="text-3xl md:text-5xl font-display font-bold text-white tracking-tight">
                          {estQualifiedLeads}+
                        </span>
                        <span className="text-xs font-sans font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-1 rounded-full flex items-center gap-1">
                          <TrendingUp size={12} /> High-Ticket Inbounds
                        </span>
                      </div>

                      <p className="font-sans text-xs text-zinc-300 leading-relaxed">
                        Decision makers (CTOs, Founders, Heads of Product) initiating qualified sales conversations directly with you.
                      </p>

                      <div className="pt-2 border-t border-white/5 flex items-center justify-between text-xs font-sans text-zinc-400">
                        <span>ICP Target Accuracy:</span>
                        <span className="text-emerald-400 font-bold">96.4% Verified</span>
                      </div>
                    </div>

                    {/* Metric Card 2: Estimated Pipeline Value */}
                    <div className="bg-[#181721] p-5 rounded-2xl border border-white/10 space-y-3 shadow-lg relative overflow-hidden group hover:border-[#C5A059]/50 transition-all">
                      <div className="flex justify-between items-start">
                        <span className="font-mono text-xs text-zinc-400 uppercase tracking-wider font-semibold">
                          EST. MONTHLY PIPELINE VALUE
                        </span>
                        <div className="p-1.5 rounded-md bg-[#C5A059]/15 text-[#C5A059] border border-[#C5A059]/30">
                          <Award size={14} />
                        </div>
                      </div>

                      <div className="flex items-baseline gap-2">
                        <span className="text-3xl md:text-5xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#FAF8F5] via-[#C5A059] to-[#9E7B4F] tracking-tight">
                          ${estPipelineValue.toLocaleString()}
                        </span>
                      </div>

                      <p className="font-sans text-xs text-zinc-300 leading-relaxed">
                        Calculated at benchmark $14,500 contract deal size with 22% founder-led conversion velocity.
                      </p>

                      <div className="pt-2 border-t border-white/5 flex items-center justify-between text-xs font-sans text-zinc-400">
                        <span>Compound Revenue Multiplier:</span>
                        <span className="text-[#C5A059] font-bold">4.8x Efficiency</span>
                      </div>
                    </div>
                  </div>

                  {/* Director Contact Row */}
                  <div className="bg-gradient-to-r from-[#181721] via-[#1c1a26] to-[#181721] p-5 rounded-2xl border border-[#9E7B4F]/40 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
                    <div className="flex items-center gap-4">
                      {/* Avatar Seal */}
                      <div className="relative">
                        <div className="w-13 h-13 rounded-full bg-[#121118] border-2 border-[#C5A059] p-0.5 shadow-md flex items-center justify-center">
                          <img
                            src="/images/foundx-logo.png"
                            alt="FOUND X Seal Emblem"
                            className="w-full h-full object-contain rounded-full"
                          />
                        </div>
                        <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-[#181721] flex items-center justify-center">
                          <CheckCircle2 size={10} className="text-black" />
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-display font-bold text-base text-white">Preet Yadav</span>
                          <span className="font-mono text-xs bg-[#9E7B4F]/20 text-[#C5A059] border border-[#9E7B4F]/30 px-2 py-0.5 rounded font-bold uppercase">
                            STUDIO DIRECTOR
                          </span>
                        </div>
                        <p className="font-sans text-xs text-zinc-300 mt-0.5">
                          50+ Products Shipped · ₹22 Crore in Client POs Opened · Gurugram / NCR
                        </p>
                      </div>
                    </div>

                    <a
                      href="#contact"
                      onClick={(e) => e.stopPropagation()}
                      className="bg-gradient-to-r from-[#9E7B4F] to-[#C5A059] hover:brightness-110 text-white py-3 px-6 text-xs font-sans font-bold uppercase tracking-wider rounded-xl transition-all shadow-[0_4px_20px_rgba(158,123,79,0.35)] w-full sm:w-auto text-center flex items-center justify-center gap-2 shrink-0 cursor-pointer"
                    >
                      <span>RESERVE ADVISORY SLOT</span>
                      <ArrowUpRight size={14} />
                    </a>
                  </div>
                </motion.div>
              )}

              {/* Bottom Telemetry Footer */}
              <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row justify-between items-center text-xs font-mono text-zinc-400 gap-2">
                <div className="flex items-center gap-2">
                  <Globe2 size={13} className="text-[#C5A059]" />
                  <span className="text-zinc-300">FOUND X STUDIO SPATIAL OS</span>
                </div>
                <div className="flex items-center gap-3 text-xs">
                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" /> RETINA CRISP RENDER
                  </span>
                  <span className="text-zinc-400">•</span>
                  <span className="text-[#C5A059] font-bold">SUB-FRAME 16MS ENGINE</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
