import { Link } from 'react-router-dom';

import { FadeUp } from '../components/ui/FadeUp';
import { Code2, Cpu, TrendingUp, UserCheck, ArrowRight, CheckCircle2 } from 'lucide-react';
import { GrowpidoProofFAQ } from '../components/GrowpidoProofFAQ';

export function ServicesPage() {
  const servicePillars = [
    {
      id: 'web-app-development',
      path: '/services/web-app-development',
      title: 'Web & App Development',
      subtitle: 'Engineered for Sub-Frame Edge Speed',
      icon: Code2,
      category: 'ENGINEERING',
      tagline: 'High-performance React 19, Next.js 15, Node.js, and mobile applications built with zero compromise.',
      features: [
        'Custom Web Applications & SaaS Platforms',
        'Cross-Platform iOS & Android Apps',
        'Sub-frame Latency & Edge Rendering Optimization',
        'API Design & Serverless Microservices',
      ],
      metrics: '12.4ms Latency • 100% Precision',
      bgImg: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1200&q=80',
    },
    {
      id: 'ai-automation',
      path: '/services/ai-automation',
      title: 'AI Agents & Automation Lab',
      subtitle: 'Autonomous Multi-Node Reasoning Engines',
      icon: Cpu,
      category: 'INTELLIGENCE',
      tagline: 'Deploy custom AI agents, RAG vector pipelines, and automated workflow telemetry to multiply leverage.',
      features: [
        'Autonomous Multi-Agent Orchestration',
        'RAG Vector Search & Semantic Memory',
        'Custom LLM Integration & Fine-Tuning',
        'Enterprise Telemetry & Automated Pipelines',
      ],
      metrics: '410ms Task Resolution • 4 Active Nodes',
      bgImg: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    },
    {
      id: 'linkedin-growth',
      path: '/services/linkedin-growth',
      title: 'LinkedIn Growth & Authority Engine',
      subtitle: 'Positioning Founders into Inbound Magnets',
      icon: TrendingUp,
      category: 'ORGANIC REACH',
      tagline: 'Technical narrative positioning and organic lead engines that turn passive profiles into high-ticket pipeline.',
      features: [
        'Technical Thought Leadership Positioning',
        'Inbound Lead Engine Architecture',
        'Viral Organic Content Strategy',
        'Founder Profile Authority Redesign',
      ],
      metrics: '2.4M+ Impressions • 4.8x Conversion Rate',
      bgImg: 'https://images.unsplash.com/photo-1611095790444-1dfa35e37b52?auto=format&fit=crop&w=1200&q=80',
    },
    {
      id: 'personal-branding',
      path: '/services/personal-branding',
      title: 'Personal Branding & Founder Advisory',
      subtitle: 'Architectural Brand Strategy for Visionaries',
      icon: UserCheck,
      category: 'AUTHORITY',
      tagline: 'Strategic personal brand architecture for technical founders, CTOs, and high-performance leaders.',
      features: [
        'Founder Narrative & Positioning Blueprint',
        'Executive Personal Media Architecture',
        'Keynote & Technical Presentation Design',
        'Strategic Investor & Client Pitch Alignment',
      ],
      metrics: '50+ Founders Guided • Top 1% Reach',
      bgImg: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=1200&q=80',
    },
  ];

  return (
    <div className="py-20 md:py-28 px-margin-mobile md:px-margin-desktop max-w-container-max mx-auto bg-[#F6F3EC] text-[#181716]">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <FadeUp>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#EFECE4] border border-[#9E7B4F]/40 text-[#9E7B4F] font-mono text-xs font-bold uppercase tracking-widest mb-4 shadow-sm">
            DEDICATED SERVICES PORTFOLIO
          </div>
        </FadeUp>
        <FadeUp delay={0.1}>
          <h1 className="font-display font-bold text-4xl sm:text-6xl md:text-7xl text-[#181716] tracking-tight leading-tight mb-6">
            Engineered to <span className="text-[#9E7B4F]">build, scale & dominate.</span>
          </h1>
        </FadeUp>
        <FadeUp delay={0.15}>
          <p className="font-sans text-lg text-[#54504A] leading-relaxed">
            Click on any service pillar below to explore dedicated technical specifications, case study metrics, and execution workflows.
          </p>
        </FadeUp>
      </div>

      {/* Service Pillars Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20">
        {servicePillars.map((service, index) => {
          const Icon = service.icon;
          return (
            <FadeUp key={service.id} delay={index * 0.1}>
              <Link to={service.path} className="block group">
                <div className="bg-[#EFECE4] rounded-2xl p-8 metallic-edge border border-[#9E7B4F]/30 hover:border-[#9E7B4F] transition-all duration-500 shadow-[0_10px_35px_rgba(158,123,79,0.08)] group-hover:shadow-[0_20px_50px_rgba(158,123,79,0.2)] h-full flex flex-col justify-between">
                  <div>
                    {/* Top Row */}
                    <div className="flex justify-between items-center mb-6">
                      <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1 rounded border border-[#9E7B4F]/25 font-bold uppercase tracking-wider">
                        {service.category}
                      </span>
                      <div className="w-12 h-12 rounded-full bg-[#FAF8F5] border border-[#9E7B4F]/30 flex items-center justify-center text-[#9E7B4F] group-hover:bg-[#9E7B4F] group-hover:text-white transition-all shadow-sm">
                        <Icon size={22} />
                      </div>
                    </div>

                    <h2 className="font-display font-bold text-2xl md:text-3xl text-[#181716] group-hover:text-[#9E7B4F] transition-colors mb-2">
                      {service.title}
                    </h2>
                    <p className="font-mono text-xs text-[#8B693C] font-semibold mb-4">
                      {service.subtitle}
                    </p>
                    <p className="font-sans text-sm text-[#54504A] leading-relaxed mb-6">
                      {service.tagline}
                    </p>

                    {/* Features Bullet Points */}
                    <div className="space-y-2.5 mb-8 border-t border-[#9E7B4F]/20 pt-6">
                      {service.features.map((feat) => (
                        <div key={feat} className="flex items-start gap-2.5 text-xs font-sans text-[#181716]">
                          <CheckCircle2 size={15} className="text-[#9E7B4F] shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Bottom Action Footer */}
                  <div className="pt-6 border-t border-[#9E7B4F]/20 flex justify-between items-center">
                    <span className="font-mono text-xs text-[#54504A] font-bold">
                      {service.metrics}
                    </span>
                    <div className="inline-flex items-center gap-2 text-xs font-mono font-bold text-[#9E7B4F] uppercase tracking-wider group-hover:translate-x-1 transition-transform">
                      <span>Explore Service</span>
                      <ArrowRight size={16} />
                    </div>
                  </div>
                </div>
              </Link>
            </FadeUp>
          );
        })}
      </div>

      {/* Growpido Proof & FAQ Component */}
      <GrowpidoProofFAQ />
    </div>
  );
}
