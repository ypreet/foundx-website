import { useState } from 'react';
import { FadeUp } from '../components/ui/FadeUp';
import {
  Cpu,
  Terminal,
  Play,
  CheckCircle2,
  Sparkles,
  RefreshCw,
  Code2,
  TrendingUp,
  Database,
  Sliders,
  Check,
} from 'lucide-react';

interface AgentWorkflow {
  id: string;
  name: string;
  codename: string;
  tagline: string;
  icon: typeof Cpu;
  status: string;
  latency: string;
  confidence: string;
  inputExample: string;
  outputPayload: string;
  steps: {
    phase: string;
    action: string;
    details: string;
    speed: string;
  }[];
}

const agentList: AgentWorkflow[] = [
  {
    id: 'agent-sales',
    name: 'Autonomous Lead Qualifier',
    codename: 'AGENT_01 // INBOUND_PIPELINE',
    tagline: 'Autonomous outreach, intent scoring, and calendar routing for high-ticket B2B deals.',
    icon: TrendingUp,
    status: 'ACTIVE_NODE',
    latency: '185ms',
    confidence: '99.4%',
    inputExample: 'Webhook: VP of Engineering at $40M ARR FinTech visited pricing page 3x and read Found X Edge Architecture case study.',
    outputPayload: '{\n  "leadScore": 98,\n  "intentCategory": "High-Ticket Enterprise Web App",\n  "decisionMaker": "Verified VP Eng",\n  "actionTaken": "Enriched tech stack + Delivered personalized Loom briefing link",\n  "status": "Meeting Scheduled for Thursday 2:00 PM IST"\n}',
    steps: [
      { phase: '01. INGEST', action: 'Webhook Event Capture', details: 'Extracted visitor IP, referrer domain & session replay duration (8m 42s)', speed: '14ms' },
      { phase: '02. ENRICH', action: 'Company Graph Search', details: 'Identified Series-B stage, 140 engineers, using Next.js 14 with high latency', speed: '52ms' },
      { phase: '03. REASON', action: 'Intent Scoring & Personalization', details: 'Generated personalized architectural teardown addressing their specific P99 latency bottleneck', speed: '88ms' },
      { phase: '04. DISPATCH', action: 'VIP Outreach & Calendar Sync', details: 'Sent private brief to executive inbox with calendar reservation link', speed: '31ms' },
    ],
  },
  {
    id: 'agent-refactor',
    name: 'Codebase Architecture & Patch Agent',
    codename: 'AGENT_02 // SYSTEM_OPTIMIZER',
    tagline: 'Deep AST analysis and automated refactoring patches to maintain sub-15ms edge performance.',
    icon: Code2,
    status: 'ACTIVE_NODE',
    latency: '340ms',
    confidence: '100%',
    inputExample: 'PR #142: Ingested 18 modified Next.js server actions with unmemoized MongoDB database queries.',
    outputPayload: '{\n  "securityIssues": 0,\n  "performanceBottlenecks": 2,\n  "patchGenerated": "Replaced waterfall fetches with Promise.allSettled + Edge Redis caching",\n  "measuredImpact": "Latency dropped from 148ms -> 12.4ms",\n  "testsPassed": "46/46 unit tests verified in isolation"\n}',
    steps: [
      { phase: '01. PARSE', action: 'Semantic Abstract Syntax Tree', details: 'Parsed TypeScript syntax tree to identify blocking database waterfalls', speed: '32ms' },
      { phase: '02. BENCHMARK', action: 'Sub-Frame Timing Simulator', details: 'Simulated 1,000 concurrent requests across 4 global edge nodes', speed: '110ms' },
      { phase: '03. GENERATE', action: 'Optimized Code Patch', details: 'Engineered zero-copy memory buffers and cached edge response headers', speed: '145ms' },
      { phase: '04. VERIFY', action: 'Automated CI Test Suite', details: 'Executed comprehensive smoke & regression suites with zero breaking changes', speed: '53ms' },
    ],
  },
  {
    id: 'agent-rag',
    name: 'Enterprise RAG Knowledge Agent',
    codename: 'AGENT_03 // VECTOR_MEMORY',
    tagline: 'Multi-document semantic retrieval and synthesis with zero hallucinations.',
    icon: Database,
    status: 'ACTIVE_NODE',
    latency: '210ms',
    confidence: '99.8%',
    inputExample: 'Query: "What is the exact SLA guarantee and recovery procedure if edge cache fails in EU-Central?"',
    outputPayload: '{\n  "sourcesQueried": 84,\n  "cosineSimilarity": 0.988,\n  "synthesizedAnswer": "FOUND X guarantees 99.98% uptime with automated DNS failover to AWS Frankfurt within 400ms. In-flight transactions retry via idempotent edge worker.",\n  "groundedSource": "architecture-spec-v4.pdf #Section 8.2",\n  "hallucinationRisk": "0.00%"\n}',
    steps: [
      { phase: '01. EMBED', action: 'Vector Embedding Generation', details: 'Generated 1,536-dimensional vector embedding for technical query', speed: '18ms' },
      { phase: '02. SEARCH', action: 'HNSW Graph Similarity Retrieval', details: 'Queried 500,000 document chunks with cosine similarity threshold > 0.88', speed: '48ms' },
      { phase: '03. RERANK', action: 'Cross-Encoder Context Rerank', details: 'Ranked top 4 canonical specification fragments for context window injection', speed: '74ms' },
      { phase: '04. SYNTHESIZE', action: 'Deterministic Answer Generation', details: 'Synthesized grounded response strictly citing verified source documentation', speed: '70ms' },
    ],
  },
  {
    id: 'agent-brand',
    name: 'Executive Narrative & Authority Agent',
    codename: 'AGENT_04 // NARRATIVE_ENGINE',
    tagline: 'Transforms raw technical achievements into viral, high-signal founder posts on LinkedIn.',
    icon: Sparkles,
    status: 'ACTIVE_NODE',
    latency: '260ms',
    confidence: '98.9%',
    inputExample: 'Founder Input: "We cut our AWS cloud bill from $12,000/mo to $1,800/mo by moving from ECS containers to Cloudflare Workers."',
    outputPayload: '{\n  "hookScore": 95,\n  "targetAudience": "CTOs, SaaS Founders & Tech Investors",\n  "narrativeHook": "We just fired 80% of our cloud infrastructure.\\n\\nHere is how we took a $12,000 AWS bill down to $1,800 without dropping a single packet:",\n  "reachPotential": "50,000+ organic impressions",\n  "callToAction": "Direct inbound DM to discuss architectural audit"\n}',
    steps: [
      { phase: '01. EXTRACT', action: 'Signal & Metric Extraction', details: 'Identified core commercial hook: $10.2k/mo cost delta + architectural audacity', speed: '24ms' },
      { phase: '02. MAP', action: 'Audience Persona Resonance', details: 'Mapped narrative against technical decision-maker psychological triggers', speed: '62ms' },
      { phase: '03. COMPOSE', action: 'High-Signal Post Architecture', details: 'Constructed punchy 1-3 line cadence with actionable technical breakdown', speed: '124ms' },
      { phase: '04. REFINE', action: 'Algorithmic Distribution Check', details: 'Ensured dwell-time optimization and removed external link penalization', speed: '50ms' },
    ],
  },
];

const capabilities = [
  {
    icon: Database,
    title: 'Vector Memory & RAG Retrieval',
    desc: 'Ingest enterprise documentation, codebase repositories, and historical telemetry for instant, grounded search.',
  },
  {
    icon: Sliders,
    title: 'Multi-Node Agent Coordination',
    desc: 'Specialized autonomous nodes collaborate to solve complex multi-step workflows without human bottlenecks.',
  },
  {
    icon: CheckCircle2,
    title: 'Guardrailed Determinism',
    desc: 'Zero-hallucination pipelines with built-in sanity checks, type validation, and automated rollback protections.',
  },
];

export function AILab() {
  const [selectedAgentId, setSelectedAgentId] = useState('agent-sales');
  const [isRunning, setIsRunning] = useState(false);
  const [activeStepIndex, setActiveStepIndex] = useState(3);
  const [copiedOutput, setCopiedOutput] = useState(false);

  const activeAgent = agentList.find((a) => a.id === selectedAgentId) || agentList[0];

  const handleRunAgent = () => {
    if (isRunning) return;
    setIsRunning(true);
    setActiveStepIndex(0);

    const t1 = setTimeout(() => setActiveStepIndex(1), 350);
    const t2 = setTimeout(() => setActiveStepIndex(2), 700);
    const t3 = setTimeout(() => {
      setActiveStepIndex(3);
      setIsRunning(false);
    }, 1100);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  };

  const handleSelectAgent = (id: string) => {
    setSelectedAgentId(id);
    handleRunAgent();
  };

  const handleCopyPayload = () => {
    navigator.clipboard.writeText(activeAgent.outputPayload);
    setCopiedOutput(true);
    setTimeout(() => setCopiedOutput(false), 2000);
  };

  return (
    <section id="ailab" className="py-16 md:py-24 px-margin-mobile md:px-margin-desktop w-full max-w-container-max mx-auto relative bg-[#F6F3EC] text-[#181716]">
      {/* Hero Header */}
      <div className="text-center max-w-4xl mx-auto mb-16">
        <FadeUp>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#EFECE4] border border-[#9E7B4F]/40 text-[#9E7B4F] font-mono text-xs font-bold uppercase tracking-widest mb-4 shadow-sm">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            FOUND X AUTONOMOUS AGENT LAB
          </div>
        </FadeUp>
        <FadeUp delay={0.1}>
          <h2 className="font-display font-bold text-4xl sm:text-6xl md:text-7xl text-[#181716] tracking-tight leading-tight mb-4">
            AI that actually <span className="text-[#9E7B4F]">does something.</span>
          </h2>
        </FadeUp>
        <FadeUp delay={0.15}>
          <p className="font-sans text-base sm:text-lg text-[#54504A] max-w-2xl mx-auto leading-relaxed">
            Move beyond generic chat wrappers. We architect specialized, multi-agent networks that execute complex operational workflows, reason through ambiguity, and drive measurable revenue.
          </p>
        </FadeUp>
      </div>

      {/* INTERACTIVE AGENT COMMAND CENTER & SIMULATOR */}
      <div className="mb-20 bg-[#EFECE4] border-2 border-[#9E7B4F]/30 rounded-3xl p-5 md:p-8 metallic-edge shadow-[0_20px_60px_rgba(158,123,79,0.1)]">
        {/* Top Control Bar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-[#9E7B4F]/25">
          <div>
            <span className="font-mono text-xs text-[#9E7B4F] font-bold uppercase tracking-widest block mb-1">
              LIVE AGENT SIMULATION PLAYGROUND
            </span>
            <h3 className="font-display font-bold text-2xl text-[#181716]">
              Select an agent to test live execution telemetry
            </h3>
          </div>

          <button
            onClick={handleRunAgent}
            disabled={isRunning}
            className="self-start md:self-auto bg-[#9E7B4F] hover:bg-[#8B693C] text-white px-5 py-2.5 rounded-xl font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer shadow-md disabled:opacity-50"
          >
            {isRunning ? <RefreshCw size={14} className="animate-spin" /> : <Play size={14} />}
            <span>{isRunning ? 'EXECUTING TRACE...' : 'RUN LIVE AGENT TRACE'}</span>
          </button>
        </div>

        {/* Agent Selector Tabs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 my-6">
          {agentList.map((agent) => {
            const Icon = agent.icon;
            const isSelected = selectedAgentId === agent.id;
            return (
              <button
                key={agent.id}
                onClick={() => handleSelectAgent(agent.id)}
                className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                  isSelected
                    ? 'bg-[#FAF8F5] border-[#9E7B4F] ring-2 ring-[#9E7B4F]/40 shadow-md'
                    : 'bg-[#EFECE4]/60 border-[#9E7B4F]/20 hover:border-[#9E7B4F]/50 hover:bg-[#FAF8F5]/60'
                }`}
              >
                <div className="flex justify-between items-start">
                  <div className="p-2 rounded-lg bg-[#9E7B4F]/10 border border-[#9E7B4F]/20 text-[#9E7B4F]">
                    <Icon size={20} />
                  </div>
                  <span className="font-mono text-xs text-emerald-700 bg-emerald-500/15 border border-emerald-500/30 px-2 py-0.5 rounded font-bold">
                    ONLINE
                  </span>
                </div>

                <div>
                  <h4 className="font-display font-bold text-base text-[#181716] mb-0.5">
                    {agent.name}
                  </h4>
                  <span className="font-mono text-xs text-[#9E7B4F] block font-semibold truncate">
                    {agent.codename}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Live Execution Console & Output Area */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-4">
          {/* Left: Step-by-Step Execution Pipeline (7 cols) */}
          <div className="lg:col-span-7 bg-[#FAF8F5] border border-[#9E7B4F]/30 rounded-2xl p-6 metallic-edge flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#9E7B4F]/20">
                <div className="flex items-center gap-2">
                  <Terminal size={18} className="text-[#9E7B4F]" />
                  <span className="font-mono text-xs font-bold text-[#181716] uppercase tracking-wider">
                    EXECUTION PIPELINE TELEMETRY
                  </span>
                </div>
                <div className="flex items-center gap-3 font-mono text-xs text-[#54504A]">
                  <span>P99: <strong className="text-[#9E7B4F]">{activeAgent.latency}</strong></span>
                  <span>CONFIDENCE: <strong className="text-emerald-600">{activeAgent.confidence}</strong></span>
                </div>
              </div>

              {/* Input Prompt Card */}
              <div className="bg-[#EFECE4] p-3.5 rounded-xl border border-[#9E7B4F]/25 mb-6 text-xs font-mono text-[#54504A]">
                <span className="text-[#9E7B4F] font-bold block mb-1">TRIGGER INPUT:</span>
                <p className="text-[#181716] font-sans text-xs leading-relaxed">{activeAgent.inputExample}</p>
              </div>

              {/* 4 Pipeline Steps */}
              <div className="space-y-3.5">
                {activeAgent.steps.map((step, idx) => {
                  const isCompleted = activeStepIndex >= idx;
                  const isCurrent = activeStepIndex === idx;

                  return (
                    <div
                      key={step.phase}
                      className={`p-3.5 rounded-xl border transition-all duration-300 flex items-start justify-between gap-3 ${
                        isCurrent
                          ? 'bg-[#EFECE4] border-[#9E7B4F] shadow-sm'
                          : isCompleted
                          ? 'bg-[#FAF8F5] border-[#9E7B4F]/30'
                          : 'bg-[#FAF8F5]/40 border-dashed border-[#9E7B4F]/20 opacity-50'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div
                          className={`w-6 h-6 rounded-full flex items-center justify-center font-mono text-xs font-bold shrink-0 mt-0.5 ${
                            isCompleted
                              ? 'bg-[#9E7B4F] text-white'
                              : 'bg-zinc-200 text-zinc-600'
                          }`}
                        >
                          {isCompleted ? <Check size={14} /> : idx + 1}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs font-bold text-[#9E7B4F]">{step.phase}</span>
                            <span className="font-display font-bold text-sm text-[#181716]">{step.action}</span>
                          </div>
                          <p className="font-sans text-xs text-[#54504A] mt-1 leading-relaxed">{step.details}</p>
                        </div>
                      </div>

                      <span className="font-mono text-xs text-[#9E7B4F] font-bold shrink-0 pt-0.5">
                        +{step.speed}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-[#9E7B4F]/20 flex items-center justify-between text-xs font-mono text-[#54504A]">
              <span>STATUS: {isRunning ? 'PROCESSING THREAD...' : 'VERIFIED COMPLETE'}</span>
              <span className="text-emerald-700 font-bold">100% DETERMINISTIC</span>
            </div>
          </div>

          {/* Right: Real-time Output Payload Inspector (5 cols) */}
          <div className="lg:col-span-5 bg-[#121215] rounded-2xl p-6 border-2 border-[#9E7B4F]/40 shadow-xl flex flex-col justify-between relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#9E7B4F]/10 blur-3xl pointer-events-none" />

            <div>
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-white/15 text-xs font-mono">
                <div className="flex items-center gap-2 text-[#C5A059] font-bold">
                  <Cpu size={16} />
                  <span>SYNTHESIZED ARTIFACT PAYLOAD</span>
                </div>

                <button
                  onClick={handleCopyPayload}
                  className="text-zinc-400 hover:text-white transition-colors cursor-pointer flex items-center gap-1 font-mono text-xs"
                >
                  {copiedOutput ? <Check size={12} className="text-emerald-400" /> : null}
                  <span>{copiedOutput ? 'COPIED' : 'COPY'}</span>
                </button>
              </div>

              {/* JSON Payload View */}
              <pre className="font-mono text-xs text-emerald-400 bg-[#050508] p-4 rounded-xl border border-white/10 overflow-x-auto leading-relaxed shadow-inner">
                <code>{activeAgent.outputPayload}</code>
              </pre>

              {/* Summary Explanation */}
              <div className="mt-4 p-3 bg-white/5 rounded-xl border border-white/10 text-xs font-sans text-zinc-300 leading-relaxed">
                <span className="font-mono text-[#C5A059] font-bold block mb-1">ARCHITECTURAL SUMMARY:</span>
                {activeAgent.tagline}
              </div>
            </div>

            {/* Bottom Inquire CTA */}
            <div className="mt-6 pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
              <span className="font-mono text-xs text-zinc-400">READY FOR DEPLOYMENT</span>
              <a
                href="#contact"
                className="bg-[#9E7B4F] hover:bg-[#8B693C] text-white px-5 py-2 rounded-lg font-mono text-xs font-bold uppercase tracking-wider transition-colors shadow-sm w-full sm:w-auto text-center"
              >
                DEPLOY AGENT
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* CORE CAPABILITIES GRID */}
      <div>
        <FadeUp>
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1 rounded border border-[#9E7B4F]/25 font-bold uppercase tracking-wider">
              FOUNDATION
            </span>
            <h3 className="font-display font-bold text-3xl md:text-4xl text-[#181716] mt-3">
              Core Intelligence Architecture
            </h3>
            <p className="font-sans text-sm text-[#54504A] mt-2">
              The underlying engineering primitives powering our autonomous systems.
            </p>
          </div>
        </FadeUp>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {capabilities.map((cap, i) => {
            const Icon = cap.icon;
            return (
              <FadeUp key={cap.title} delay={i * 0.1}>
                <div className="bg-[#EFECE4] border border-[#9E7B4F]/30 rounded-2xl p-8 metallic-edge shadow-sm hover:border-[#9E7B4F] transition-all h-full flex flex-col justify-between group">
                  <div>
                    <div className="w-12 h-12 rounded-xl bg-[#FAF8F5] border border-[#9E7B4F]/30 flex items-center justify-center text-[#9E7B4F] mb-6 shadow-sm group-hover:scale-110 transition-transform">
                      <Icon size={24} />
                    </div>
                    <h4 className="font-display font-bold text-xl text-[#181716] mb-3">
                      {cap.title}
                    </h4>
                    <p className="font-sans text-sm text-[#54504A] leading-relaxed">
                      {cap.desc}
                    </p>
                  </div>
                </div>
              </FadeUp>
            );
          })}
        </div>
      </div>
    </section>
  );
}
