import { Contact } from '../sections/Contact';

export function ContactPage() {
  return (
    <div className="pt-12">
      <Contact />
    </div>
  );
}
