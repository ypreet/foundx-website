import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FadeUp } from '../components/ui/FadeUp';
import { Clock, ArrowRight, X, Sparkles } from 'lucide-react';

interface Article {
  id: number;
  category: string;
  date: string;
  readTime: string;
  title: string;
  desc: string;
  img: string;
  fullBody: string[];
  takeaways: string[];
}

const categories = ['All', 'Engineering', 'AI & Agents', 'Personal Branding', 'Leadership'];

const articles: Article[] = [
  {
    id: 1,
    category: 'Personal Branding',
    date: 'Oct 24, 2026',
    readTime: '6 min read',
    title: 'Your LinkedIn Profile Is Not Your Resume — It Is Your Digital Landing Page',
    desc: 'The old paradigm of treating your profile as a static CV is dead. In the age of founder-led growth, it is the primary conversion funnel for your authority.',
    img: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1000&q=80',
    fullBody: [
      'Most technical founders treat their LinkedIn profiles like an archive of past jobs. They list responsibilities, graduation years, and corporate bullet points.',
      'High-value clients and investors do not care where you worked in 2018. They care about what problem you can solve for them today, with what speed, and with what level of conviction.',
      'When you treat your profile as a high-conversion landing page, your headline becomes your value proposition, your banner becomes your social proof, and your featured section becomes your case study portfolio.',
    ],
    takeaways: [
      'Replace resume jargon with commercial outcomes (revenue unlocked, latency reduced).',
      'Feature 2-3 specific case studies with measurable metrics above the fold.',
      'Ensure every post drives clear inbound curiosity directly to your direct messages.',
    ],
  },
  {
    id: 2,
    category: 'AI & Agents',
    date: 'Oct 18, 2026',
    readTime: '8 min read',
    title: 'Beyond the Chat Wrapper: Building Autonomous Multi-Agent State Machines',
    desc: 'Integrating LLMs into production workflows reveals fundamental truths about deterministic state machines versus non-deterministic reasoning.',
    img: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&w=1000&q=80',
    fullBody: [
      'A chat interface is rarely the best interface for enterprise software. Real leverage occurs when AI agents operate silently in the background, executing workflows between APIs, databases, and message queues.',
      'The biggest hurdle in autonomous agent design is state recovery. When an LLM generates invalid JSON or hallucinates a parameter, your system must self-correct through strict TypeScript schema validation.',
      'By architecting specialized single-purpose agents (Ingestion, Reranking, Code Generation, Verification), you reduce token costs by 68% and drive accuracy to near 100%.',
    ],
    takeaways: [
      'Decouple agent reasoning from user UI — run heavy chains asynchronously.',
      'Use HNSW vector search with cross-encoder reranking to prevent hallucinations.',
      'Enforce strict JSON schema validation with automated retry fallbacks.',
    ],
  },
  {
    id: 3,
    category: 'Engineering',
    date: 'Sep 30, 2026',
    readTime: '7 min read',
    title: 'The Sub-Frame Web: Why Every 10ms of Latency Destroys Inbound Conversion',
    desc: 'Speed is not an optimization; it is your core product feature. How sub-frame edge rendering directly multiplies B2B pipeline velocity.',
    img: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1000&q=80',
    fullBody: [
      'In high-stakes technical sales, decision-makers have zero patience for sluggish web interfaces. If your app takes 2.4 seconds to load its dashboard, you lose psychological dominance before the pitch begins.',
      'Sub-frame rendering means ensuring initial content paints within a single 16.6ms screen refresh frame. This is achieved by combining React 19 server components, edge CDN caching, and zero client runtime bloat.',
      'When your product reacts instantly to every click, users subconsciously associate your software with reliability, power, and architectural mastery.',
    ],
    takeaways: [
      'Host code on multi-region edge nodes within 15ms of key global business hubs.',
      'Eliminate heavy monolithic UI libraries in favor of tailored, zero-waste CSS.',
      'Audit client bundle sizes relentlessly — ship only the bytes strictly needed.',
    ],
  },
  {
    id: 4,
    category: 'Leadership',
    date: 'Sep 15, 2026',
    readTime: '9 min read',
    title: 'The Anatomy of a High-Signal Builder Studio in 2026',
    desc: 'How modern technical directors build lean, high-output studios that out-execute 50-person agencies through AI leverage.',
    img: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=1000&q=80',
    fullBody: [
      'The traditional agency model is fundamentally broken: bloated account managers, endless status meetings, and outsourced junior developers executing cookie-cutter templates.',
      'A true builder studio operates like an elite Formula 1 engineering pit crew. The founder and principal architects interface directly with the client, writing the core code and directing the strategic narrative.',
      'By pairing human craftsmanship with automated AI development workflows, a 2-person studio can deliver what previously required a 20-person development firm.',
    ],
    takeaways: [
      'Eliminate intermediate account managers — maintain direct builder-to-client signal.',
      'Deploy autonomous agents for test verification, code refactoring, and telemetry.',
      'Deliver working software prototypes within 7 days instead of 6-week slide decks.',
    ],
  },
];

export function Insights() {
  const [activeCategory, setActiveCategory] = useState('All');
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  const filteredArticles =
    activeCategory === 'All'
      ? articles
      : articles.filter((a) => a.category === activeCategory);

  return (
    <section
      id="insights"
      className="py-16 md:py-24 px-margin-mobile md:px-margin-desktop max-w-container-max mx-auto w-full relative bg-[#F6F3EC] text-[#181716]"
    >
      {/* Header Section */}
      <div className="mb-12 text-center">
        <FadeUp>
          <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3.5 py-1.5 rounded border border-[#9E7B4F]/25 uppercase tracking-widest font-bold mb-4 inline-block">
            ARCHITECTURAL INSIGHTS & ESSAYS
          </span>
        </FadeUp>
        <FadeUp delay={0.1}>
          <h2 className="font-display font-bold text-4xl sm:text-6xl md:text-7xl text-[#181716] mb-4 tracking-tight leading-tight">
            High-signal thoughts for <span className="text-[#9E7B4F]">builders.</span>
          </h2>
        </FadeUp>
        <FadeUp delay={0.15}>
          <p className="font-sans text-base sm:text-lg text-[#54504A] max-w-2xl mx-auto leading-relaxed">
            Observations from the frontlines of software engineering, AI agent deployments, and founder reputation architecture.
          </p>
        </FadeUp>
      </div>

      {/* Category Filter Chips */}
      <FadeUp delay={0.2}>
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setActiveCategory(c)}
              className={`font-mono text-xs px-4 py-2 rounded-xl border transition-all duration-300 cursor-pointer ${
                activeCategory === c
                  ? 'bg-[#9E7B4F] text-white border-[#9E7B4F] font-bold shadow-sm'
                  : 'bg-[#EFECE4] text-[#54504A] border-[#9E7B4F]/25 hover:border-[#9E7B4F] hover:text-[#181716]'
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </FadeUp>

      {/* Articles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {filteredArticles.map((article, i) => (
          <FadeUp key={article.id} delay={i * 0.1}>
            <motion.article
              whileHover={{ y: -4 }}
              transition={{ duration: 0.3 }}
              onClick={() => setSelectedArticle(article)}
              className="bg-[#EFECE4] rounded-2xl overflow-hidden border border-[#9E7B4F]/30 metallic-edge flex flex-col justify-between h-full shadow-sm hover:border-[#9E7B4F] hover:shadow-md transition-all cursor-pointer group"
            >
              <div>
                {/* Image Cover */}
                <div className="h-56 w-full relative overflow-hidden bg-zinc-900">
                  <img
                    src={article.img}
                    alt={article.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#181716]/70 via-transparent to-transparent" />
                  <div className="absolute top-4 left-4">
                    <span className="font-mono text-xs bg-[#181716]/80 text-[#C5A059] px-3 py-1 rounded-md border border-[#9E7B4F]/40 font-bold uppercase tracking-wider backdrop-blur-sm">
                      {article.category}
                    </span>
                  </div>
                </div>

                {/* Article Content */}
                <div className="p-7">
                  <div className="flex items-center gap-4 text-xs font-mono text-[#54504A] mb-3">
                    <span>{article.date}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock size={12} /> {article.readTime}
                    </span>
                  </div>

                  <h3 className="font-display font-bold text-xl md:text-2xl text-[#181716] group-hover:text-[#9E7B4F] transition-colors leading-snug mb-3">
                    {article.title}
                  </h3>

                  <p className="font-sans text-sm text-[#54504A] line-clamp-3 leading-relaxed">
                    {article.desc}
                  </p>
                </div>
              </div>

              {/* Read Action Footer */}
              <div className="px-7 pb-6 pt-2 border-t border-[#9E7B4F]/20 flex justify-between items-center text-xs font-mono font-bold text-[#9E7B4F] group-hover:text-[#181716] transition-colors">
                <span className="uppercase tracking-wider">READ ESSAY</span>
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </div>
            </motion.article>
          </FadeUp>
        ))}
      </div>

      {/* ARTICLE READER MODAL */}
      <AnimatePresence>
        {selectedArticle && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-[#FAF8F5] border-2 border-[#9E7B4F] rounded-3xl w-full max-w-3xl max-h-[90vh] overflow-y-auto shadow-2xl p-6 md:p-10 relative"
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedArticle(null)}
                className="absolute top-6 right-6 p-2 rounded-full bg-[#EFECE4] hover:bg-[#E0DBD0] text-[#181716] transition-colors cursor-pointer"
                aria-label="Close modal"
              >
                <X size={20} />
              </button>

              {/* Modal Metadata */}
              <div className="flex items-center gap-3 mb-4">
                <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1 rounded font-bold uppercase tracking-wider">
                  {selectedArticle.category}
                </span>
                <span className="font-mono text-xs text-[#54504A]">
                  {selectedArticle.date} · {selectedArticle.readTime}
                </span>
              </div>

              {/* Modal Title */}
              <h2 className="font-display font-bold text-2xl md:text-4xl text-[#181716] mb-6 leading-snug">
                {selectedArticle.title}
              </h2>

              {/* Article Hero Banner */}
              <div className="h-64 rounded-2xl overflow-hidden mb-8 border border-[#9E7B4F]/20">
                <img
                  src={selectedArticle.img}
                  alt={selectedArticle.title}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Article Body Paragraphs */}
              <div className="space-y-4 text-base font-sans text-[#181716] leading-relaxed mb-8">
                {selectedArticle.fullBody.map((para, idx) => (
                  <p key={idx}>{para}</p>
                ))}
              </div>

              {/* Key Takeaways Box */}
              <div className="bg-[#EFECE4] border border-[#9E7B4F]/30 rounded-2xl p-6 mb-8">
                <div className="flex items-center gap-2 text-sm font-mono font-bold text-[#9E7B4F] mb-3 uppercase tracking-wider">
                  <Sparkles size={16} /> CORE ARCHITECTURAL TAKEAWAYS
                </div>
                <ul className="space-y-2.5">
                  {selectedArticle.takeaways.map((takeaway, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm font-sans text-[#54504A]">
                      <span className="text-[#9E7B4F] font-bold font-mono">0{idx + 1}.</span>
                      <span>{takeaway}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Author Attribution & Footer */}
              <div className="flex flex-col sm:flex-row justify-between items-center gap-4 pt-6 border-t border-[#9E7B4F]/25 text-xs font-mono text-[#54504A]">
                <div>Written by Preet Yadav · Found X Studio Director</div>
                <button
                  onClick={() => setSelectedArticle(null)}
                  className="bg-[#9E7B4F] text-white px-6 py-2.5 rounded-xl font-bold uppercase tracking-wider hover:bg-[#8B693C] transition-colors cursor-pointer"
                >
                  DONE READING
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
