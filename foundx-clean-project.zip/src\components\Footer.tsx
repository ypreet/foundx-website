import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowUp } from 'lucide-react';

export function Footer() {
  const [istTime, setIstTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const options: Intl.DateTimeFormatOptions = {
        timeZone: 'Asia/Kolkata',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      };
      setIstTime(new Intl.DateTimeFormat('en-US', options).format(now));
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full py-16 bg-[#EFECE4] border-t border-[#9E7B4F]/25 relative z-20">
      <div className="max-w-container-max mx-auto px-margin-mobile md:px-margin-desktop flex flex-col gap-10">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8 pb-8 border-b border-[#9E7B4F]/20">
          <div className="flex items-center gap-4">
            <img
              src="/images/foundx-logo.png"
              alt="FOUND X Seal Emblem"
              className="w-14 h-14 object-contain rounded-full mix-blend-multiply"
            />
            <div>
              <div className="font-display font-bold text-2xl text-[#181716] tracking-widest">
                FOUND X
              </div>
              <p className="font-mono text-xs text-[#54504A] tracking-wider font-semibold">
                Builder's Studio for High-Performance Founders
              </p>
            </div>
          </div>

          {/* Navigation Links with Accessible Touch Targets */}
          <div className="flex flex-wrap gap-1.5 md:gap-2 font-mono text-xs uppercase tracking-wider text-[#54504A] font-semibold">
            <Link className="px-3 py-2 rounded-lg hover:text-[#9E7B4F] hover:bg-[#9E7B4F]/10 transition-colors inline-block" to="/">Home</Link>
            <Link className="px-3 py-2 rounded-lg hover:text-[#9E7B4F] hover:bg-[#9E7B4F]/10 transition-colors inline-block" to="/services">Services</Link>
            <Link className="px-3 py-2 rounded-lg hover:text-[#9E7B4F] hover:bg-[#9E7B4F]/10 transition-colors inline-block" to="/3d-showcase">3D Showcase</Link>
            <Link className="px-3 py-2 rounded-lg hover:text-[#9E7B4F] hover:bg-[#9E7B4F]/10 transition-colors inline-block" to="/ai-lab">AI Lab</Link>
            <Link className="px-3 py-2 rounded-lg hover:text-[#9E7B4F] hover:bg-[#9E7B4F]/10 transition-colors inline-block" to="/work">Work</Link>
            <Link className="px-3 py-2 rounded-lg hover:text-[#9E7B4F] hover:bg-[#9E7B4F]/10 transition-colors inline-block" to="/about">About</Link>
            <Link className="px-3 py-2 rounded-lg hover:text-[#9E7B4F] hover:bg-[#9E7B4F]/10 transition-colors inline-block" to="/insights">Insights</Link>
            <Link className="px-3 py-2 rounded-lg hover:text-[#9E7B4F] hover:bg-[#9E7B4F]/10 transition-colors inline-block" to="/contact">Contact</Link>
            <a
              className="px-3 py-2 rounded-lg hover:text-[#9E7B4F] hover:bg-[#9E7B4F]/10 transition-colors text-[#9E7B4F] font-bold inline-block"
              href="https://www.linkedin.com/in/preet-yadav-found-x/"
              target="_blank"
              rel="noopener noreferrer"
            >
              LinkedIn ↗
            </a>
          </div>
        </div>

        {/* Live IST Time, Copyright, and Back-to-Top */}
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 text-xs font-mono text-[#54504A]">
          <div className="flex items-center gap-3">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-semibold">INDIA (IST / GMT+5:30): {istTime || '12:00:00 PM'}</span>
          </div>

          <span className="font-medium">© 2026 FOUND X · PREET YADAV STUDIO. ALL RIGHTS RESERVED.</span>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-2 px-4 py-2 rounded bg-[#FAF8F5] border border-[#9E7B4F]/30 hover:border-[#9E7B4F] text-[#181716] hover:text-[#9E7B4F] transition-all cursor-pointer group shadow-sm font-mono text-xs font-bold"
          >
            <span>TOP</span>
            <ArrowUp size={14} className="group-hover:-translate-y-0.5 transition-transform" />
          </button>
        </div>
      </div>
    </footer>
  );
}
