import { FadeUp } from '../components/ui/FadeUp';

export function FounderJourney() {
  return (
    <section className="section-y bg-brand-white">
      <div className="section-padding max-w-screen-xl mx-auto">
        <div className="max-w-3xl mx-auto">
          <FadeUp>
            <p className="label mb-8">Founder Journey</p>
          </FadeUp>
          <FadeUp delay={0.1}>
            <h2 className="heading-md text-brand-black mb-12">Still Early. Still Building.</h2>
          </FadeUp>
          <FadeUp delay={0.15}>
            <div className="flex flex-col gap-6 text-xl md:text-2xl font-light text-brand-black/60 leading-relaxed">
              <p>I'm not trying to look like I've figured everything out.</p>
              <p>
                I'm still learning.<br />
                Still testing.<br />
                Still building.
              </p>
              <p>But every project teaches me something new.</p>
              <p className="text-brand-black font-semibold">
                And that's exactly what I want Found X to represent:<br />
                <span className="text-brand-brown">curiosity, execution and continuous growth.</span>
              </p>
            </div>
          </FadeUp>

          {/* Signature line */}
          <FadeUp delay={0.25}>
            <div className="mt-16 flex items-center gap-4 border-t border-brand-border pt-8">
              <div className="w-10 h-10 rounded-full bg-brand-brown flex items-center justify-center">
                <span className="text-white text-sm font-black">PY</span>
              </div>
              <div>
                <p className="font-bold text-brand-black text-sm">Preet Yadav</p>
                <p className="text-xs text-brand-black/40">Founder, Found X · New Delhi, India</p>
              </div>
            </div>
          </FadeUp>
        </div>
      </div>
    </section>
  );
}
