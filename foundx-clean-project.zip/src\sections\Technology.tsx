import { useState } from 'react';
import { motion } from 'framer-motion';
import { FadeUp } from '../components/ui/FadeUp';
import { ArrowRight, Code2, Cpu, Server, Smartphone, ShieldCheck, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';

interface TechItem {
  name: string;
  category: 'Frontend' | 'AI & Agents' | 'Backend & Cloud' | 'Mobile';
  role: string;
  speed: string;
  icon: typeof Code2;
}

const techStack: TechItem[] = [
  // Frontend
  { name: 'React 19 & Next.js 15', category: 'Frontend', role: 'Server Components & Edge Rendering', speed: '12.4ms TTFB', icon: Code2 },
  { name: 'TypeScript Strict', category: 'Frontend', role: 'Zero-Runtime Exploit Static Typing', speed: '100% Type Safety', icon: ShieldCheck },
  { name: 'Tailwind CSS v3', category: 'Frontend', role: 'Zero-Runtime Overhead Design System', speed: '<10kB CSS Bundle', icon: Zap },
  { name: 'Framer Motion & 3D', category: 'Frontend', role: 'Hardware-Accelerated Spatial Physics', speed: '60 FPS Locked', icon: Code2 },

  // AI & Agents
  { name: 'Autonomous Agent Chains', category: 'AI & Agents', role: 'Multi-node decision state machines', speed: '185ms Execution', icon: Cpu },
  { name: 'RAG & Vector Memory', category: 'AI & Agents', role: 'HNSW Graph Indexing & Semantic Search', speed: '0.988 Cosine Match', icon: Cpu },
  { name: 'Python & FastAPI', category: 'AI & Agents', role: 'Asynchronous High-Throughput Inference', speed: '100k events/sec', icon: Cpu },
  { name: 'Structured JSON Schemas', category: 'AI & Agents', role: 'Deterministic AI Guardrails', speed: '0% Hallucination', icon: ShieldCheck },

  // Backend & Cloud
  { name: 'Cloudflare & Vercel Edge', category: 'Backend & Cloud', role: 'Global Multi-Region Serverless CDN', speed: '340 Points of Presence', icon: Server },
  { name: 'Node.js Microservices', category: 'Backend & Cloud', role: 'High-Concurrency Event Loops', speed: 'Sub-frame I/O', icon: Server },
  { name: 'PostgreSQL & Redis Cache', category: 'Backend & Cloud', role: 'ACID Transactions + Sub-millisecond Cache', speed: '0.8ms In-Memory Read', icon: Server },
  { name: 'GraphQL & REST APIs', category: 'Backend & Cloud', role: 'Idempotent Strict Payload Contracts', speed: 'Zero Payload Waste', icon: Server },

  // Mobile
  { name: 'React Native & Expo', category: 'Mobile', role: 'Native iOS & Android Binary Builds', speed: '60 FPS Smooth Gesture', icon: Smartphone },
  { name: 'Flutter Engine', category: 'Mobile', role: 'Skia Canvas Native Rendering', speed: 'Cross-Platform Sync', icon: Smartphone },
  { name: 'Offline-First SQLite', category: 'Mobile', role: 'Zero-Network Local Persistence', speed: 'Instant Resiliency', icon: Smartphone },
];

const categories = ['Frontend', 'AI & Agents', 'Backend & Cloud', 'Mobile', 'All Technologies'];

export function Technology() {
  const [activeCategory, setActiveCategory] = useState('Frontend');

  const filteredTech =
    activeCategory === 'All Technologies'
      ? techStack
      : techStack.filter((t) => t.category === activeCategory);

  return (
    <section id="technology" className="py-16 md:py-24 px-margin-mobile md:px-margin-desktop w-full max-w-container-max mx-auto relative bg-[#F6F3EC] text-[#181716]">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-12 border-b border-[#9E7B4F]/25 pb-6">
        <div>
          <FadeUp>
            <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1.5 rounded-md border border-[#9E7B4F]/25 uppercase tracking-widest font-bold mb-3 inline-block">
              FOUND X ARCHITECTURAL STACK
            </span>
          </FadeUp>
          <FadeUp delay={0.1}>
            <h2 className="font-display font-bold text-3xl sm:text-5xl md:text-6xl text-[#181716] tracking-tight leading-tight">
              Production-tested <span className="text-[#9E7B4F]">engineering tools.</span>
            </h2>
          </FadeUp>
        </div>

        <FadeUp delay={0.15}>
          <p className="font-sans text-sm md:text-base text-[#54504A] max-w-md leading-relaxed">
            We avoid trendy hype and legacy bloat. Every layer of our technology matrix is benchmarked for sub-frame execution speed, reliability, and security.
          </p>
        </FadeUp>
      </div>

      {/* Category Tabs */}
      <div className="flex flex-wrap gap-2 mb-10">
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setActiveCategory(c)}
            className={`font-mono text-xs px-4 py-2 rounded-xl border transition-all cursor-pointer ${
              activeCategory === c
                ? 'bg-[#9E7B4F] text-white border-[#9E7B4F] font-bold shadow-sm'
                : 'bg-[#EFECE4] text-[#54504A] border-[#9E7B4F]/25 hover:border-[#9E7B4F] hover:text-[#181716]'
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Tech Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 mb-14">
        {filteredTech.map((tech, i) => {
          const Icon = tech.icon;
          return (
            <FadeUp key={tech.name} delay={i * 0.05}>
              <motion.div
                whileHover={{ y: -3 }}
                transition={{ duration: 0.25 }}
                className="bg-[#EFECE4] border border-[#9E7B4F]/30 rounded-2xl p-6 metallic-edge shadow-sm hover:border-[#9E7B4F] hover:shadow-md transition-all flex flex-col justify-between h-full group"
              >
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-2.5 py-0.5 rounded-md border border-[#9E7B4F]/20 font-bold uppercase tracking-wider">
                      {tech.category}
                    </span>
                    <div className="p-2 rounded-lg bg-[#FAF8F5] border border-[#9E7B4F]/20 text-[#9E7B4F] group-hover:scale-110 transition-transform">
                      <Icon size={18} />
                    </div>
                  </div>

                  <h3 className="font-display font-bold text-lg text-[#181716] mb-1 group-hover:text-[#9E7B4F] transition-colors">
                    {tech.name}
                  </h3>

                  <p className="font-sans text-xs text-[#54504A] leading-relaxed">
                    {tech.role}
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-[#9E7B4F]/20 flex justify-between items-center text-xs font-mono">
                  <span className="text-zinc-500">Benchmark:</span>
                  <span className="text-[#9E7B4F] font-bold">{tech.speed}</span>
                </div>
              </motion.div>
            </FadeUp>
          );
        })}
      </div>

      {/* Callout Banner */}
      <FadeUp delay={0.2}>
        <div className="bg-[#FAF8F5] border-2 border-[#9E7B4F]/40 rounded-3xl p-8 md:p-10 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-sm">
          <div>
            <h4 className="font-display font-bold text-2xl text-[#181716] mb-2">
              Have a custom technology stack or legacy codebase?
            </h4>
            <p className="font-sans text-sm text-[#54504A]">
              We audit, refactor, and migrate systems without downtime or breaking customer workflows.
            </p>
          </div>

          <Link
            to="/contact"
            className="btn-primary shrink-0 w-full sm:w-auto text-center"
          >
            REQUEST ARCHITECTURE AUDIT <ArrowRight size={14} />
          </Link>
        </div>
      </FadeUp>
    </section>
  );
}
