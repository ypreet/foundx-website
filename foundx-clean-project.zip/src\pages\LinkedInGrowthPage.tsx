import { Link } from 'react-router-dom';
import { FadeUp } from '../components/ui/FadeUp';
import { ArrowLeft } from 'lucide-react';
import { LinkedInSection } from '../sections/LinkedIn';

export function LinkedInGrowthPage() {
  return (
    <div className="py-20 md:py-28 px-margin-mobile md:px-margin-desktop max-w-container-max mx-auto bg-[#F6F3EC] text-[#181716]">
      {/* Back Link */}
      <div className="mb-8">
        <Link to="/services" className="inline-flex items-center gap-2 font-mono text-xs text-[#9E7B4F] font-bold uppercase tracking-wider hover:underline">
          <ArrowLeft size={16} /> BACK TO ALL SERVICES
        </Link>
      </div>

      {/* Hero Header */}
      <div className="text-center max-w-4xl mx-auto mb-16">
        <FadeUp>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#EFECE4] border border-[#9E7B4F]/40 text-[#9E7B4F] font-mono text-xs font-bold uppercase tracking-widest mb-4 shadow-sm">
            03 // DEDICATED ORGANIC GROWTH PILLAR
          </div>
        </FadeUp>
        <FadeUp delay={0.1}>
          <h1 className="font-display font-bold text-4xl sm:text-6xl md:text-7xl text-[#181716] tracking-tight leading-tight mb-6">
            LinkedIn Organic Growth & <span className="text-[#9E7B4F]">Authority Engine.</span>
          </h1>
        </FadeUp>
        <FadeUp delay={0.15}>
          <p className="font-sans text-lg text-[#54504A] leading-relaxed max-w-2xl mx-auto mb-8">
            Transform passive LinkedIn profiles into high-ticket inbound lead magnets with technical founder positioning and organic reach systems.
          </p>
        </FadeUp>

        <FadeUp delay={0.2}>
          <div className="flex justify-center gap-4">
            <Link to="/contact" className="btn-primary">
              SCALE LINKEDIN BRAND
            </Link>
            <a
              href="https://www.linkedin.com/in/preet-yadav-found-x/"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-secondary"
            >
              VIEW PREET'S PROFILE ↗
            </a>
          </div>
        </FadeUp>
      </div>

      {/* LinkedIn Detail Component */}
      <LinkedInSection />

      {/* CTA Footer */}
      <div className="mt-16 text-center pt-12 border-t border-[#9E7B4F]/25">
        <h3 className="font-display font-bold text-3xl text-[#181716] mb-4">Ready to generate organic inbound leads on LinkedIn?</h3>
        <p className="font-sans text-base text-[#54504A] mb-8">2.4M+ impressions generated, 4.8x conversion rate multiplier.</p>
        <Link to="/contact" className="btn-primary">LAUNCH GROWTH ENGINE</Link>
      </div>
    </div>
  );
}
