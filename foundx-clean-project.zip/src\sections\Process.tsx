import { motion } from 'framer-motion';
import { FadeUp } from '../components/ui/FadeUp';
import { EyeOff, Award, Compass, Layers, PenTool, Share2, TrendingUp, Check } from 'lucide-react';

export function Process() {
  return (
    <section id="process" className="py-16 md:py-24 px-margin-mobile md:px-margin-desktop w-full max-w-container-max mx-auto relative overflow-hidden bg-[#F6F3EC] text-[#181716]">
      {/* Hero Section */}
      <div className="flex flex-col items-center text-center mb-16 relative">
        <FadeUp>
          <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3.5 py-1.5 rounded border border-[#9E7B4F]/25 uppercase tracking-widest font-bold mb-4 inline-block">
            METHODOLOGY // THE REPUTATION CASCADE
          </span>
        </FadeUp>

        <FadeUp delay={0.1}>
          <h2 className="font-display font-bold text-4xl sm:text-6xl md:text-7xl text-[#181716] mb-4 max-w-4xl tracking-tight leading-tight">
            Become impossible to <span className="text-[#9E7B4F]">ignore.</span>
          </h2>
        </FadeUp>

        <FadeUp delay={0.15}>
          <p className="font-sans text-base sm:text-lg text-[#54504A] max-w-2xl mb-8 leading-relaxed">
            Your expertise is rare. Your positioning should make it undeniable. We engineer narrative authority for technical founders and leaders in crowded digital markets.
          </p>
        </FadeUp>

        <FadeUp delay={0.2}>
          <a href="#contact" className="btn-primary">
            START YOUR TRANSFORMATION
          </a>
        </FadeUp>
      </div>

      {/* Transformation Flow (Before / After Comparison) */}
      <div className="mb-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Before: Weak Positioning */}
          <FadeUp>
            <motion.div
              whileHover={{ y: -4 }}
              transition={{ duration: 0.35 }}
              className="bg-[#FAF8F5] rounded-2xl p-8 border border-zinc-300 flex flex-col justify-between h-full shadow-sm"
            >
              <div>
                <div className="flex justify-between items-center mb-6">
                  <span className="font-mono text-xs text-zinc-500 bg-zinc-200/80 px-3 py-1 rounded font-bold uppercase tracking-wider">
                    CURRENT STATE // CONVENTIONAL
                  </span>
                  <EyeOff size={24} className="text-zinc-400" />
                </div>
                <h3 className="font-display font-bold text-2xl md:text-3xl text-zinc-700 mb-3">
                  Weak Domain Positioning
                </h3>
                <p className="font-sans text-sm text-zinc-500 leading-relaxed mb-6">
                  Blending into the feed. Deep technical brilliance buried under generic corporate buzzwords. Unnoticed by high-tier clients and investors.
                </p>
              </div>

              <ul className="space-y-2 border-t border-zinc-200 pt-4 text-xs font-mono text-zinc-500">
                <li>✕ Dependent on cold outbound spam</li>
                <li>✕ Ignored by key ecosystem partners</li>
                <li>✕ Viewed as an interchangeable vendor</li>
              </ul>
            </motion.div>
          </FadeUp>

          {/* After: Strong Authority */}
          <FadeUp delay={0.15}>
            <motion.div
              whileHover={{ y: -4 }}
              transition={{ duration: 0.35 }}
              className="bg-[#EFECE4] rounded-2xl p-8 border-2 border-[#9E7B4F] metallic-edge flex flex-col justify-between h-full shadow-lg relative overflow-hidden group"
            >
              <div className="absolute top-0 right-0 w-48 h-48 bg-[#9E7B4F]/10 blur-3xl pointer-events-none" />

              <div>
                <div className="flex justify-between items-center mb-6">
                  <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/15 px-3 py-1 rounded font-bold uppercase tracking-wider border border-[#9E7B4F]/30">
                    TRANSFORMED // FOUND X ENGINE
                  </span>
                  <Award size={26} className="text-[#9E7B4F] group-hover:scale-110 transition-transform" />
                </div>
                <h3 className="font-display font-bold text-2xl md:text-3xl text-[#181716] mb-3">
                  Category-of-One Authority
                </h3>
                <p className="font-sans text-sm text-[#54504A] leading-relaxed mb-6">
                  Sharp, authoritative, and magnetizing. Your technical narrative framed as an indispensable industry benchmark that pulls high-ticket deals to you.
                </p>
              </div>

              <ul className="space-y-2 border-t border-[#9E7B4F]/25 pt-4 text-xs font-mono text-[#181716]">
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-[#9E7B4F]" /> Consistent high-ticket inbound deal flow
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-[#9E7B4F]" /> Cited by founders, venture capitalists & CTOs
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-[#9E7B4F]" /> Premium pricing power with zero rate resistance
                </li>
              </ul>
            </motion.div>
          </FadeUp>
        </div>
      </div>

      {/* Process Bento Grid: The Architecture of Authority */}
      <div>
        <FadeUp>
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1 rounded border border-[#9E7B4F]/25 font-bold uppercase tracking-wider">
              ROADMAP
            </span>
            <h3 className="font-display font-bold text-3xl sm:text-5xl text-[#181716] mt-3 tracking-tight">
              The Architecture of Authority
            </h3>
            <p className="font-sans text-sm text-[#54504A] mt-2">
              Our end-to-end operational framework deployed across all client partnerships.
            </p>
          </div>
        </FadeUp>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* 01 DISCOVER (col-span-4) */}
          <FadeUp className="md:col-span-4">
            <motion.div
              whileHover={{ y: -4 }}
              transition={{ duration: 0.35 }}
              className="bg-[#EFECE4] rounded-2xl p-7 flex flex-col justify-between border border-[#9E7B4F]/30 hover:border-[#9E7B4F] transition-all min-h-[220px] shadow-sm group"
            >
              <div className="flex justify-between items-start mb-6">
                <span className="font-mono text-xs text-[#9E7B4F] font-bold bg-[#9E7B4F]/10 px-2.5 py-0.5 rounded">
                  01
                </span>
                <Compass size={24} className="text-[#9E7B4F] group-hover:rotate-12 transition-transform" />
              </div>
              <div>
                <h4 className="font-display font-bold text-xl text-[#181716] mb-2">
                  DISCOVER & EXTRACT
                </h4>
                <p className="font-sans text-sm text-[#54504A] leading-relaxed">
                  Mining your proprietary technical insights, contrarian views, and customer case studies to distill core narrative pillars.
                </p>
              </div>
            </motion.div>
          </FadeUp>

          {/* 02 POSITION (col-span-8) */}
          <FadeUp delay={0.1} className="md:col-span-8">
            <motion.div
              whileHover={{ y: -4 }}
              transition={{ duration: 0.35 }}
              className="bg-[#EFECE4] rounded-2xl p-7 flex flex-col justify-between border border-[#9E7B4F]/30 hover:border-[#9E7B4F] transition-all min-h-[220px] shadow-sm group relative overflow-hidden"
            >
              <div className="flex justify-between items-start mb-6">
                <span className="font-mono text-xs text-[#9E7B4F] font-bold bg-[#9E7B4F]/10 px-2.5 py-0.5 rounded">
                  02
                </span>
                <Layers size={24} className="text-[#9E7B4F] group-hover:scale-110 transition-transform" />
              </div>
              <div>
                <h4 className="font-display font-bold text-xl text-[#181716] mb-2">
                  STRATEGIC POSITIONING MATRIX
                </h4>
                <p className="font-sans text-sm text-[#54504A] leading-relaxed max-w-xl">
                  Crafting a category-of-one stance. We engineer the specific framing and visual language that elevates your brand far above generic competitors.
                </p>
              </div>
            </motion.div>
          </FadeUp>

          {/* 03 CREATE (col-span-6) */}
          <FadeUp delay={0.15} className="md:col-span-6">
            <motion.div
              whileHover={{ y: -4 }}
              transition={{ duration: 0.35 }}
              className="bg-[#EFECE4] rounded-2xl p-7 flex flex-col justify-between border border-[#9E7B4F]/30 hover:border-[#9E7B4F] transition-all min-h-[220px] shadow-sm group"
            >
              <div className="flex justify-between items-start mb-6">
                <span className="font-mono text-xs text-[#9E7B4F] font-bold bg-[#9E7B4F]/10 px-2.5 py-0.5 rounded">
                  03
                </span>
                <PenTool size={24} className="text-[#9E7B4F] group-hover:scale-110 transition-transform" />
              </div>
              <div>
                <h4 className="font-display font-bold text-xl text-[#181716] mb-2">
                  CREATE & ASSEMBLE
                </h4>
                <p className="font-sans text-sm text-[#54504A] leading-relaxed">
                  Engineering bespoke web landing surfaces, spatial 3D interactive elements, and high-signal editorial content.
                </p>
              </div>
            </motion.div>
          </FadeUp>

          {/* 04 DISTRIBUTE & 05 GROW (col-span-6 stacked grid) */}
          <FadeUp delay={0.2} className="md:col-span-6 grid grid-rows-2 gap-4">
            <motion.div
              whileHover={{ x: 4 }}
              transition={{ duration: 0.25 }}
              className="bg-[#EFECE4] rounded-2xl p-5 flex items-center justify-between border border-[#9E7B4F]/30 hover:border-[#9E7B4F] transition-all shadow-sm group"
            >
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs text-[#9E7B4F] font-bold bg-[#9E7B4F]/10 px-2 py-0.5 rounded">
                  04
                </span>
                <h4 className="font-display font-bold text-lg text-[#181716]">
                  ALGORITHMIC DISTRIBUTION
                </h4>
              </div>
              <Share2 size={20} className="text-[#9E7B4F] group-hover:scale-110 transition-transform" />
            </motion.div>

            <motion.div
              whileHover={{ x: 4 }}
              transition={{ duration: 0.25 }}
              className="bg-[#EFECE4] rounded-2xl p-5 flex items-center justify-between border-2 border-[#9E7B4F] transition-all shadow-md group"
            >
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs text-white font-bold bg-[#9E7B4F] px-2 py-0.5 rounded">
                  05
                </span>
                <h4 className="font-display font-bold text-lg text-[#181716]">
                  SCALE & COMMERCIAL CONVERSION
                </h4>
              </div>
              <TrendingUp size={20} className="text-[#9E7B4F] group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
            </motion.div>
          </FadeUp>
        </div>
      </div>
    </section>
  );
}
