import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

export function Hero() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const container = document.getElementById('hero-nodes');
    if (!container) return;

    let canvas = canvasRef.current;
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvasRef.current = canvas;
      container.appendChild(canvas);
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = (canvas.width = container.offsetWidth || window.innerWidth);
    let height = (canvas.height = container.offsetHeight || window.innerHeight);

    let mouse = { x: -1000, y: -1000 };

    interface Particle {
      x: number;
      y: number;
      vx: number;
      vy: number;
      baseX: number;
      baseY: number;
      size: number;
    }

    const particles: Particle[] = [];
    for (let i = 0; i < 45; i++) {
      const rx = Math.random() * width;
      const ry = Math.random() * height;
      particles.push({
        x: rx,
        y: ry,
        vx: (Math.random() - 0.5) * 0.35,
        vy: (Math.random() - 0.5) * 0.35,
        baseX: rx,
        baseY: ry,
        size: Math.random() * 1.5 + 1,
      });
    }

    const handleResize = () => {
      if (!canvas || !container) return;
      width = canvas.width = container.offsetWidth || window.innerWidth;
      height = canvas.height = container.offsetHeight || window.innerHeight;
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      mouse.x = e.clientX - rect.left;
      mouse.y = e.clientY - rect.top;
    };

    const handleMouseLeave = () => {
      mouse.x = -1000;
      mouse.y = -1000;
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseleave', handleMouseLeave);

    let animId: number;

    const animate = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw subtle connecting lines
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 110) {
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = `rgba(185, 137, 104, ${0.15 * (1 - dist / 110)})`;
            ctx.lineWidth = 0.6;
            ctx.stroke();
          }
        }
      }

      particles.forEach((p) => {
        const dx = mouse.x - p.x;
        const dy = mouse.y - p.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < 150) {
          p.x -= dx * 0.018;
          p.y -= dy * 0.018;
        } else {
          p.x += (p.baseX - p.x) * 0.012;
          p.y += (p.baseY - p.y) * 0.012;
        }

        p.baseX += p.vx;
        p.baseY += p.vy;

        if (p.baseX < 0 || p.baseX > width) p.vx *= -1;
        if (p.baseY < 0 || p.baseY > height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(185, 137, 104, 0.6)';
        ctx.fill();
      });

      animId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseleave', handleMouseLeave);
      cancelAnimationFrame(animId);
    };
  }, []);

  return (
    <header className="relative w-full py-20 md:py-28 flex flex-col justify-between overflow-hidden bg-[#F6F3EC]">
      {/* Node Canvas Container */}
      <div id="hero-nodes" className="absolute inset-0 z-10 pointer-events-none" />

      {/* Warm Ambient Glow Backdrop */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-[#9E7B4F]/15 blur-[140px] rounded-full" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#F6F3EC]/80 via-transparent to-[#F6F3EC]" />
      </div>

      {/* Main Content */}
      <div className="relative z-20 text-center px-margin-mobile md:px-margin-desktop w-full max-w-container-max mx-auto flex flex-col items-center justify-center my-auto pt-8">
        {/* Seal Emblem & Status Badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="flex flex-col items-center gap-5 mb-8"
        >
          {/* Circular Seal Emblem Logo */}
          <div className="relative group">
            <div className="absolute inset-0 rounded-full bg-[#9E7B4F]/30 blur-xl group-hover:bg-[#9E7B4F]/40 transition-all pointer-events-none" />
            <img
              src="/images/foundx-logo.png"
              alt="FOUND X Seal Emblem"
              className="w-32 h-32 md:w-44 md:h-44 object-contain rounded-full relative z-10 hover:scale-105 transition-transform duration-500 mix-blend-multiply"
            />
          </div>

          {/* Status Pill Badge */}
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-[#EFECE4] border border-[#9E7B4F]/40 backdrop-blur-xl metallic-edge shadow-[0_4px_20px_rgba(158,123,79,0.12)]">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-mono text-xs text-[#181716] font-semibold tracking-wider">
              Available for Q3/Q4 Projects — Preet Yadav Studio
            </span>
          </div>
        </motion.div>

        {/* Display XL Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
          className="font-display font-bold text-4xl sm:text-6xl md:text-7xl lg:text-8xl text-[#181716] mb-6 max-w-5xl tracking-tighter leading-[1.05]"
        >
          BUILD. BRAND.{' '}
          <span className="text-[#9E7B4F] drop-shadow-[0_4px_25px_rgba(158,123,79,0.25)]">
            AUTOMATE. GROW.
          </span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          className="font-sans text-base md:text-xl text-[#54504A] max-w-2xl mb-10 leading-relaxed font-normal"
        >
          The builder's studio designed for high-performance founders and technical visionaries who demand architectural precision.
        </motion.p>

        {/* Action Buttons with Clear Primary vs Secondary Hierarchy */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
          className="flex flex-col sm:flex-row gap-4 mb-16 items-center"
        >
          <a
            href="#services"
            className="btn-primary"
          >
            Explore Studio Services
          </a>
          <a
            href="#work"
            className="btn-secondary"
          >
            View Case Studies
          </a>
        </motion.div>

        {/* Trust & Metric Highlights Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
          className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-8 w-full max-w-3xl pt-8 border-t border-[#9E7B4F]/25"
        >
          <div className="flex flex-col items-center">
            <span className="font-display text-2xl md:text-3xl font-bold text-[#181716]">50+</span>
            <span className="font-mono text-xs text-[#54504A] tracking-wider mt-1 font-semibold">Digital Products Shipped</span>
          </div>

          <div className="flex flex-col items-center">
            <span className="font-display text-2xl md:text-3xl font-bold text-[#9E7B4F]">100%</span>
            <span className="font-mono text-xs text-[#54504A] tracking-wider mt-1 font-semibold">Precision Engineering</span>
          </div>

          <div className="flex flex-col items-center">
            <span className="font-display text-2xl md:text-3xl font-bold text-[#181716]">2.4M+</span>
            <span className="font-mono text-xs text-[#54504A] tracking-wider mt-1 font-semibold">Organic LinkedIn Impressions</span>
          </div>
        </motion.div>
      </div>
    </header>
  );
}
