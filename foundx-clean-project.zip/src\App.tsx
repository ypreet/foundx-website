import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ScrollToTop } from './components/ScrollToTop';

// Dedicated Multi-Page Views
import { HomePage } from './pages/HomePage';
import { ServicesPage } from './pages/ServicesPage';
import { WebAppDevPage } from './pages/WebAppDevPage';
import { AIAgentsPage } from './pages/AIAgentsPage';
import { LinkedInGrowthPage } from './pages/LinkedInGrowthPage';
import { PersonalBrandingPage } from './pages/PersonalBrandingPage';
import { Showcase3DPage } from './pages/Showcase3DPage';
import { AboutPage } from './pages/AboutPage';
import { WorkPage } from './pages/WorkPage';
import { InsightsPage } from './pages/InsightsPage';
import { ContactPage } from './pages/ContactPage';

function App() {
  return (
    <BrowserRouter>
      <ScrollToTop />
      <div className="min-h-screen bg-[#F6F3EC] text-[#181716] flex flex-col justify-between">
        <Navbar />
        <main className="flex-1 pt-16">
          <Routes>
            {/* Main Studio Landing Overview */}
            <Route path="/" element={<HomePage />} />

            {/* Dedicated Main Services Page */}
            <Route path="/services" element={<ServicesPage />} />

            {/* Sub-Service Dedicated Pages */}
            <Route path="/services/web-app-development" element={<WebAppDevPage />} />
            <Route path="/services/ai-automation" element={<AIAgentsPage />} />
            <Route path="/services/linkedin-growth" element={<LinkedInGrowthPage />} />
            <Route path="/services/personal-branding" element={<PersonalBrandingPage />} />

            {/* Dedicated Studio Pages */}
            <Route path="/3d-showcase" element={<Showcase3DPage />} />
            <Route path="/ai-lab" element={<AIAgentsPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/work" element={<WorkPage />} />
            <Route path="/insights" element={<InsightsPage />} />
            <Route path="/contact" element={<ContactPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
}

export default App;
