import { FadeUp } from '../components/ui/FadeUp';

export function Testimonials() {
  return (
    <section className="section-y bg-brand-white">
      <div className="section-padding max-w-screen-xl mx-auto">
        <FadeUp>
          <div className="flex flex-col gap-4 mb-16">
            <p className="label">Testimonials</p>
            <h2 className="heading-md text-brand-black">What People Say</h2>
          </div>
        </FadeUp>

        <FadeUp delay={0.1}>
          <div className="flex items-center justify-center py-24 border border-dashed border-brand-border rounded-2xl">
            <div className="flex flex-col items-center gap-4 text-center max-w-sm">
              <div className="w-12 h-12 rounded-full bg-brand-brown/10 flex items-center justify-center">
                <span className="text-brand-brown text-xl">✦</span>
              </div>
              <p className="font-semibold text-brand-black/50">Client feedback coming soon.</p>
              <p className="text-sm text-brand-black/35">
                I'm currently collecting reviews from clients I've worked with. Check back soon.
              </p>
            </div>
          </div>
        </FadeUp>
      </div>
    </section>
  );
}
