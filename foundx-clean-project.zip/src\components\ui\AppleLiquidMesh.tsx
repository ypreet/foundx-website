import { motion } from 'framer-motion';

export function AppleLiquidMesh() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
      {/* Liquid Organic Blob 1 */}
      <motion.div
        animate={{
          x: [0, 80, -40, 0],
          y: [0, -60, 40, 0],
          scale: [1, 1.25, 0.9, 1],
          rotate: [0, 90, 180, 360],
        }}
        transition={{
          duration: 18,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="absolute top-[-10%] left-[-5%] w-[600px] h-[600px] rounded-full"
        style={{
          background: 'radial-gradient(circle, rgba(139, 115, 85, 0.25) 0%, rgba(196, 168, 130, 0.12) 50%, rgba(250, 250, 249, 0) 70%)',
          filter: 'blur(70px)',
        }}
      />

      {/* Liquid Organic Blob 2 */}
      <motion.div
        animate={{
          x: [0, -70, 50, 0],
          y: [0, 80, -50, 0],
          scale: [1, 1.15, 0.95, 1],
          rotate: [360, 180, 90, 0],
        }}
        transition={{
          duration: 22,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="absolute top-[20%] right-[-10%] w-[700px] h-[700px] rounded-full"
        style={{
          background: 'radial-gradient(circle, rgba(44, 24, 16, 0.18) 0%, rgba(92, 61, 46, 0.08) 55%, rgba(250, 250, 249, 0) 75%)',
          filter: 'blur(80px)',
        }}
      />

      {/* Liquid Organic Blob 3 */}
      <motion.div
        animate={{
          x: [0, 50, -60, 0],
          y: [0, -40, 70, 0],
          scale: [1, 1.3, 0.85, 1],
        }}
        transition={{
          duration: 25,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="absolute bottom-[-10%] left-[20%] w-[650px] h-[650px] rounded-full"
        style={{
          background: 'radial-gradient(circle, rgba(196, 168, 130, 0.22) 0%, rgba(139, 115, 85, 0.10) 50%, rgba(250, 250, 249, 0) 70%)',
          filter: 'blur(75px)',
        }}
      />
    </div>
  );
}
