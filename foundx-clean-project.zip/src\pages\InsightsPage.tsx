import { Insights } from '../sections/Insights';

export function InsightsPage() {
  return (
    <div className="pt-12">
      <Insights />
    </div>
  );
}
