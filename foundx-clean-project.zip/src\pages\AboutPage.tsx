import { About } from '../sections/About';
import { Process } from '../sections/Process';

export function AboutPage() {
  return (
    <div className="pt-12">
      <About />
      <Process />
    </div>
  );
}
