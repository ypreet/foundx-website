import { Link } from 'react-router-dom';
import { DeviceShowcase } from '../sections/DeviceShowcase';
import { FadeUp } from '../components/ui/FadeUp';
import { ArrowLeft, Cpu, ShieldCheck, Zap, Layers, Sparkles } from 'lucide-react';

const specs = [
  { label: 'Rendering Pipeline', value: 'WebGL 2.0 & CSS3D Hardware Layering' },
  { label: 'P99 Edge Latency', value: '12.4ms (Global CDN Multi-Region)' },
  { label: 'Agent Reasoning Engine', value: 'Autonomous Multi-Modal RAG (4 Nodes)' },
  { label: 'Frame Budget', value: '16.6ms (Locked 60fps Sub-frame Speed)' },
  { label: 'Spatial Perspective', value: '1400px Depth with Dynamic Gyro Parallax' },
  { label: 'Security & Integrity', value: 'Zero-Exploit Static Type Checking & Memory Isolation' },
];

export function Showcase3DPage() {
  return (
    <div className="pt-12 pb-24 bg-[#F6F3EC] text-[#181716]">
      {/* Top Breadcrumb Header */}
      <div className="max-w-container-max mx-auto px-margin-mobile md:px-margin-desktop mb-4">
        <Link
          to="/"
          className="inline-flex items-center gap-2 font-mono text-xs text-[#9E7B4F] font-bold uppercase tracking-wider hover:underline"
        >
          <ArrowLeft size={16} /> BACK TO STUDIO HOME
        </Link>
      </div>

      {/* Hero Showcase Title */}
      <div className="max-w-4xl mx-auto text-center px-margin-mobile md:px-margin-desktop mb-6">
        <FadeUp>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#EFECE4] border border-[#9E7B4F]/40 text-[#9E7B4F] font-mono text-xs font-bold uppercase tracking-widest mb-4 shadow-sm">
            <Sparkles size={14} className="text-[#9E7B4F]" />
            SPATIAL HARDWARE OS EXPERIMENT
          </div>
        </FadeUp>
        <FadeUp delay={0.1}>
          <h1 className="font-display font-bold text-4xl sm:text-6xl md:text-7xl text-[#181716] tracking-tight leading-tight mb-4">
            3D Studio <span className="text-[#9E7B4F]">Spatial Display.</span>
          </h1>
        </FadeUp>
        <FadeUp delay={0.15}>
          <p className="font-sans text-base sm:text-lg text-[#54504A] max-w-2xl mx-auto leading-relaxed">
            Experience the architectural precision behind FOUND X products. Scroll and tilt to inspect our real-time engineering telemetry, autonomous AI agent simulations, and growth systems.
          </p>
        </FadeUp>
      </div>

      {/* The 3D Interactive Tablet Component */}
      <DeviceShowcase />

      {/* Hardware & Engineering Telemetry Specifications */}
      <div className="max-w-container-max mx-auto px-margin-mobile md:px-margin-desktop mt-16">
        <FadeUp>
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1 rounded border border-[#9E7B4F]/25 font-bold uppercase tracking-wider">
              ENGINEERING BENCHMARKS
            </span>
            <h3 className="font-display font-bold text-3xl md:text-4xl text-[#181716] mt-3">
              Spatial Architecture Specifications
            </h3>
            <p className="font-sans text-sm text-[#54504A] mt-2">
              Every digital interface we ship is engineered against strict sub-frame performance SLAs.
            </p>
          </div>
        </FadeUp>

        {/* Specs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {specs.map((spec, i) => (
            <FadeUp key={spec.label} delay={i * 0.08}>
              <div className="bg-[#EFECE4] border border-[#9E7B4F]/30 rounded-2xl p-6 metallic-edge shadow-sm hover:border-[#9E7B4F] transition-all">
                <div className="font-mono text-xs text-[#9E7B4F] uppercase tracking-wider font-bold mb-2">
                  {spec.label}
                </div>
                <div className="font-display font-bold text-lg text-[#181716]">
                  {spec.value}
                </div>
              </div>
            </FadeUp>
          ))}
        </div>

        {/* Architecture Capabilities Bento */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto mt-12">
          <div className="bg-[#FAF8F5] border border-[#9E7B4F]/25 rounded-2xl p-6 flex flex-col items-center text-center">
            <Zap size={28} className="text-[#9E7B4F] mb-3" />
            <h4 className="font-display font-bold text-base text-[#181716] mb-1">Sub-Frame Latency</h4>
            <p className="font-sans text-xs text-[#54504A] leading-relaxed">
              Optimized edge distribution ensures web interfaces react in &lt;16ms.
            </p>
          </div>

          <div className="bg-[#FAF8F5] border border-[#9E7B4F]/25 rounded-2xl p-6 flex flex-col items-center text-center">
            <Cpu size={28} className="text-[#9E7B4F] mb-3" />
            <h4 className="font-display font-bold text-base text-[#181716] mb-1">Autonomous AI Nodes</h4>
            <p className="font-sans text-xs text-[#54504A] leading-relaxed">
              Custom agent pipelines automate high-friction operational workflows.
            </p>
          </div>

          <div className="bg-[#FAF8F5] border border-[#9E7B4F]/25 rounded-2xl p-6 flex flex-col items-center text-center">
            <ShieldCheck size={28} className="text-[#9E7B4F] mb-3" />
            <h4 className="font-display font-bold text-base text-[#181716] mb-1">Production Resilient</h4>
            <p className="font-sans text-xs text-[#54504A] leading-relaxed">
              Full test suites and type-safe verification with zero runtime surprises.
            </p>
          </div>

          <div className="bg-[#FAF8F5] border border-[#9E7B4F]/25 rounded-2xl p-6 flex flex-col items-center text-center">
            <Layers size={28} className="text-[#9E7B4F] mb-3" />
            <h4 className="font-display font-bold text-base text-[#181716] mb-1">Domain Authority</h4>
            <p className="font-sans text-xs text-[#54504A] leading-relaxed">
              Positioning founders as category leaders through algorithmic leverage.
            </p>
          </div>
        </div>

        {/* CTA Banner */}
        <div className="mt-16 bg-[#EFECE4] border border-[#9E7B4F]/40 rounded-3xl p-8 md:p-12 text-center max-w-4xl mx-auto shadow-md">
          <h3 className="font-display font-bold text-3xl md:text-4xl text-[#181716] mb-3">
            Ready to engineer your digital product?
          </h3>
          <p className="font-sans text-base text-[#54504A] max-w-xl mx-auto mb-8">
            From high-conversion SaaS web apps to autonomous AI workflows, FOUND X builds for technical founders who demand excellence.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/contact" className="btn-primary">
              INQUIRE ABOUT YOUR PROJECT
            </Link>
            <Link to="/work" className="btn-secondary">
              VIEW CASE STUDIES
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
