import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FadeUp } from '../components/ui/FadeUp';
import {
  ArrowRight,
  UserCheck,
  FileText,
  Eye,
  ShieldCheck,
  MessageSquare,
  Radar,
  Handshake,
  Maximize2,
  X,
  CheckCircle2,
  Sparkles,
  ExternalLink,
  BarChart3,
  Calendar,
} from 'lucide-react';

const funnelSteps = [
  { num: '01', title: 'PROFILE ARCHITECTURE', icon: UserCheck, width: 'w-full', zIndex: 'z-50' },
  { num: '02', title: 'HIGH-SIGNAL CONTENT', icon: FileText, width: 'w-[92%]', zIndex: 'z-40' },
  { num: '03', title: 'ALGORITHMIC VISIBILITY', icon: Eye, width: 'w-[84%]', zIndex: 'z-30' },
  { num: '04', title: 'DOMAIN AUTHORITY & TRUST', icon: ShieldCheck, width: 'w-[76%]', zIndex: 'z-20' },
  { num: '05', title: 'INBOUND PIPELINE DEALS', icon: MessageSquare, width: 'w-[68%]', zIndex: 'z-10' },
];

const architecturalServices = [
  {
    icon: UserCheck,
    title: 'Executive Profile Audit',
    desc: 'Optimizing your digital front door to establish instant technical authority and executive credibility upon first glance.',
  },
  {
    icon: FileText,
    title: 'Content Strategy & Ghostwriting',
    desc: 'Data-driven narrative design. We architect posts that resonate with high-value technical buyers and founders.',
  },
  {
    icon: Radar,
    title: 'Inbound Lead Acquisition',
    desc: 'Systematic pipeline funnels designed to attract and qualify high-budget prospects without aggressive spam tactics.',
  },
  {
    icon: Handshake,
    title: 'Executive Network Leverage',
    desc: 'Converting digital interactions into real pipeline velocity through strategic relationship building and warm intros.',
  },
];

interface ProofItem {
  id: string;
  category: 'impressions' | 'followers' | 'scale';
  title: string;
  metric: string;
  metricLabel: string;
  growthPill: string;
  timeframe: string;
  strategy: string;
  image: string;
  keyHighlight: string;
  auditTag: string;
}

const proofData: ProofItem[] = [
  {
    id: 'proof-987k',
    category: 'scale',
    title: '1M Organic Reach Milestone',
    metric: '987,536',
    metricLabel: 'Quarterly Impressions',
    growthPill: '▲ +10,238.4%',
    timeframe: 'Past 90 days',
    strategy: 'Massive algorithmic compounding unlocking nearly one million verified impressions across targeted executive and founder audiences.',
    image: '/images/proof/proof-impressions-987k.jpg',
    keyHighlight: 'Over 10,238% expansion reaching 400k capacity wave peaks.',
    auditTag: 'VERIFIED IN-APP TELEMETRY',
  },
  {
    id: 'proof-612k',
    category: 'impressions',
    title: 'Triple-Wave Authority Engine',
    metric: '612,047',
    metricLabel: 'Monthly Impressions',
    growthPill: '▲ +928.1%',
    timeframe: 'Past 28 days',
    strategy: 'Multi-post technical framework breakdowns driving sustained 600k+ reach across consecutive viral compounding cycles.',
    image: '/images/proof/proof-impressions-612k.jpg',
    keyHighlight: '3 consecutive 15,000+ daily impression peaks generating qualified enterprise inquiries.',
    auditTag: 'VERIFIED IN-APP TELEMETRY',
  },
  {
    id: 'proof-562k',
    category: 'impressions',
    title: 'Parabolic Exponential Surge',
    metric: '562,308',
    metricLabel: 'Monthly Impressions',
    growthPill: '▲ +2,105.7%',
    timeframe: 'Past 28 days',
    strategy: 'Strategic narrative repositioning driving immediate 2,100%+ monthly impression growth culminating in a dramatic viral breakout.',
    image: '/images/proof/proof-impressions-562k.jpg',
    keyHighlight: '2,105.7% monthly expansion with peak velocity breaking past 18,000 views in a single day.',
    auditTag: 'VERIFIED IN-APP TELEMETRY',
  },
  {
    id: 'proof-211k',
    category: 'impressions',
    title: 'Winter Inbound Viral Surge',
    metric: '211,087',
    metricLabel: 'Monthly Impressions',
    growthPill: '▲ +1,465.5%',
    timeframe: 'Past 28 days',
    strategy: 'Precision enterprise thought leadership framework executed into early January, driving a dramatic viral peak approaching 20,000 daily views.',
    image: '/images/proof/proof-impressions-211k.jpg',
    keyHighlight: '+1,465.5% 28-day growth with peak single-day velocity breaking past 19,000 views.',
    auditTag: 'VERIFIED IN-APP TELEMETRY',
  },
  {
    id: 'proof-210k',
    category: 'impressions',
    title: 'High-Ticket Inbound Viral Surge',
    metric: '210,870',
    metricLabel: 'Monthly Impressions',
    growthPill: '▲ +1,465.5%',
    timeframe: 'Past 28 days',
    strategy: 'Precision-engineered technical teardowns designed for enterprise CTOs. Generated 4,000+ daily views at peak velocity.',
    image: '/images/proof/proof-impressions-210k.jpg',
    keyHighlight: 'Over 1,465% growth in 28 days with sustained high-relevance inbound DMs.',
    auditTag: 'VERIFIED IN-APP TELEMETRY',
  },
  {
    id: 'proof-180k',
    category: 'impressions',
    title: 'Compound Distribution Engine',
    metric: '180,820',
    metricLabel: 'Monthly Impressions',
    growthPill: '▲ +917.6%',
    timeframe: 'Past 28 days',
    strategy: 'Consistency-engineered multi-post cadence maintaining constant visibility in founder and tech executive newsfeeds.',
    image: '/images/proof/proof-impressions-180k.jpg',
    keyHighlight: 'Multiple compounding peaks throughout August resulting in 917% month-over-month reach.',
    auditTag: 'VERIFIED IN-APP TELEMETRY',
  },
  {
    id: 'proof-29k',
    category: 'followers',
    title: 'Executive Follower Acceleration',
    metric: '29,880',
    metricLabel: 'Total Followers',
    growthPill: '▲ +7.6%',
    timeframe: 'Past 28 days',
    strategy: 'High-density audience acquisition targeting SaaS founders, tech directors, and venture capitalists without paid ads.',
    image: '/images/proof/proof-followers-29k.jpg',
    keyHighlight: 'Consistently adding 100+ qualified executive connections per week.',
    auditTag: 'VERIFIED IN-APP TELEMETRY',
  },
  {
    id: 'proof-87k',
    category: 'impressions',
    title: 'Late-Cycle Inflection Surge',
    metric: '87,315',
    metricLabel: 'Active Impressions',
    growthPill: '▲ +11.8%',
    timeframe: 'Past 28 days',
    strategy: 'Sharply focused niche thought leadership driving a sudden hockey-stick lift heading into mid-August.',
    image: '/images/proof/proof-impressions-87k.jpg',
    keyHighlight: 'Immediate 18k peak surge transforming account momentum and profile engagement.',
    auditTag: 'VERIFIED IN-APP TELEMETRY',
  },
  {
    id: 'proof-79k',
    category: 'impressions',
    title: 'Steep Hockey-Stick Breakout',
    metric: '79,220',
    metricLabel: 'Active Impressions',
    growthPill: '▲ +10.4%',
    timeframe: 'Past 28 days',
    strategy: 'Breaking through account algorithmic plateaus with sharp narrative hooks that convert passive scrollers into engaged followers.',
    image: '/images/proof/proof-impressions-79k.jpg',
    keyHighlight: 'Instant upward surge inflection on Aug 14 leading to qualified inbound meetings.',
    auditTag: 'VERIFIED IN-APP TELEMETRY',
  },
];

export function LinkedInSection() {
  const [activeFilter, setActiveFilter] = useState<'all' | 'impressions' | 'followers' | 'scale'>('all');
  const [selectedProof, setSelectedProof] = useState<ProofItem | null>(null);

  const filteredProofs = activeFilter === 'all'
    ? proofData
    : proofData.filter((p) => p.category === activeFilter);

  return (
    <section id="linkedin" className="py-16 md:py-24 px-margin-mobile md:px-margin-desktop w-full max-w-container-max mx-auto relative overflow-hidden bg-[#F6F3EC] text-[#181716]">
      {/* Hero Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center mb-16">
        {/* Left */}
        <div className="relative z-10 flex flex-col items-start">
          <FadeUp>
            <span className="font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1.5 rounded border border-[#9E7B4F]/25 uppercase tracking-widest font-bold mb-4 inline-block">
              ORGANIC GROWTH ENGINE
            </span>
          </FadeUp>

          <FadeUp delay={0.1}>
            <h2 className="font-display font-bold text-4xl sm:text-6xl md:text-7xl text-[#181716] mb-6 leading-tight tracking-tight">
              Your LinkedIn should work like a <span className="text-[#9E7B4F]">commercial engine.</span>
            </h2>
          </FadeUp>

          <FadeUp delay={0.15}>
            <p className="font-sans text-base md:text-lg text-[#54504A] mb-8 max-w-xl leading-relaxed">
              We transform passive profiles into active inbound generators. Precision-engineered technical narratives, algorithmic reach, and qualified inbound deals for technical founders.
            </p>
          </FadeUp>

          <FadeUp delay={0.2}>
            <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
              <a href="#contact" className="btn-primary">
                SCALE MY LINKEDIN ENGINE
              </a>
              <a
                href="https://www.linkedin.com/in/preet-yadav-found-x/"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-secondary group"
              >
                CONNECT WITH PREET{' '}
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </a>
            </div>
          </FadeUp>
        </div>

        {/* Right — 3D Funnel Visualization Concept */}
        <FadeUp delay={0.25}>
          <div className="relative bg-[#EFECE4] border-2 border-[#9E7B4F]/30 rounded-3xl metallic-edge flex flex-col items-center justify-center p-8 shadow-sm">
            {/* Background Warm Glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-[#9E7B4F]/15 blur-3xl pointer-events-none" />

            <div className="font-mono text-xs text-[#9E7B4F] font-bold uppercase tracking-widest mb-6 text-center">
              THE 5-STEP CONVERSION CASCADE
            </div>

            <div className="flex flex-col gap-3 relative z-10 items-center w-full max-w-md">
              {funnelSteps.map((step) => {
                const Icon = step.icon;
                return (
                  <motion.div
                    key={step.num}
                    whileHover={{ scale: 1.02, y: -2 }}
                    className={`${step.width} bg-[#FAF8F5] border border-[#9E7B4F]/30 rounded-xl p-3.5 flex items-center justify-between shadow-sm cursor-default transition-all duration-300 hover:border-[#9E7B4F]`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-xs text-[#9E7B4F] font-bold bg-[#9E7B4F]/10 px-2 py-0.5 rounded">
                        {step.num}
                      </span>
                      <span className="font-display font-bold text-xs sm:text-sm text-[#181716] tracking-wide">
                        {step.title}
                      </span>
                    </div>
                    <Icon size={18} className="text-[#9E7B4F] shrink-0" />
                  </motion.div>
                );
              })}

              {/* Final Qualified Inbound Goal Badge */}
              <motion.div
                whileHover={{ scale: 1.04 }}
                className="w-[58%] bg-[#9E7B4F] text-white rounded-xl p-3.5 flex items-center justify-center shadow-md border border-[#8B693C] mt-2 cursor-default"
              >
                <span className="font-mono text-xs font-bold tracking-widest uppercase">
                  ★ QUALIFIED REVENUE DEAL
                </span>
              </motion.div>
            </div>
          </div>
        </FadeUp>
      </div>

      {/* ========================================================================= */}
      {/* SECTION: VERIFIED IN-APP TELEMETRY & CLIENT PROOF GALLERY */}
      {/* ========================================================================= */}
      <div id="proof" className="pt-8 pb-16 border-t border-[#9E7B4F]/25 my-12">
        {/* Proof Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <FadeUp>
              <div className="inline-flex items-center gap-2 font-mono text-xs text-[#9E7B4F] bg-[#9E7B4F]/10 px-3 py-1.5 rounded border border-[#9E7B4F]/25 uppercase tracking-widest font-bold mb-3">
                <CheckCircle2 size={13} className="text-emerald-600" />
                LIVE WORK PROOF // VERIFIED LINKEDIN TELEMETRY
              </div>
            </FadeUp>
            <FadeUp delay={0.1}>
              <h3 className="font-display font-bold text-3xl sm:text-5xl text-[#181716] tracking-tight">
                Real Growth Proof. <span className="text-[#9E7B4F]">Data That Speaks.</span>
              </h3>
            </FadeUp>
            <FadeUp delay={0.15}>
              <p className="font-sans text-sm sm:text-base text-[#54504A] max-w-2xl mt-2 leading-relaxed">
                Raw in-app analytics screenshots from client campaigns engineered by FOUND X. Unfiltered proof of algorithmic distribution, hockey-stick breakouts, and high-ticket inbound velocity.
              </p>
            </FadeUp>
          </div>

          {/* Quick Aggregate Stats Pill Bar */}
          <FadeUp delay={0.2}>
            <div className="bg-[#EFECE4] border border-[#9E7B4F]/30 p-3 rounded-2xl flex items-center gap-4 text-xs font-mono metallic-edge shadow-sm">
              <div>
                <div className="text-xs text-[#54504A] uppercase">Total Proof Reach</div>
                <div className="font-display font-bold text-lg text-[#181716]">6.5M+</div>
              </div>
              <div className="h-7 w-px bg-[#9E7B4F]/30" />
              <div>
                <div className="text-xs text-[#54504A] uppercase">Peak 90D Surge</div>
                <div className="font-display font-bold text-lg text-emerald-700">+10,238%</div>
              </div>
              <div className="h-7 w-px bg-[#9E7B4F]/30" />
              <div>
                <div className="text-xs text-[#54504A] uppercase">Decision Makers</div>
                <div className="font-display font-bold text-lg text-[#9E7B4F]">29,880+</div>
              </div>
            </div>
          </FadeUp>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center gap-2 mb-8">
          {[
            { key: 'all', label: `ALL PROOF SCREENSHOTS (${proofData.length})` },
            { key: 'impressions', label: 'IMPRESSION SURGES' },
            { key: 'followers', label: 'FOLLOWER VELOCITY' },
            { key: 'scale', label: '90-DAY SCALING' },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveFilter(tab.key as any)}
              className={`px-4 py-2 rounded-xl text-xs font-mono font-bold tracking-wider transition-all cursor-pointer border ${
                activeFilter === tab.key
                  ? 'bg-[#9E7B4F] text-white border-[#9E7B4F] shadow-sm'
                  : 'bg-[#EFECE4] text-[#54504A] border-[#9E7B4F]/25 hover:border-[#9E7B4F] hover:text-[#181716]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Proof Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProofs.map((item, idx) => (
            <FadeUp key={item.id} delay={idx * 0.08}>
              <motion.div
                whileHover={{ y: -4 }}
                transition={{ duration: 0.3 }}
                className="bg-[#EFECE4] border border-[#9E7B4F]/30 rounded-2xl overflow-hidden metallic-edge shadow-sm hover:shadow-xl hover:border-[#9E7B4F] transition-all flex flex-col justify-between h-full group"
              >
                {/* Top Header */}
                <div className="p-5 pb-3">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-mono text-xs font-bold text-[#9E7B4F] bg-[#9E7B4F]/10 px-2 py-0.5 rounded border border-[#9E7B4F]/25 uppercase tracking-wider">
                      {item.auditTag}
                    </span>
                    <span className="font-mono text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                      {item.growthPill}
                    </span>
                  </div>

                  <h4 className="font-display font-bold text-lg text-[#181716] group-hover:text-[#9E7B4F] transition-colors">
                    {item.title}
                  </h4>

                  {/* Big Bold Metric */}
                  <div className="mt-3 flex items-baseline gap-2">
                    <span className="font-display font-bold text-3xl sm:text-4xl text-[#181716] tracking-tight">
                      {item.metric}
                    </span>
                    <span className="font-mono text-xs text-[#54504A] uppercase">
                      {item.metricLabel}
                    </span>
                  </div>
                  <div className="font-mono text-xs text-[#54504A] flex items-center gap-1 mt-0.5">
                    <Calendar size={12} className="text-[#9E7B4F]" /> {item.timeframe}
                  </div>
                </div>

                {/* Screenshot Visual Window */}
                <div
                  onClick={() => setSelectedProof(item)}
                  className="relative mx-5 my-2 bg-white rounded-xl border border-[#9E7B4F]/25 overflow-hidden shadow-inner cursor-pointer group/img"
                >
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-48 object-contain bg-white transition-transform duration-500 group-hover/img:scale-105"
                  />
                  {/* Hover Overlay with Zoom Icon */}
                  <div className="absolute inset-0 bg-[#181716]/40 backdrop-blur-[2px] opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white font-mono text-xs font-bold uppercase tracking-wider">
                    <Maximize2 size={16} />
                    <span>INSPECT FULL PROOF</span>
                  </div>
                </div>

                {/* Bottom Card Context & Strategy */}
                <div className="p-5 pt-3 border-t border-[#9E7B4F]/20 flex flex-col justify-between flex-1">
                  <p className="font-sans text-xs text-[#54504A] leading-relaxed mb-3">
                    {item.strategy}
                  </p>

                  <div className="bg-[#FAF8F5] p-3 rounded-xl border border-[#9E7B4F]/20 text-xs font-sans text-[#181716] flex items-center justify-between">
                    <span className="font-semibold truncate mr-2">
                      💡 {item.keyHighlight}
                    </span>
                    <button
                      onClick={() => setSelectedProof(item)}
                      className="font-mono text-xs font-bold text-[#9E7B4F] hover:underline flex items-center gap-1 shrink-0 cursor-pointer"
                    >
                      EXPAND <ExternalLink size={11} />
                    </button>
                  </div>
                </div>
              </motion.div>
            </FadeUp>
          ))}
        </div>

        {/* Proof Bottom Assurance Bar */}
        <div className="mt-8 bg-[#FAF8F5] border border-[#9E7B4F]/30 rounded-2xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#9E7B4F]/15 flex items-center justify-center text-[#9E7B4F] shrink-0">
              <BarChart3 size={20} />
            </div>
            <div>
              <h5 className="font-display font-bold text-base text-[#181716]">
                Ready to turn your personal profile into an inbound engine?
              </h5>
              <p className="font-sans text-xs text-[#54504A]">
                All metrics above were generated purely through organic narrative positioning — zero paid ads or cold outreach spam.
              </p>
            </div>
          </div>
          <a href="#contact" className="btn-primary text-xs shrink-0 whitespace-nowrap">
            LAUNCH YOUR ENGINE NOW
          </a>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* LIGHTBOX MODAL FOR HIGH-RES INSPECTION */}
      {/* ========================================================================= */}
      <AnimatePresence>
        {selectedProof && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedProof(null)}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
          >
            <motion.div
              initial={{ scale: 0.92, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.92, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-[#F6F3EC] border-2 border-[#9E7B4F] rounded-3xl max-w-3xl w-full overflow-hidden shadow-2xl relative flex flex-col max-h-[90vh]"
            >
              {/* Modal Top Bar */}
              <div className="bg-[#EFECE4] border-b border-[#9E7B4F]/30 px-6 py-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="font-mono text-xs font-bold text-[#9E7B4F] uppercase tracking-wider">
                    {selectedProof.auditTag} • {selectedProof.timeframe}
                  </span>
                </div>
                <button
                  onClick={() => setSelectedProof(null)}
                  className="p-1.5 rounded-full hover:bg-black/5 text-[#181716] transition-colors cursor-pointer"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Modal Content */}
              <div className="p-6 overflow-y-auto space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 border-b border-[#9E7B4F]/20 pb-4">
                  <div>
                    <h3 className="font-display font-bold text-2xl text-[#181716]">
                      {selectedProof.title}
                    </h3>
                    <p className="font-sans text-xs text-[#54504A] mt-1">
                      {selectedProof.strategy}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-display font-bold text-3xl text-[#181716]">
                      {selectedProof.metric}
                    </div>
                    <div className="font-mono text-xs font-bold text-emerald-700">
                      {selectedProof.growthPill}
                    </div>
                  </div>
                </div>

                {/* High-Res Image Display */}
                <div className="bg-white rounded-2xl p-4 border border-[#9E7B4F]/30 shadow-inner flex items-center justify-center">
                  <img
                    src={selectedProof.image}
                    alt={selectedProof.title}
                    className="max-h-[50vh] w-auto object-contain rounded-lg"
                  />
                </div>

                {/* Key Insight Callout */}
                <div className="bg-[#EFECE4] border border-[#9E7B4F]/40 p-4 rounded-xl flex items-start gap-3">
                  <Sparkles size={18} className="text-[#9E7B4F] shrink-0 mt-0.5" />
                  <div>
                    <div className="font-mono text-xs font-bold text-[#9E7B4F] uppercase tracking-wide">
                      ARCHITECTURAL TAKEAWAY
                    </div>
                    <p className="font-sans text-xs text-[#181716] mt-1 leading-relaxed">
                      {selectedProof.keyHighlight} — By transforming technical expertise into algorithmic narratives, we build domain authority that translates directly into high-budget client inquiries.
                    </p>
                  </div>
                </div>
              </div>

              {/* Modal Footer CTA */}
              <div className="bg-[#EFECE4] border-t border-[#9E7B4F]/30 px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-3">
                <span className="font-mono text-xs text-[#54504A]">
                  Account Verified & Architected by Preet Yadav
                </span>
                <div className="flex gap-2">
                  <button
                    onClick={() => setSelectedProof(null)}
                    className="btn-secondary text-xs px-4 py-2"
                  >
                    CLOSE
                  </button>
                  <a
                    href="#contact"
                    onClick={() => setSelectedProof(null)}
                    className="btn-primary text-xs px-5 py-2"
                  >
                    REPLICATE THIS GROWTH
                  </a>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Architectural Services Grid */}
      <div className="pt-6">
        <FadeUp>
          <div className="flex justify-between items-end mb-8 border-b border-[#9E7B4F]/25 pb-4">
            <div>
              <span className="font-mono text-xs text-[#9E7B4F] font-bold uppercase tracking-wider block mb-1">
                DELIVERY SCOPE
              </span>
              <h3 className="font-display font-bold text-2xl md:text-3xl text-[#181716] tracking-tight">
                Architectural Growth Services
              </h3>
            </div>
            <span className="font-mono text-xs text-[#54504A] hidden sm:inline">DONE-FOR-YOU EXECUTION</span>
          </div>
        </FadeUp>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {architecturalServices.map((srv, i) => {
            const Icon = srv.icon;
            return (
              <FadeUp key={srv.title} delay={i * 0.1}>
                <motion.div
                  whileHover={{ y: -4 }}
                  transition={{ duration: 0.3 }}
                  className="bg-[#EFECE4] p-6 rounded-2xl metallic-edge border border-[#9E7B4F]/30 hover:border-[#9E7B4F] transition-all h-full flex flex-col justify-between group shadow-sm hover:shadow-md"
                >
                  <div>
                    <div className="w-12 h-12 rounded-xl bg-[#FAF8F5] border border-[#9E7B4F]/25 flex items-center justify-center text-[#9E7B4F] mb-5 shadow-sm group-hover:scale-110 transition-transform">
                      <Icon size={22} />
                    </div>

                    <h4 className="font-display font-bold text-lg text-[#181716] mb-2">
                      {srv.title}
                    </h4>

                    <p className="font-sans text-sm text-[#54504A] leading-relaxed">
                      {srv.desc}
                    </p>
                  </div>
                </motion.div>
              </FadeUp>
            );
          })}
        </div>
      </div>
    </section>
  );
}
