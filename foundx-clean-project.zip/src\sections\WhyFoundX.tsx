import { motion } from 'framer-motion';
import { FadeUp } from '../components/ui/FadeUp';

const pillars = [
  {
    num: '01. BUILD',
    icon: 'architecture',
    desc: 'We engineer robust digital architectures, from scalable web apps to high-performance MVPs.',
  },
  {
    num: '02. BRAND',
    icon: 'diamond',
    desc: 'Crafting sharp, authoritative visual identities and founder narratives that command attention.',
  },
  {
    num: '03. AUTOMATE',
    icon: 'smart_toy',
    desc: 'Deploying AI agents and custom workflows to eliminate friction and multiply output.',
  },
  {
    num: '04. GROW',
    icon: 'monitoring',
    desc: 'Data-driven lead generation and LinkedIn strategies to scale your reach organically.',
  },
];

export function WhyFoundX() {
  return (
    <section className="py-section-gap px-margin-mobile md:px-margin-desktop w-full max-w-container-max mx-auto relative">
      <FadeUp>
        <div className="text-center mb-20">
          <span className="font-mono text-xs text-primary px-3 py-1 bg-primary/10 rounded-sm mb-4 inline-block tracking-wider font-semibold">
            OUR APPROACH
          </span>
          <h2 className="font-display font-semibold text-3xl md:text-5xl text-white-pure max-w-3xl mx-auto leading-tight tracking-tight">
            Not another agency.
            <br />A builder’s studio.
          </h2>
        </div>
      </FadeUp>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {pillars.map((p, i) => (
          <FadeUp key={p.num} delay={i * 0.1}>
            <motion.div
              whileHover={{ y: -6, scale: 1.01 }}
              transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              className="bg-surface-dark/80 backdrop-blur-xl rounded-lg p-8 metallic-edge relative overflow-hidden group hover:bg-surface-dark transition-all duration-500 border border-white/5 hover:border-primary/30 h-full flex flex-col justify-between"
            >
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-30 transition-opacity">
                <span className="material-symbols-outlined text-6xl text-primary">{p.icon}</span>
              </div>
              <div>
                <h3 className="font-mono text-xs font-bold text-primary mb-4 tracking-widest">{p.num}</h3>
                <p className="font-sans text-sm md:text-base text-on-surface-variant leading-relaxed">{p.desc}</p>
              </div>
            </motion.div>
          </FadeUp>
        ))}
      </div>
    </section>
  );
}
